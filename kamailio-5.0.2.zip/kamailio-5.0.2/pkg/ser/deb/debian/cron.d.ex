#
# Regular cron jobs for the ser-0.8.7 package
#
0 4	* * *	root	ser-0.8.7_maintenance

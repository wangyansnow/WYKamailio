/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     FORWARD = 258,
     FORWARD_TCP = 259,
     FORWARD_TLS = 260,
     FORWARD_SCTP = 261,
     FORWARD_UDP = 262,
     EXIT = 263,
     DROP = 264,
     RETURN = 265,
     BREAK = 266,
     LOG_TOK = 267,
     ERROR = 268,
     ROUTE = 269,
     ROUTE_REQUEST = 270,
     ROUTE_FAILURE = 271,
     ROUTE_ONREPLY = 272,
     ROUTE_REPLY = 273,
     ROUTE_BRANCH = 274,
     ROUTE_SEND = 275,
     ROUTE_EVENT = 276,
     EXEC = 277,
     SET_HOST = 278,
     SET_HOSTPORT = 279,
     SET_HOSTPORTTRANS = 280,
     PREFIX = 281,
     STRIP = 282,
     STRIP_TAIL = 283,
     SET_USERPHONE = 284,
     APPEND_BRANCH = 285,
     REMOVE_BRANCH = 286,
     CLEAR_BRANCHES = 287,
     SET_USER = 288,
     SET_USERPASS = 289,
     SET_PORT = 290,
     SET_URI = 291,
     REVERT_URI = 292,
     FORCE_RPORT = 293,
     ADD_LOCAL_RPORT = 294,
     FORCE_TCP_ALIAS = 295,
     UDP_MTU = 296,
     UDP_MTU_TRY_PROTO = 297,
     UDP4_RAW = 298,
     UDP4_RAW_MTU = 299,
     UDP4_RAW_TTL = 300,
     IF = 301,
     ELSE = 302,
     SET_ADV_ADDRESS = 303,
     SET_ADV_PORT = 304,
     FORCE_SEND_SOCKET = 305,
     SET_FWD_NO_CONNECT = 306,
     SET_RPL_NO_CONNECT = 307,
     SET_FWD_CLOSE = 308,
     SET_RPL_CLOSE = 309,
     SWITCH = 310,
     CASE = 311,
     DEFAULT = 312,
     WHILE = 313,
     CFG_SELECT = 314,
     CFG_RESET = 315,
     URIHOST = 316,
     URIPORT = 317,
     MAX_LEN = 318,
     SETFLAG = 319,
     RESETFLAG = 320,
     ISFLAGSET = 321,
     SETAVPFLAG = 322,
     RESETAVPFLAG = 323,
     ISAVPFLAGSET = 324,
     METHOD = 325,
     URI = 326,
     FROM_URI = 327,
     TO_URI = 328,
     SRCIP = 329,
     SRCPORT = 330,
     DSTIP = 331,
     DSTPORT = 332,
     TOIP = 333,
     TOPORT = 334,
     SNDIP = 335,
     SNDPORT = 336,
     SNDPROTO = 337,
     SNDAF = 338,
     PROTO = 339,
     AF = 340,
     MYSELF = 341,
     MSGLEN = 342,
     UDP = 343,
     TCP = 344,
     TLS = 345,
     SCTP = 346,
     WS = 347,
     WSS = 348,
     DEBUG_V = 349,
     FORK = 350,
     FORK_DELAY = 351,
     MODINIT_DELAY = 352,
     LOGSTDERROR = 353,
     LOGFACILITY = 354,
     LOGNAME = 355,
     LOGCOLOR = 356,
     LOGPREFIX = 357,
     LOGPREFIXMODE = 358,
     LOGENGINETYPE = 359,
     LOGENGINEDATA = 360,
     LISTEN = 361,
     ADVERTISE = 362,
     ALIAS = 363,
     SR_AUTO_ALIASES = 364,
     DNS = 365,
     REV_DNS = 366,
     DNS_TRY_IPV6 = 367,
     DNS_TRY_NAPTR = 368,
     DNS_SRV_LB = 369,
     DNS_UDP_PREF = 370,
     DNS_TCP_PREF = 371,
     DNS_TLS_PREF = 372,
     DNS_SCTP_PREF = 373,
     DNS_RETR_TIME = 374,
     DNS_RETR_NO = 375,
     DNS_SERVERS_NO = 376,
     DNS_USE_SEARCH = 377,
     DNS_SEARCH_FMATCH = 378,
     DNS_NAPTR_IGNORE_RFC = 379,
     DNS_CACHE_INIT = 380,
     DNS_USE_CACHE = 381,
     DNS_USE_FAILOVER = 382,
     DNS_CACHE_FLAGS = 383,
     DNS_CACHE_NEG_TTL = 384,
     DNS_CACHE_MIN_TTL = 385,
     DNS_CACHE_MAX_TTL = 386,
     DNS_CACHE_MEM = 387,
     DNS_CACHE_GC_INT = 388,
     DNS_CACHE_DEL_NONEXP = 389,
     DNS_CACHE_REC_PREF = 390,
     AUTO_BIND_IPV6 = 391,
     DST_BLST_INIT = 392,
     USE_DST_BLST = 393,
     DST_BLST_MEM = 394,
     DST_BLST_TTL = 395,
     DST_BLST_GC_INT = 396,
     DST_BLST_UDP_IMASK = 397,
     DST_BLST_TCP_IMASK = 398,
     DST_BLST_TLS_IMASK = 399,
     DST_BLST_SCTP_IMASK = 400,
     PORT = 401,
     STAT = 402,
     CHILDREN = 403,
     SOCKET_WORKERS = 404,
     ASYNC_WORKERS = 405,
     ASYNC_USLEEP = 406,
     CHECK_VIA = 407,
     PHONE2TEL = 408,
     MEMLOG = 409,
     MEMDBG = 410,
     MEMSUM = 411,
     MEMSAFETY = 412,
     MEMJOIN = 413,
     MEMSTATUSMODE = 414,
     CORELOG = 415,
     SIP_WARNING = 416,
     SERVER_SIGNATURE = 417,
     SERVER_HEADER = 418,
     USER_AGENT_HEADER = 419,
     REPLY_TO_VIA = 420,
     LOADMODULE = 421,
     LOADPATH = 422,
     MODPARAM = 423,
     CFGENGINE = 424,
     MAXBUFFER = 425,
     SQL_BUFFER_SIZE = 426,
     USER = 427,
     GROUP = 428,
     CHROOT = 429,
     WDIR = 430,
     RUNDIR = 431,
     MHOMED = 432,
     DISABLE_TCP = 433,
     TCP_ACCEPT_ALIASES = 434,
     TCP_CHILDREN = 435,
     TCP_CONNECT_TIMEOUT = 436,
     TCP_SEND_TIMEOUT = 437,
     TCP_CON_LIFETIME = 438,
     TCP_POLL_METHOD = 439,
     TCP_MAX_CONNECTIONS = 440,
     TLS_MAX_CONNECTIONS = 441,
     TCP_NO_CONNECT = 442,
     TCP_SOURCE_IPV4 = 443,
     TCP_SOURCE_IPV6 = 444,
     TCP_OPT_FD_CACHE = 445,
     TCP_OPT_BUF_WRITE = 446,
     TCP_OPT_CONN_WQ_MAX = 447,
     TCP_OPT_WQ_MAX = 448,
     TCP_OPT_RD_BUF = 449,
     TCP_OPT_WQ_BLK = 450,
     TCP_OPT_DEFER_ACCEPT = 451,
     TCP_OPT_DELAYED_ACK = 452,
     TCP_OPT_SYNCNT = 453,
     TCP_OPT_LINGER2 = 454,
     TCP_OPT_KEEPALIVE = 455,
     TCP_OPT_KEEPIDLE = 456,
     TCP_OPT_KEEPINTVL = 457,
     TCP_OPT_KEEPCNT = 458,
     TCP_OPT_CRLF_PING = 459,
     TCP_OPT_ACCEPT_NO_CL = 460,
     TCP_CLONE_RCVBUF = 461,
     DISABLE_TLS = 462,
     ENABLE_TLS = 463,
     TLSLOG = 464,
     TLS_PORT_NO = 465,
     TLS_METHOD = 466,
     TLS_HANDSHAKE_TIMEOUT = 467,
     TLS_SEND_TIMEOUT = 468,
     SSLv23 = 469,
     SSLv2 = 470,
     SSLv3 = 471,
     TLSv1 = 472,
     TLS_VERIFY = 473,
     TLS_REQUIRE_CERTIFICATE = 474,
     TLS_CERTIFICATE = 475,
     TLS_PRIVATE_KEY = 476,
     TLS_CA_LIST = 477,
     DISABLE_SCTP = 478,
     ENABLE_SCTP = 479,
     SCTP_CHILDREN = 480,
     ADVERTISED_ADDRESS = 481,
     ADVERTISED_PORT = 482,
     DISABLE_CORE = 483,
     OPEN_FD_LIMIT = 484,
     SHM_MEM_SZ = 485,
     SHM_FORCE_ALLOC = 486,
     MLOCK_PAGES = 487,
     REAL_TIME = 488,
     RT_PRIO = 489,
     RT_POLICY = 490,
     RT_TIMER1_PRIO = 491,
     RT_TIMER1_POLICY = 492,
     RT_TIMER2_PRIO = 493,
     RT_TIMER2_POLICY = 494,
     MCAST_LOOPBACK = 495,
     MCAST_TTL = 496,
     MCAST = 497,
     TOS = 498,
     PMTU_DISCOVERY = 499,
     KILL_TIMEOUT = 500,
     MAX_WLOOPS = 501,
     PVBUFSIZE = 502,
     PVBUFSLOTS = 503,
     HTTP_REPLY_PARSE = 504,
     VERSION_TABLE_CFG = 505,
     CFG_DESCRIPTION = 506,
     SERVER_ID = 507,
     MAX_RECURSIVE_LEVEL = 508,
     MAX_BRANCHES_PARAM = 509,
     LATENCY_CFG_LOG = 510,
     LATENCY_LOG = 511,
     LATENCY_LIMIT_DB = 512,
     LATENCY_LIMIT_ACTION = 513,
     MSG_TIME = 514,
     ONSEND_RT_REPLY = 515,
     FLAGS_DECL = 516,
     AVPFLAGS_DECL = 517,
     ATTR_MARK = 518,
     SELECT_MARK = 519,
     ATTR_FROM = 520,
     ATTR_TO = 521,
     ATTR_FROMURI = 522,
     ATTR_TOURI = 523,
     ATTR_FROMUSER = 524,
     ATTR_TOUSER = 525,
     ATTR_FROMDOMAIN = 526,
     ATTR_TODOMAIN = 527,
     ATTR_GLOBAL = 528,
     ADDEQ = 529,
     SUBST = 530,
     SUBSTDEF = 531,
     SUBSTDEFS = 532,
     EQUAL = 533,
     LOG_OR = 534,
     LOG_AND = 535,
     BIN_OR = 536,
     BIN_AND = 537,
     BIN_XOR = 538,
     BIN_LSHIFT = 539,
     BIN_RSHIFT = 540,
     STRDIFF = 541,
     STREQ = 542,
     INTDIFF = 543,
     INTEQ = 544,
     MATCH = 545,
     DIFF = 546,
     EQUAL_T = 547,
     LTE = 548,
     GTE = 549,
     LT = 550,
     GT = 551,
     MINUS = 552,
     PLUS = 553,
     MODULO = 554,
     SLASH = 555,
     STAR = 556,
     BIN_NOT = 557,
     UNARY = 558,
     NOT = 559,
     DEFINED = 560,
     STRCAST = 561,
     INTCAST = 562,
     DOT = 563,
     STRLEN = 564,
     STREMPTY = 565,
     NUMBER = 566,
     ID = 567,
     NUM_ID = 568,
     STRING = 569,
     IPV6ADDR = 570,
     PVAR = 571,
     AVP_OR_PVAR = 572,
     EVENT_RT_NAME = 573,
     COMMA = 574,
     SEMICOLON = 575,
     RPAREN = 576,
     LPAREN = 577,
     LBRACE = 578,
     RBRACE = 579,
     LBRACK = 580,
     RBRACK = 581,
     CR = 582,
     COLON = 583
   };
#endif
/* Tokens.  */
#define FORWARD 258
#define FORWARD_TCP 259
#define FORWARD_TLS 260
#define FORWARD_SCTP 261
#define FORWARD_UDP 262
#define EXIT 263
#define DROP 264
#define RETURN 265
#define BREAK 266
#define LOG_TOK 267
#define ERROR 268
#define ROUTE 269
#define ROUTE_REQUEST 270
#define ROUTE_FAILURE 271
#define ROUTE_ONREPLY 272
#define ROUTE_REPLY 273
#define ROUTE_BRANCH 274
#define ROUTE_SEND 275
#define ROUTE_EVENT 276
#define EXEC 277
#define SET_HOST 278
#define SET_HOSTPORT 279
#define SET_HOSTPORTTRANS 280
#define PREFIX 281
#define STRIP 282
#define STRIP_TAIL 283
#define SET_USERPHONE 284
#define APPEND_BRANCH 285
#define REMOVE_BRANCH 286
#define CLEAR_BRANCHES 287
#define SET_USER 288
#define SET_USERPASS 289
#define SET_PORT 290
#define SET_URI 291
#define REVERT_URI 292
#define FORCE_RPORT 293
#define ADD_LOCAL_RPORT 294
#define FORCE_TCP_ALIAS 295
#define UDP_MTU 296
#define UDP_MTU_TRY_PROTO 297
#define UDP4_RAW 298
#define UDP4_RAW_MTU 299
#define UDP4_RAW_TTL 300
#define IF 301
#define ELSE 302
#define SET_ADV_ADDRESS 303
#define SET_ADV_PORT 304
#define FORCE_SEND_SOCKET 305
#define SET_FWD_NO_CONNECT 306
#define SET_RPL_NO_CONNECT 307
#define SET_FWD_CLOSE 308
#define SET_RPL_CLOSE 309
#define SWITCH 310
#define CASE 311
#define DEFAULT 312
#define WHILE 313
#define CFG_SELECT 314
#define CFG_RESET 315
#define URIHOST 316
#define URIPORT 317
#define MAX_LEN 318
#define SETFLAG 319
#define RESETFLAG 320
#define ISFLAGSET 321
#define SETAVPFLAG 322
#define RESETAVPFLAG 323
#define ISAVPFLAGSET 324
#define METHOD 325
#define URI 326
#define FROM_URI 327
#define TO_URI 328
#define SRCIP 329
#define SRCPORT 330
#define DSTIP 331
#define DSTPORT 332
#define TOIP 333
#define TOPORT 334
#define SNDIP 335
#define SNDPORT 336
#define SNDPROTO 337
#define SNDAF 338
#define PROTO 339
#define AF 340
#define MYSELF 341
#define MSGLEN 342
#define UDP 343
#define TCP 344
#define TLS 345
#define SCTP 346
#define WS 347
#define WSS 348
#define DEBUG_V 349
#define FORK 350
#define FORK_DELAY 351
#define MODINIT_DELAY 352
#define LOGSTDERROR 353
#define LOGFACILITY 354
#define LOGNAME 355
#define LOGCOLOR 356
#define LOGPREFIX 357
#define LOGPREFIXMODE 358
#define LOGENGINETYPE 359
#define LOGENGINEDATA 360
#define LISTEN 361
#define ADVERTISE 362
#define ALIAS 363
#define SR_AUTO_ALIASES 364
#define DNS 365
#define REV_DNS 366
#define DNS_TRY_IPV6 367
#define DNS_TRY_NAPTR 368
#define DNS_SRV_LB 369
#define DNS_UDP_PREF 370
#define DNS_TCP_PREF 371
#define DNS_TLS_PREF 372
#define DNS_SCTP_PREF 373
#define DNS_RETR_TIME 374
#define DNS_RETR_NO 375
#define DNS_SERVERS_NO 376
#define DNS_USE_SEARCH 377
#define DNS_SEARCH_FMATCH 378
#define DNS_NAPTR_IGNORE_RFC 379
#define DNS_CACHE_INIT 380
#define DNS_USE_CACHE 381
#define DNS_USE_FAILOVER 382
#define DNS_CACHE_FLAGS 383
#define DNS_CACHE_NEG_TTL 384
#define DNS_CACHE_MIN_TTL 385
#define DNS_CACHE_MAX_TTL 386
#define DNS_CACHE_MEM 387
#define DNS_CACHE_GC_INT 388
#define DNS_CACHE_DEL_NONEXP 389
#define DNS_CACHE_REC_PREF 390
#define AUTO_BIND_IPV6 391
#define DST_BLST_INIT 392
#define USE_DST_BLST 393
#define DST_BLST_MEM 394
#define DST_BLST_TTL 395
#define DST_BLST_GC_INT 396
#define DST_BLST_UDP_IMASK 397
#define DST_BLST_TCP_IMASK 398
#define DST_BLST_TLS_IMASK 399
#define DST_BLST_SCTP_IMASK 400
#define PORT 401
#define STAT 402
#define CHILDREN 403
#define SOCKET_WORKERS 404
#define ASYNC_WORKERS 405
#define ASYNC_USLEEP 406
#define CHECK_VIA 407
#define PHONE2TEL 408
#define MEMLOG 409
#define MEMDBG 410
#define MEMSUM 411
#define MEMSAFETY 412
#define MEMJOIN 413
#define MEMSTATUSMODE 414
#define CORELOG 415
#define SIP_WARNING 416
#define SERVER_SIGNATURE 417
#define SERVER_HEADER 418
#define USER_AGENT_HEADER 419
#define REPLY_TO_VIA 420
#define LOADMODULE 421
#define LOADPATH 422
#define MODPARAM 423
#define CFGENGINE 424
#define MAXBUFFER 425
#define SQL_BUFFER_SIZE 426
#define USER 427
#define GROUP 428
#define CHROOT 429
#define WDIR 430
#define RUNDIR 431
#define MHOMED 432
#define DISABLE_TCP 433
#define TCP_ACCEPT_ALIASES 434
#define TCP_CHILDREN 435
#define TCP_CONNECT_TIMEOUT 436
#define TCP_SEND_TIMEOUT 437
#define TCP_CON_LIFETIME 438
#define TCP_POLL_METHOD 439
#define TCP_MAX_CONNECTIONS 440
#define TLS_MAX_CONNECTIONS 441
#define TCP_NO_CONNECT 442
#define TCP_SOURCE_IPV4 443
#define TCP_SOURCE_IPV6 444
#define TCP_OPT_FD_CACHE 445
#define TCP_OPT_BUF_WRITE 446
#define TCP_OPT_CONN_WQ_MAX 447
#define TCP_OPT_WQ_MAX 448
#define TCP_OPT_RD_BUF 449
#define TCP_OPT_WQ_BLK 450
#define TCP_OPT_DEFER_ACCEPT 451
#define TCP_OPT_DELAYED_ACK 452
#define TCP_OPT_SYNCNT 453
#define TCP_OPT_LINGER2 454
#define TCP_OPT_KEEPALIVE 455
#define TCP_OPT_KEEPIDLE 456
#define TCP_OPT_KEEPINTVL 457
#define TCP_OPT_KEEPCNT 458
#define TCP_OPT_CRLF_PING 459
#define TCP_OPT_ACCEPT_NO_CL 460
#define TCP_CLONE_RCVBUF 461
#define DISABLE_TLS 462
#define ENABLE_TLS 463
#define TLSLOG 464
#define TLS_PORT_NO 465
#define TLS_METHOD 466
#define TLS_HANDSHAKE_TIMEOUT 467
#define TLS_SEND_TIMEOUT 468
#define SSLv23 469
#define SSLv2 470
#define SSLv3 471
#define TLSv1 472
#define TLS_VERIFY 473
#define TLS_REQUIRE_CERTIFICATE 474
#define TLS_CERTIFICATE 475
#define TLS_PRIVATE_KEY 476
#define TLS_CA_LIST 477
#define DISABLE_SCTP 478
#define ENABLE_SCTP 479
#define SCTP_CHILDREN 480
#define ADVERTISED_ADDRESS 481
#define ADVERTISED_PORT 482
#define DISABLE_CORE 483
#define OPEN_FD_LIMIT 484
#define SHM_MEM_SZ 485
#define SHM_FORCE_ALLOC 486
#define MLOCK_PAGES 487
#define REAL_TIME 488
#define RT_PRIO 489
#define RT_POLICY 490
#define RT_TIMER1_PRIO 491
#define RT_TIMER1_POLICY 492
#define RT_TIMER2_PRIO 493
#define RT_TIMER2_POLICY 494
#define MCAST_LOOPBACK 495
#define MCAST_TTL 496
#define MCAST 497
#define TOS 498
#define PMTU_DISCOVERY 499
#define KILL_TIMEOUT 500
#define MAX_WLOOPS 501
#define PVBUFSIZE 502
#define PVBUFSLOTS 503
#define HTTP_REPLY_PARSE 504
#define VERSION_TABLE_CFG 505
#define CFG_DESCRIPTION 506
#define SERVER_ID 507
#define MAX_RECURSIVE_LEVEL 508
#define MAX_BRANCHES_PARAM 509
#define LATENCY_CFG_LOG 510
#define LATENCY_LOG 511
#define LATENCY_LIMIT_DB 512
#define LATENCY_LIMIT_ACTION 513
#define MSG_TIME 514
#define ONSEND_RT_REPLY 515
#define FLAGS_DECL 516
#define AVPFLAGS_DECL 517
#define ATTR_MARK 518
#define SELECT_MARK 519
#define ATTR_FROM 520
#define ATTR_TO 521
#define ATTR_FROMURI 522
#define ATTR_TOURI 523
#define ATTR_FROMUSER 524
#define ATTR_TOUSER 525
#define ATTR_FROMDOMAIN 526
#define ATTR_TODOMAIN 527
#define ATTR_GLOBAL 528
#define ADDEQ 529
#define SUBST 530
#define SUBSTDEF 531
#define SUBSTDEFS 532
#define EQUAL 533
#define LOG_OR 534
#define LOG_AND 535
#define BIN_OR 536
#define BIN_AND 537
#define BIN_XOR 538
#define BIN_LSHIFT 539
#define BIN_RSHIFT 540
#define STRDIFF 541
#define STREQ 542
#define INTDIFF 543
#define INTEQ 544
#define MATCH 545
#define DIFF 546
#define EQUAL_T 547
#define LTE 548
#define GTE 549
#define LT 550
#define GT 551
#define MINUS 552
#define PLUS 553
#define MODULO 554
#define SLASH 555
#define STAR 556
#define BIN_NOT 557
#define UNARY 558
#define NOT 559
#define DEFINED 560
#define STRCAST 561
#define INTCAST 562
#define DOT 563
#define STRLEN 564
#define STREMPTY 565
#define NUMBER 566
#define ID 567
#define NUM_ID 568
#define STRING 569
#define IPV6ADDR 570
#define PVAR 571
#define AVP_OR_PVAR 572
#define EVENT_RT_NAME 573
#define COMMA 574
#define SEMICOLON 575
#define RPAREN 576
#define LPAREN 577
#define LBRACE 578
#define RBRACE 579
#define LBRACK 580
#define RBRACK 581
#define CR 582
#define COLON 583




/* Copy the first part of user declarations.  */
#line 30 "core/cfg.y"


#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <string.h>
#include <errno.h>
#include "route_struct.h"
#include "globals.h"
#ifdef SHM_MEM
#include "shm_init.h"
#endif /* SHM_MEM */
#include "route.h"
#include "switch.h"
#include "dprint.h"
#include "sr_module.h"
#include "modparam.h"
#include "ip_addr.h"
#include "resolve.h"
#include "socket_info.h"
#include "name_alias.h"
#include "ut.h"
#include "dset.h"
#include "select.h"
#include "flags.h"
#include "tcp_init.h"
#include "tcp_options.h"
#include "sctp_core.h"
#include "pvar.h"
#include "lvalue.h"
#include "rvalue.h"
#include "sr_compat.h"
#include "msg_translator.h"
#include "async_task.h"

#include "kemi.h"
#include "ppcfg.h"
#include "pvapi.h"
#include "config.h"
#include "cfg_core.h"
#include "cfg/cfg.h"
#ifdef CORE_TLS
#include "tls/tls_config.h"
#endif
#include "timer_ticks.h"

#ifdef DEBUG_DMALLOC
#include <dmalloc.h>
#endif

/* hack to avoid alloca usage in the generated C file (needed for compiler
 with no built in alloca, like icc*/
#undef _ALLOCA_H

#define onsend_check(s) \
	do{\
		if (rt!=ONSEND_ROUTE) yyerror( s " allowed only in onsend_routes");\
	}while(0)

	#define IF_AUTO_BIND_IPV6(x) x

#ifdef USE_DNS_CACHE
	#define IF_DNS_CACHE(x) x
#else
	#define IF_DNS_CACHE(x) warn("dns cache support not compiled in")
#endif

#ifdef USE_DNS_FAILOVER
	#define IF_DNS_FAILOVER(x) x
#else
	#define IF_DNS_FAILOVER(x) warn("dns failover support not compiled in")
#endif

#ifdef USE_NAPTR
	#define IF_NAPTR(x) x
#else
	#define IF_NAPTR(x) warn("dns naptr support not compiled in")
#endif

#ifdef USE_DST_BLACKLIST
	#define IF_DST_BLACKLIST(x) x
#else
	#define IF_DST_BLACKLIST(x) warn("dst blacklist support not compiled in")
#endif

#ifdef USE_SCTP
	#define IF_SCTP(x) x
#else
	#define IF_SCTP(x) warn("sctp support not compiled in")
#endif

#ifdef USE_RAW_SOCKS
	#define IF_RAW_SOCKS(x) x
#else
	#define IF_RAW_SOCKS(x) warn("raw socket support not compiled in")
#endif


extern int yylex();
/* safer then using yytext which can be array or pointer */
extern char* yy_number_str;

static void yyerror(char* s, ...);
static void yyerror_at(struct cfg_pos* pos, char* s, ...);
static char* tmp;
static int i_tmp;
static unsigned u_tmp;
static struct socket_id* lst_tmp;
static struct name_lst*  nl_tmp;
static int rt;  /* Type of route block for find_export */
static str* str_tmp;
static str s_tmp;
static struct ip_addr* ip_tmp;
static struct avp_spec* s_attr;
static select_t sel;
static select_t* sel_ptr;
static pv_spec_t* pv_spec;
static struct action *mod_func_action;
static struct lvalue* lval_tmp;
static struct rvalue* rval_tmp;

static void warn(char* s, ...);
static void warn_at(struct cfg_pos* pos, char* s, ...);
static void get_cpos(struct cfg_pos* pos);
static struct rval_expr* mk_rve_rval(enum rval_type, void* v);
static struct rval_expr* mk_rve1(enum rval_expr_op op, struct rval_expr* rve1);
static struct rval_expr* mk_rve2(enum rval_expr_op op, struct rval_expr* rve1,
									struct rval_expr* rve2);
static int rval_expr_int_check(struct rval_expr *rve);
static int warn_ct_rve(struct rval_expr *rve, char* name);
static struct socket_id* mk_listen_id(char*, int, int);
static struct name_lst* mk_name_lst(char* name, int flags);
static struct socket_id* mk_listen_id2(struct name_lst*, int, int);
static void free_name_lst(struct name_lst* lst);
static void free_socket_id_lst(struct socket_id* i);

static struct case_stms* mk_case_stm(struct rval_expr* ct, int is_re, 
									struct action* a, int* err);
static int case_check_type(struct case_stms* stms);
static int case_check_default(struct case_stms* stms);
static int mod_f_params_pre_fixup(struct action* a);
static void free_mod_func_action(struct action* a);


extern int line;
extern int column;
extern int startcolumn;
extern int startline;
extern char *finame;
extern char *routename;
extern char *default_routename;

#define set_cfg_pos(x) \
	do{\
		if(x) {\
		(x)->cline = line;\
		(x)->cfile = (finame!=0)?finame:((cfg_file!=0)?cfg_file:"default");\
		(x)->rname = (routename!=0)?routename:((default_routename!=0)?default_routename:"DEFAULT");\
		}\
	}while(0)




/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 199 "core/cfg.y"
{
	long intval;
	unsigned long uval;
	char* strval;
	struct expr* expr;
	struct action* action;
	struct case_stms* case_stms;
	struct net* ipnet;
	struct ip_addr* ipaddr;
	struct socket_id* sockid;
	struct name_lst* name_l;
	struct avp_spec* attr;
	struct _pv_spec* pvar;
	struct lvalue* lval;
	struct rvalue* rval;
	struct rval_expr* rv_expr;
	select_t* select;
}
/* Line 193 of yacc.c.  */
#line 940 "core/cfg.tab.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 953 "core/cfg.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  429
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   11337

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  329
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  100
/* YYNRULES -- Number of rules.  */
#define YYNRULES  858
/* YYNRULES -- Number of states.  */
#define YYNSTATES  1601

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   583

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint16 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110,   111,   112,   113,   114,
     115,   116,   117,   118,   119,   120,   121,   122,   123,   124,
     125,   126,   127,   128,   129,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   139,   140,   141,   142,   143,   144,
     145,   146,   147,   148,   149,   150,   151,   152,   153,   154,
     155,   156,   157,   158,   159,   160,   161,   162,   163,   164,
     165,   166,   167,   168,   169,   170,   171,   172,   173,   174,
     175,   176,   177,   178,   179,   180,   181,   182,   183,   184,
     185,   186,   187,   188,   189,   190,   191,   192,   193,   194,
     195,   196,   197,   198,   199,   200,   201,   202,   203,   204,
     205,   206,   207,   208,   209,   210,   211,   212,   213,   214,
     215,   216,   217,   218,   219,   220,   221,   222,   223,   224,
     225,   226,   227,   228,   229,   230,   231,   232,   233,   234,
     235,   236,   237,   238,   239,   240,   241,   242,   243,   244,
     245,   246,   247,   248,   249,   250,   251,   252,   253,   254,
     255,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     8,    10,    13,    15,    17,    19,
      21,    23,    24,    27,    28,    31,    33,    34,    37,    38,
      41,    42,    45,    47,    49,    51,    53,    55,    57,    61,
      65,    67,    69,    71,    73,    75,    77,    79,    81,    83,
      85,    87,    89,    91,    93,    95,    97,   101,   105,   111,
     115,   117,   121,   125,   131,   135,   137,   140,   142,   145,
     148,   151,   153,   157,   159,   163,   165,   167,   170,   173,
     175,   179,   181,   185,   189,   193,   197,   201,   205,   209,
     213,   217,   221,   225,   229,   233,   237,   241,   245,   249,
     253,   257,   261,   265,   269,   273,   277,   281,   285,   289,
     293,   297,   300,   304,   307,   311,   314,   318,   321,   325,
     328,   332,   335,   339,   342,   346,   349,   353,   356,   360,
     363,   367,   370,   374,   377,   381,   384,   388,   391,   395,
     398,   402,   405,   409,   412,   416,   419,   423,   426,   430,
     433,   437,   440,   444,   447,   451,   454,   458,   461,   465,
     468,   472,   475,   479,   482,   486,   489,   493,   496,   500,
     503,   507,   510,   514,   517,   521,   524,   528,   531,   535,
     539,   543,   547,   551,   555,   559,   563,   567,   571,   575,
     579,   583,   587,   591,   595,   599,   603,   607,   611,   615,
     619,   623,   627,   631,   635,   639,   643,   647,   651,   655,
     659,   663,   667,   671,   675,   679,   683,   687,   691,   695,
     699,   703,   707,   711,   715,   719,   723,   727,   731,   735,
     739,   743,   747,   751,   755,   759,   763,   767,   771,   775,
     779,   783,   787,   791,   795,   799,   803,   807,   811,   815,
     819,   823,   827,   831,   835,   839,   843,   847,   851,   855,
     859,   863,   867,   870,   874,   877,   881,   884,   888,   891,
     895,   899,   903,   907,   911,   915,   919,   923,   927,   931,
     935,   939,   943,   947,   951,   955,   959,   963,   967,   971,
     975,   979,   983,   987,   991,   995,   999,  1003,  1007,  1011,
    1015,  1019,  1023,  1027,  1031,  1035,  1039,  1043,  1047,  1051,
    1055,  1059,  1063,  1067,  1071,  1075,  1079,  1083,  1087,  1091,
    1095,  1099,  1103,  1107,  1111,  1115,  1119,  1123,  1127,  1131,
    1135,  1139,  1143,  1147,  1155,  1159,  1163,  1167,  1171,  1175,
    1179,  1183,  1187,  1191,  1195,  1199,  1203,  1207,  1211,  1215,
    1219,  1223,  1227,  1231,  1235,  1239,  1243,  1247,  1251,  1255,
    1259,  1263,  1267,  1271,  1275,  1279,  1283,  1287,  1291,  1295,
    1299,  1303,  1307,  1311,  1315,  1319,  1323,  1327,  1331,  1334,
    1338,  1342,  1346,  1350,  1354,  1358,  1362,  1366,  1370,  1374,
    1378,  1382,  1386,  1390,  1394,  1398,  1402,  1406,  1410,  1414,
    1418,  1422,  1426,  1430,  1434,  1438,  1442,  1446,  1450,  1454,
    1458,  1462,  1466,  1470,  1474,  1478,  1482,  1484,  1487,  1489,
    1491,  1493,  1495,  1497,  1503,  1509,  1517,  1525,  1531,  1540,
    1549,  1552,  1555,  1558,  1561,  1565,  1569,  1578,  1587,  1590,
    1593,  1596,  1600,  1604,  1606,  1608,  1616,  1618,  1620,  1624,
    1626,  1628,  1630,  1632,  1634,  1639,  1647,  1650,  1653,  1658,
    1666,  1669,  1671,  1673,  1674,  1680,  1683,  1686,  1687,  1696,
    1702,  1707,  1715,  1718,  1723,  1731,  1734,  1742,  1745,  1748,
    1751,  1754,  1757,  1760,  1763,  1765,  1767,  1769,  1771,  1773,
    1775,  1777,  1779,  1781,  1783,  1785,  1787,  1789,  1791,  1793,
    1795,  1797,  1799,  1801,  1803,  1805,  1807,  1809,  1811,  1813,
    1815,  1817,  1819,  1821,  1823,  1825,  1827,  1829,  1831,  1833,
    1835,  1837,  1841,  1845,  1849,  1852,  1856,  1860,  1864,  1867,
    1871,  1875,  1879,  1883,  1886,  1890,  1894,  1898,  1902,  1906,
    1910,  1914,  1918,  1922,  1926,  1930,  1933,  1937,  1941,  1945,
    1948,  1952,  1956,  1958,  1962,  1964,  1968,  1972,  1976,  1980,
    1982,  1984,  1986,  1988,  1992,  1996,  2000,  2004,  2006,  2008,
    2012,  2015,  2017,  2020,  2023,  2025,  2027,  2029,  2032,  2035,
    2037,  2040,  2044,  2050,  2052,  2057,  2063,  2067,  2072,  2076,
    2079,  2084,  2090,  2094,  2099,  2104,  2107,  2109,  2115,  2120,
    2123,  2129,  2133,  2135,  2140,  2145,  2149,  2151,  2152,  2156,
    2158,  2160,  2162,  2164,  2166,  2168,  2170,  2172,  2174,  2176,
    2178,  2182,  2184,  2187,  2193,  2198,  2200,  2202,  2204,  2206,
    2208,  2210,  2212,  2214,  2216,  2218,  2220,  2222,  2224,  2226,
    2228,  2230,  2232,  2234,  2236,  2238,  2240,  2242,  2246,  2250,
    2254,  2258,  2260,  2262,  2264,  2266,  2269,  2272,  2275,  2279,
    2283,  2287,  2291,  2295,  2299,  2303,  2307,  2311,  2315,  2319,
    2323,  2327,  2331,  2335,  2340,  2345,  2348,  2351,  2354,  2357,
    2361,  2365,  2369,  2373,  2377,  2381,  2385,  2389,  2393,  2397,
    2401,  2406,  2411,  2414,  2418,  2420,  2422,  2424,  2428,  2433,
    2438,  2443,  2450,  2457,  2464,  2471,  2478,  2483,  2486,  2491,
    2496,  2501,  2506,  2513,  2520,  2527,  2534,  2541,  2546,  2549,
    2554,  2559,  2564,  2569,  2576,  2583,  2590,  2597,  2604,  2609,
    2612,  2617,  2622,  2627,  2632,  2639,  2646,  2653,  2660,  2667,
    2672,  2675,  2680,  2685,  2690,  2695,  2702,  2709,  2716,  2723,
    2730,  2735,  2738,  2743,  2748,  2755,  2758,  2763,  2768,  2773,
    2776,  2781,  2786,  2789,  2794,  2799,  2802,  2809,  2816,  2823,
    2828,  2831,  2838,  2841,  2846,  2851,  2856,  2859,  2864,  2869,
    2874,  2877,  2882,  2887,  2890,  2895,  2900,  2903,  2908,  2913,
    2916,  2921,  2925,  2928,  2933,  2937,  2940,  2945,  2949,  2954,
    2957,  2962,  2967,  2970,  2975,  2980,  2983,  2988,  2993,  2996,
    3001,  3006,  3009,  3014,  3019,  3022,  3027,  3031,  3033,  3037,
    3039,  3043,  3045,  3050,  3054,  3056,  3061,  3066,  3071,  3076,
    3081,  3084,  3089,  3094,  3097,  3102,  3107,  3110,  3114,  3116,
    3120,  3122,  3126,  3128,  3132,  3134,  3141,  3148,  3151,  3156,
    3161,  3164,  3169,  3170,  3176,  3179,  3180,  3184,  3186,  3188,
    3192,  3195,  3197,  3201,  3204,  3206,  3208,  3212,  3215
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     330,     0,    -1,   331,    -1,   331,   332,    -1,   332,    -1,
     331,     1,    -1,   355,    -1,   375,    -1,   348,    -1,   352,
      -1,   359,    -1,    -1,   333,   366,    -1,    -1,   334,   367,
      -1,   369,    -1,    -1,   335,   372,    -1,    -1,   336,   373,
      -1,    -1,   337,   374,    -1,   320,    -1,   327,    -1,   360,
      -1,   314,    -1,   390,    -1,   338,    -1,   338,   319,   339,
      -1,   322,   339,   321,    -1,   338,    -1,    88,    -1,    89,
      -1,    90,    -1,    91,    -1,   301,    -1,    88,    -1,    89,
      -1,    90,    -1,    91,    -1,    92,    -1,    93,    -1,   301,
      -1,   311,    -1,   301,    -1,   338,    -1,   338,   328,   343,
      -1,   341,   328,   338,    -1,   341,   328,   338,   328,   343,
      -1,   338,   328,     1,    -1,   340,    -1,   340,   328,   343,
      -1,   341,   328,   340,    -1,   341,   328,   340,   328,   343,
      -1,   340,   328,     1,    -1,   345,    -1,   345,   346,    -1,
     311,    -1,   297,   311,    -1,   261,   349,    -1,   261,     1,
      -1,   350,    -1,   350,   319,   349,    -1,   351,    -1,   351,
     328,   311,    -1,   314,    -1,   312,    -1,   262,   353,    -1,
     262,     1,    -1,   354,    -1,   354,   319,   353,    -1,   351,
      -1,    94,   278,   347,    -1,    94,   278,     1,    -1,    95,
     278,   311,    -1,    95,   278,     1,    -1,    96,   278,   311,
      -1,    96,   278,     1,    -1,    97,   278,   311,    -1,    97,
     278,     1,    -1,    98,   278,   311,    -1,    98,   278,     1,
      -1,    99,   278,   312,    -1,    99,   278,     1,    -1,   100,
     278,   314,    -1,   100,   278,     1,    -1,   101,   278,   311,
      -1,   101,   278,     1,    -1,   102,   278,   314,    -1,   102,
     278,     1,    -1,   103,   278,   311,    -1,   103,   278,     1,
      -1,   104,   278,   314,    -1,   104,   278,     1,    -1,   105,
     278,   314,    -1,   105,   278,     1,    -1,   110,   278,   311,
      -1,   110,   278,     1,    -1,   111,   278,   311,    -1,   111,
     278,     1,    -1,   112,   278,   311,    -1,   112,     1,    -1,
     113,   278,   311,    -1,   113,     1,    -1,   114,   278,   311,
      -1,   114,     1,    -1,   115,   278,   347,    -1,   115,     1,
      -1,   116,   278,   347,    -1,   116,     1,    -1,   117,   278,
     347,    -1,   117,     1,    -1,   118,   278,   347,    -1,   118,
       1,    -1,   119,   278,   311,    -1,   119,     1,    -1,   120,
     278,   311,    -1,   120,     1,    -1,   121,   278,   311,    -1,
     121,     1,    -1,   122,   278,   311,    -1,   122,     1,    -1,
     123,   278,   311,    -1,   123,     1,    -1,   124,   278,   311,
      -1,   124,     1,    -1,   125,   278,   311,    -1,   125,     1,
      -1,   126,   278,   311,    -1,   126,     1,    -1,   127,   278,
     311,    -1,   127,     1,    -1,   128,   278,   311,    -1,   128,
       1,    -1,   129,   278,   311,    -1,   129,     1,    -1,   131,
     278,   311,    -1,   131,     1,    -1,   130,   278,   311,    -1,
     130,     1,    -1,   132,   278,   311,    -1,   132,     1,    -1,
     133,   278,   311,    -1,   133,     1,    -1,   134,   278,   311,
      -1,   134,     1,    -1,   135,   278,   311,    -1,   135,     1,
      -1,   136,   278,   311,    -1,   136,     1,    -1,   137,   278,
     311,    -1,   137,     1,    -1,   138,   278,   311,    -1,   138,
       1,    -1,   139,   278,   311,    -1,   139,     1,    -1,   140,
     278,   311,    -1,   140,     1,    -1,   141,   278,   311,    -1,
     141,     1,    -1,   142,   278,   311,    -1,   142,     1,    -1,
     143,   278,   311,    -1,   143,     1,    -1,   144,   278,   311,
      -1,   144,     1,    -1,   145,   278,   311,    -1,   145,     1,
      -1,   146,   278,   311,    -1,   147,   278,   314,    -1,   170,
     278,   311,    -1,   170,   278,     1,    -1,   171,   278,   311,
      -1,   171,   278,     1,    -1,   146,   278,     1,    -1,   148,
     278,   311,    -1,   148,   278,     1,    -1,   149,   278,   311,
      -1,   149,   278,     1,    -1,   150,   278,   311,    -1,   150,
     278,     1,    -1,   151,   278,   311,    -1,   151,   278,     1,
      -1,   152,   278,   311,    -1,   152,   278,     1,    -1,   153,
     278,   311,    -1,   153,   278,     1,    -1,   154,   278,   347,
      -1,   154,   278,     1,    -1,   155,   278,   347,    -1,   155,
     278,     1,    -1,   156,   278,   347,    -1,   156,   278,     1,
      -1,   157,   278,   347,    -1,   157,   278,     1,    -1,   158,
     278,   347,    -1,   158,   278,     1,    -1,   159,   278,   347,
      -1,   159,   278,     1,    -1,   160,   278,   347,    -1,   160,
     278,     1,    -1,   161,   278,   311,    -1,   161,   278,     1,
      -1,   250,   278,   314,    -1,   250,   278,     1,    -1,   172,
     278,   314,    -1,   172,   278,   312,    -1,   172,   278,     1,
      -1,   173,   278,   314,    -1,   173,   278,   312,    -1,   173,
     278,     1,    -1,   174,   278,   314,    -1,   174,   278,   312,
      -1,   174,   278,     1,    -1,   175,   278,   314,    -1,   175,
     278,   312,    -1,   175,   278,     1,    -1,   176,   278,   314,
      -1,   176,   278,   312,    -1,   176,   278,     1,    -1,   177,
     278,   311,    -1,   177,   278,     1,    -1,   178,   278,   311,
      -1,   178,   278,     1,    -1,   179,   278,   311,    -1,   179,
     278,     1,    -1,   180,   278,   311,    -1,   180,   278,     1,
      -1,   181,   278,   347,    -1,   181,   278,     1,    -1,   182,
     278,   347,    -1,   182,   278,     1,    -1,   183,   278,   347,
      -1,   183,   278,     1,    -1,   184,   278,   312,    -1,   184,
     278,   314,    -1,   184,   278,     1,    -1,   185,   278,   311,
      -1,   185,   278,     1,    -1,   186,   278,   311,    -1,   186,
     278,     1,    -1,   187,   278,   311,    -1,   187,   278,     1,
      -1,   188,   278,   361,    -1,   188,   278,     1,    -1,   189,
     278,   363,    -1,   189,   278,     1,    -1,   190,   278,   311,
      -1,   190,   278,     1,    -1,   191,   278,   311,    -1,   191,
     278,     1,    -1,   192,   278,   311,    -1,   192,     1,    -1,
     193,   278,   311,    -1,   193,     1,    -1,   194,   278,   311,
      -1,   194,     1,    -1,   195,   278,   311,    -1,   195,     1,
      -1,   196,   278,   311,    -1,   196,   278,     1,    -1,   197,
     278,   311,    -1,   197,   278,     1,    -1,   198,   278,   311,
      -1,   198,   278,     1,    -1,   199,   278,   311,    -1,   199,
     278,     1,    -1,   200,   278,   311,    -1,   200,   278,     1,
      -1,   201,   278,   311,    -1,   201,   278,     1,    -1,   202,
     278,   311,    -1,   202,   278,     1,    -1,   203,   278,   311,
      -1,   203,   278,     1,    -1,   204,   278,   311,    -1,   204,
     278,     1,    -1,   205,   278,   311,    -1,   205,   278,     1,
      -1,   206,   278,   311,    -1,   206,   278,     1,    -1,   207,
     278,   311,    -1,   207,   278,     1,    -1,   208,   278,   311,
      -1,   208,   278,     1,    -1,   209,   278,   311,    -1,   209,
     278,     1,    -1,   210,   278,   311,    -1,   210,   278,     1,
      -1,   211,   278,   214,    -1,   211,   278,   215,    -1,   211,
     278,   216,    -1,   211,   278,   217,    -1,   211,   278,     1,
      -1,   218,   278,   311,    -1,   218,   278,     1,    -1,   219,
     278,   311,    -1,   219,   278,     1,    -1,   220,   278,   314,
      -1,   220,   278,     1,    -1,   221,   278,   314,    -1,   221,
     278,     1,    -1,   222,   278,   314,    -1,   222,   278,     1,
      -1,   212,   278,   311,    -1,   212,   278,     1,    -1,   213,
     278,   311,    -1,   213,   278,     1,    -1,   223,   278,   311,
      -1,   223,   278,     1,    -1,   224,   278,   311,    -1,   224,
     278,     1,    -1,   225,   278,   311,    -1,   225,   278,     1,
      -1,   162,   278,   311,    -1,   162,   278,     1,    -1,   163,
     278,   314,    -1,   163,   278,     1,    -1,   164,   278,   314,
      -1,   164,   278,     1,    -1,   165,   278,   311,    -1,   165,
     278,     1,    -1,   106,   278,   346,    -1,   106,   278,   346,
     107,   338,   328,   311,    -1,   106,   278,     1,    -1,   108,
     278,   346,    -1,   108,   278,     1,    -1,   109,   278,   311,
      -1,   109,   278,     1,    -1,   226,   278,   338,    -1,   226,
     278,     1,    -1,   227,   278,   311,    -1,   227,   278,     1,
      -1,   228,   278,   311,    -1,   228,   278,     1,    -1,   229,
     278,   311,    -1,   229,   278,     1,    -1,   230,   278,   311,
      -1,   230,   278,     1,    -1,   231,   278,   311,    -1,   231,
     278,     1,    -1,   232,   278,   311,    -1,   232,   278,     1,
      -1,   233,   278,   311,    -1,   233,   278,     1,    -1,   234,
     278,   311,    -1,   234,   278,     1,    -1,   235,   278,   311,
      -1,   235,   278,     1,    -1,   236,   278,   311,    -1,   236,
     278,     1,    -1,   237,   278,   311,    -1,   237,   278,     1,
      -1,   238,   278,   311,    -1,   238,   278,     1,    -1,   239,
     278,   311,    -1,   239,   278,     1,    -1,   240,   278,   311,
      -1,   240,   278,     1,    -1,   241,   278,   311,    -1,   241,
     278,     1,    -1,   242,   278,   312,    -1,   242,   278,   314,
      -1,   242,   278,     1,    -1,   243,   278,   311,    -1,   243,
     278,   312,    -1,   243,   278,     1,    -1,   244,   278,   311,
      -1,   244,     1,    -1,   245,   278,   311,    -1,   245,   278,
       1,    -1,   246,   278,   311,    -1,   246,   278,     1,    -1,
     247,   278,   311,    -1,   247,   278,     1,    -1,   248,   278,
     311,    -1,   248,   278,     1,    -1,   249,   278,   311,    -1,
     249,   278,     1,    -1,   252,   278,   311,    -1,   253,   278,
     311,    -1,   254,   278,   311,    -1,   256,   278,   347,    -1,
     256,   278,     1,    -1,   255,   278,   347,    -1,   255,   278,
       1,    -1,   257,   278,   311,    -1,   257,   278,     1,    -1,
     258,   278,   311,    -1,   258,   278,     1,    -1,   259,   278,
     311,    -1,   259,   278,     1,    -1,   260,   278,   311,    -1,
     260,   278,     1,    -1,    41,   278,   311,    -1,    41,   278,
       1,    -1,    38,   278,   311,    -1,    38,   278,     1,    -1,
      42,   278,   341,    -1,    42,   278,     1,    -1,    43,   278,
     347,    -1,    43,   278,     1,    -1,    44,   278,   311,    -1,
      44,   278,     1,    -1,    45,   278,   311,    -1,    45,   278,
       1,    -1,   358,    -1,     1,   278,    -1,   312,    -1,    57,
      -1,   312,    -1,    57,    -1,   311,    -1,   356,   308,   357,
     278,   311,    -1,   356,   308,   357,   278,   314,    -1,   356,
     308,   357,   278,   311,   251,   314,    -1,   356,   308,   357,
     278,   314,   251,   314,    -1,   356,   308,   357,   278,     1,
      -1,   356,   325,   311,   326,   308,   357,   278,   311,    -1,
     356,   325,   311,   326,   308,   357,   278,   314,    -1,   166,
     314,    -1,   166,     1,    -1,   167,   314,    -1,   167,     1,
      -1,   167,   278,   314,    -1,   167,   278,     1,    -1,   168,
     322,   314,   319,   314,   319,   314,   321,    -1,   168,   322,
     314,   319,   314,   319,   347,   321,    -1,   168,     1,    -1,
     169,   314,    -1,   169,     1,    -1,   169,   278,   314,    -1,
     169,   278,     1,    -1,   361,    -1,   363,    -1,   311,   308,
     311,   308,   311,   308,   311,    -1,   315,    -1,   362,    -1,
     325,   362,   326,    -1,   311,    -1,   312,    -1,   314,    -1,
      14,    -1,    15,    -1,   365,   323,   393,   324,    -1,    14,
     325,   364,   326,   323,   393,   324,    -1,    14,     1,    -1,
      15,     1,    -1,    16,   323,   393,   324,    -1,    16,   325,
     364,   326,   323,   393,   324,    -1,    16,     1,    -1,    17,
      -1,    18,    -1,    -1,   368,   323,   370,   393,   324,    -1,
      17,     1,    -1,    18,     1,    -1,    -1,    17,   325,   364,
     326,   371,   323,   393,   324,    -1,    17,   325,   364,   326,
       1,    -1,    19,   323,   393,   324,    -1,    19,   325,   364,
     326,   323,   393,   324,    -1,    19,     1,    -1,    20,   323,
     393,   324,    -1,    20,   325,   364,   326,   323,   393,   324,
      -1,    20,     1,    -1,    21,   325,   318,   326,   323,   393,
     324,    -1,    21,     1,    -1,   275,   314,    -1,   275,     1,
      -1,   276,   314,    -1,   276,     1,    -1,   277,   314,    -1,
     277,     1,    -1,   292,    -1,   291,    -1,   287,    -1,   286,
      -1,   296,    -1,   295,    -1,   294,    -1,   293,    -1,   376,
      -1,   290,    -1,   292,    -1,   291,    -1,   289,    -1,   288,
      -1,   287,    -1,   286,    -1,   290,    -1,   296,    -1,   295,
      -1,   294,    -1,   293,    -1,    71,    -1,    72,    -1,    73,
      -1,    81,    -1,    79,    -1,    83,    -1,    75,    -1,    77,
      -1,    85,    -1,    87,    -1,   382,    -1,    80,    -1,    78,
      -1,    74,    -1,    76,    -1,   384,    -1,    70,   378,   421,
      -1,    70,   378,   312,    -1,    70,   378,     1,    -1,    70,
       1,    -1,   381,   378,   421,    -1,   381,   378,    86,    -1,
     381,   378,     1,    -1,   381,     1,    -1,   383,   377,   421,
      -1,   383,   376,   421,    -1,   383,   377,     1,    -1,   383,
     376,     1,    -1,   383,     1,    -1,    84,   376,   342,    -1,
      84,   376,   421,    -1,    84,   376,     1,    -1,    82,   376,
     342,    -1,    82,   376,   421,    -1,    82,   376,     1,    -1,
     385,   378,   387,    -1,   385,   378,   421,    -1,   385,   378,
     388,    -1,   385,   378,    86,    -1,   385,   378,     1,    -1,
     385,     1,    -1,    86,   376,   381,    -1,    86,   376,   385,
      -1,    86,   376,     1,    -1,    86,     1,    -1,   360,   300,
     360,    -1,   360,   300,   311,    -1,   360,    -1,   360,   300,
       1,    -1,   312,    -1,   388,   308,   312,    -1,   388,   297,
     312,    -1,   388,   308,     1,    -1,   388,   297,     1,    -1,
     312,    -1,   313,    -1,   311,    -1,   389,    -1,   390,   308,
     389,    -1,   390,   297,   389,    -1,   390,   308,     1,    -1,
     390,   297,     1,    -1,   424,    -1,   394,    -1,   323,   393,
     324,    -1,   393,   394,    -1,   394,    -1,   393,     1,    -1,
     391,   320,    -1,   395,    -1,   399,    -1,   400,    -1,   428,
     320,    -1,   422,   320,    -1,   320,    -1,   391,     1,    -1,
      46,   421,   392,    -1,    46,   421,   392,    47,   392,    -1,
     421,    -1,    56,   396,   328,   393,    -1,    56,   300,   396,
     328,   393,    -1,    56,   396,   328,    -1,    56,   300,   396,
     328,    -1,    57,   328,   393,    -1,    57,   328,    -1,    56,
       1,   328,   393,    -1,    56,   300,     1,   328,   393,    -1,
      56,     1,   328,    -1,    56,   300,     1,   328,    -1,    56,
     396,   328,     1,    -1,   398,   397,    -1,   397,    -1,    55,
     421,   323,   398,   324,    -1,    55,   421,   323,   324,    -1,
      55,     1,    -1,    55,   421,   323,     1,   324,    -1,    58,
     421,   392,    -1,   312,    -1,   312,   325,   347,   326,    -1,
     312,   325,   314,   326,    -1,   402,   308,   401,    -1,   401,
      -1,    -1,   264,   404,   402,    -1,   265,    -1,   266,    -1,
     267,    -1,   268,    -1,   269,    -1,   270,    -1,   271,    -1,
     272,    -1,   273,    -1,   312,    -1,   406,    -1,   405,   308,
     406,    -1,   263,    -1,   408,   407,    -1,   408,   407,   325,
     347,   326,    -1,   408,   407,   325,   326,    -1,   409,    -1,
     411,    -1,   409,    -1,   411,    -1,   410,    -1,   409,    -1,
     416,    -1,   314,    -1,   316,    -1,   317,    -1,   278,    -1,
     412,    -1,   415,    -1,   416,    -1,   347,    -1,   314,    -1,
     413,    -1,   415,    -1,   416,    -1,   403,    -1,   391,    -1,
     386,    -1,   323,   393,   324,    -1,   323,     1,   324,    -1,
     322,   422,   321,    -1,   322,     1,   321,    -1,   304,    -1,
     302,    -1,   297,    -1,   419,    -1,   420,   421,    -1,   307,
     421,    -1,   306,   421,    -1,   421,   298,   421,    -1,   421,
     297,   421,    -1,   421,   301,   421,    -1,   421,   300,   421,
      -1,   421,   299,   421,    -1,   421,   281,   421,    -1,   421,
     282,   421,    -1,   421,   283,   421,    -1,   421,   284,   421,
      -1,   421,   285,   421,    -1,   421,   380,   421,    -1,   421,
     379,   421,    -1,   421,   280,   421,    -1,   421,   279,   421,
      -1,   322,   421,   321,    -1,   309,   322,   421,   321,    -1,
     310,   322,   421,   321,    -1,   305,   421,    -1,   420,     1,
      -1,   307,     1,    -1,   306,     1,    -1,   421,   298,     1,
      -1,   421,   297,     1,    -1,   421,   301,     1,    -1,   421,
     300,     1,    -1,   421,   299,     1,    -1,   421,   281,     1,
      -1,   421,   282,     1,    -1,   421,   380,     1,    -1,   421,
     379,     1,    -1,   421,   280,     1,    -1,   421,   279,     1,
      -1,   309,   322,     1,   321,    -1,   310,   322,     1,   321,
      -1,   305,     1,    -1,   418,   417,   421,    -1,    67,    -1,
      68,    -1,    69,    -1,     3,   322,   321,    -1,     3,   322,
     388,   321,    -1,     3,   322,   314,   321,    -1,     3,   322,
     360,   321,    -1,     3,   322,   388,   319,   311,   321,    -1,
       3,   322,   314,   319,   311,   321,    -1,     3,   322,   360,
     319,   311,   321,    -1,     3,   322,    61,   319,    62,   321,
      -1,     3,   322,    61,   319,   311,   321,    -1,     3,   322,
      61,   321,    -1,     3,     1,    -1,     3,   322,     1,   321,
      -1,     7,   322,   388,   321,    -1,     7,   322,   314,   321,
      -1,     7,   322,   360,   321,    -1,     7,   322,   388,   319,
     311,   321,    -1,     7,   322,   314,   319,   311,   321,    -1,
       7,   322,   360,   319,   311,   321,    -1,     7,   322,    61,
     319,    62,   321,    -1,     7,   322,    61,   319,   311,   321,
      -1,     7,   322,    61,   321,    -1,     7,     1,    -1,     7,
     322,     1,   321,    -1,     4,   322,   388,   321,    -1,     4,
     322,   314,   321,    -1,     4,   322,   360,   321,    -1,     4,
     322,   388,   319,   311,   321,    -1,     4,   322,   314,   319,
     311,   321,    -1,     4,   322,   360,   319,   311,   321,    -1,
       4,   322,    61,   319,    62,   321,    -1,     4,   322,    61,
     319,   311,   321,    -1,     4,   322,    61,   321,    -1,     4,
       1,    -1,     4,   322,     1,   321,    -1,     5,   322,   388,
     321,    -1,     5,   322,   314,   321,    -1,     5,   322,   360,
     321,    -1,     5,   322,   388,   319,   311,   321,    -1,     5,
     322,   314,   319,   311,   321,    -1,     5,   322,   360,   319,
     311,   321,    -1,     5,   322,    61,   319,    62,   321,    -1,
       5,   322,    61,   319,   311,   321,    -1,     5,   322,    61,
     321,    -1,     5,     1,    -1,     5,   322,     1,   321,    -1,
       6,   322,   388,   321,    -1,     6,   322,   314,   321,    -1,
       6,   322,   360,   321,    -1,     6,   322,   388,   319,   311,
     321,    -1,     6,   322,   314,   319,   311,   321,    -1,     6,
     322,   360,   319,   311,   321,    -1,     6,   322,    61,   319,
      62,   321,    -1,     6,   322,    61,   319,   311,   321,    -1,
       6,   322,    61,   321,    -1,     6,     1,    -1,     6,   322,
       1,   321,    -1,    12,   322,   314,   321,    -1,    12,   322,
     311,   319,   314,   321,    -1,    12,     1,    -1,    12,   322,
       1,   321,    -1,    64,   322,   311,   321,    -1,    64,   322,
     351,   321,    -1,    64,     1,    -1,    65,   322,   311,   321,
      -1,    65,   322,   351,   321,    -1,    65,     1,    -1,    66,
     322,   311,   321,    -1,    66,   322,   351,   321,    -1,    66,
       1,    -1,   423,   322,   414,   319,   351,   321,    -1,   423,
     322,   414,   319,     1,   321,    -1,   423,   322,     1,   319,
     351,   321,    -1,   423,   322,     1,   321,    -1,   423,     1,
      -1,    13,   322,   314,   319,   314,   321,    -1,    13,     1,
      -1,    13,   322,     1,   321,    -1,    14,   322,   421,   321,
      -1,    14,   322,   312,   321,    -1,    14,     1,    -1,    14,
     322,     1,   321,    -1,    22,   322,   314,   321,    -1,    23,
     322,   314,   321,    -1,    23,     1,    -1,    23,   322,     1,
     321,    -1,    26,   322,   314,   321,    -1,    26,     1,    -1,
      26,   322,     1,   321,    -1,    28,   322,   311,   321,    -1,
      28,     1,    -1,    28,   322,     1,   321,    -1,    27,   322,
     311,   321,    -1,    27,     1,    -1,    27,   322,     1,   321,
      -1,    29,   322,   321,    -1,    29,     1,    -1,    31,   322,
     347,   321,    -1,    31,   322,   321,    -1,    31,     1,    -1,
      31,   322,     1,   321,    -1,    32,   322,   321,    -1,    24,
     322,   314,   321,    -1,    24,     1,    -1,    24,   322,     1,
     321,    -1,    25,   322,   314,   321,    -1,    25,     1,    -1,
      25,   322,     1,   321,    -1,    35,   322,   314,   321,    -1,
      35,     1,    -1,    35,   322,     1,   321,    -1,    33,   322,
     314,   321,    -1,    33,     1,    -1,    33,   322,     1,   321,
      -1,    34,   322,   314,   321,    -1,    34,     1,    -1,    34,
     322,     1,   321,    -1,    36,   322,   314,   321,    -1,    36,
       1,    -1,    36,   322,     1,   321,    -1,    37,   322,   321,
      -1,    37,    -1,    38,   322,   321,    -1,    38,    -1,    39,
     322,   321,    -1,    39,    -1,    40,   322,   311,   321,    -1,
      40,   322,   321,    -1,    40,    -1,    40,   322,     1,   321,
      -1,    42,   322,   341,   321,    -1,    42,   322,     1,   321,
      -1,    48,   322,   338,   321,    -1,    48,   322,     1,   321,
      -1,    48,     1,    -1,    49,   322,   311,   321,    -1,    49,
     322,     1,   321,    -1,    49,     1,    -1,    50,   322,   344,
     321,    -1,    50,   322,     1,   321,    -1,    50,     1,    -1,
      51,   322,   321,    -1,    51,    -1,    52,   322,   321,    -1,
      52,    -1,    53,   322,   321,    -1,    53,    -1,    54,   322,
     321,    -1,    54,    -1,    59,   322,   314,   319,   311,   321,
      -1,    59,   322,   314,   319,   421,   321,    -1,    59,     1,
      -1,    59,   322,     1,   321,    -1,    60,   322,   314,   321,
      -1,    60,     1,    -1,    60,   322,     1,   321,    -1,    -1,
     312,   425,   322,   426,   321,    -1,   312,     1,    -1,    -1,
     426,   319,   427,    -1,   427,    -1,   421,    -1,     9,   322,
     321,    -1,     9,   421,    -1,     9,    -1,     8,   322,   321,
      -1,     8,   421,    -1,     8,    -1,    10,    -1,    10,   322,
     321,    -1,    10,   421,    -1,    11,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   606,   606,   609,   610,   611,   614,   615,   616,   617,
     618,   619,   619,   620,   620,   621,   622,   622,   623,   623,
     624,   624,   625,   626,   629,   645,   653,   667,   668,   674,
     675,   679,   680,   681,   682,   683,   686,   687,   688,   689,
     690,   691,   692,   695,   696,   699,   700,   701,   702,   703,
     707,   708,   709,   710,   711,   715,   716,   719,   720,   723,
     724,   726,   727,   730,   733,   739,   740,   744,   745,   748,
     749,   752,   758,   759,   760,   761,   762,   763,   764,   765,
     766,   769,   770,   776,   777,   778,   779,   780,   781,   782,
     783,   784,   785,   786,   787,   788,   789,   790,   791,   792,
     793,   794,   795,   796,   797,   798,   799,   800,   801,   802,
     803,   804,   805,   807,   808,   809,   810,   811,   812,   813,
     814,   815,   816,   817,   818,   819,   820,   821,   822,   823,
     824,   825,   826,   827,   828,   829,   830,   831,   832,   833,
     834,   835,   836,   837,   838,   839,   840,   841,   842,   843,
     844,   845,   846,   849,   850,   853,   854,   857,   858,   859,
     860,   863,   864,   867,   868,   871,   872,   875,   876,   877,
     882,   883,   884,   885,   886,   887,   888,   889,   890,   891,
     892,   893,   894,   895,   896,   897,   898,   899,   900,   901,
     902,   903,   904,   905,   906,   907,   908,   909,   910,   911,
     912,   913,   914,   915,   918,   919,   926,   933,   934,   935,
     936,   937,   938,   939,   940,   941,   942,   943,   944,   945,
     946,   947,   948,   955,   956,   963,   964,   971,   972,   979,
     980,   987,   988,   998,   999,  1013,  1027,  1028,  1035,  1036,
    1043,  1044,  1051,  1052,  1061,  1062,  1071,  1072,  1079,  1080,
    1087,  1088,  1095,  1096,  1103,  1104,  1111,  1112,  1119,  1120,
    1127,  1128,  1135,  1136,  1143,  1144,  1151,  1152,  1159,  1160,
    1167,  1168,  1175,  1176,  1183,  1184,  1191,  1192,  1199,  1200,
    1207,  1208,  1215,  1216,  1223,  1224,  1231,  1232,  1239,  1240,
    1247,  1254,  1261,  1268,  1275,  1282,  1283,  1290,  1291,  1298,
    1299,  1306,  1307,  1314,  1315,  1322,  1323,  1330,  1331,  1338,
    1339,  1346,  1347,  1354,  1355,  1356,  1357,  1360,  1361,  1364,
    1365,  1366,  1367,  1379,  1392,  1394,  1405,  1406,  1407,  1408,
    1414,  1415,  1425,  1426,  1427,  1428,  1429,  1430,  1437,  1438,
    1445,  1446,  1447,  1448,  1449,  1450,  1451,  1452,  1453,  1454,
    1455,  1456,  1457,  1458,  1459,  1460,  1461,  1462,  1469,  1470,
    1477,  1478,  1485,  1492,  1493,  1494,  1521,  1522,  1523,  1524,
    1525,  1526,  1527,  1528,  1529,  1530,  1531,  1532,  1533,  1534,
    1535,  1536,  1537,  1538,  1539,  1540,  1541,  1542,  1543,  1544,
    1545,  1546,  1547,  1548,  1549,  1550,  1551,  1553,  1554,  1556,
    1558,  1559,  1560,  1563,  1564,  1567,  1568,  1569,  1572,  1573,
    1576,  1577,  1578,  1586,  1591,  1596,  1601,  1606,  1609,  1614,
    1622,  1628,  1629,  1639,  1640,  1650,  1651,  1662,  1673,  1674,
    1680,  1681,  1687,  1691,  1692,  1695,  1724,  1739,  1740,  1744,
    1755,  1756,  1760,  1761,  1765,  1774,  1792,  1793,  1796,  1805,
    1823,  1827,  1828,  1833,  1833,  1842,  1843,  1845,  1844,  1869,
    1874,  1883,  1901,  1903,  1912,  1930,  1932,  1951,  1954,  1955,
    1956,  1957,  1958,  1959,  1981,  1982,  1983,  1984,  1987,  1988,
    1989,  1990,  1993,  1994,  2000,  2001,  2002,  2003,  2004,  2005,
    2006,  2009,  2010,  2011,  2012,  2019,  2020,  2021,  2028,  2029,
    2030,  2034,  2035,  2036,  2037,  2038,  2043,  2044,  2047,  2048,
    2049,  2055,  2057,  2059,  2060,  2062,  2064,  2066,  2068,  2070,
    2071,  2073,  2074,  2075,  2076,  2078,  2080,  2082,  2084,  2086,
    2088,  2089,  2125,  2127,  2129,  2131,  2134,  2136,  2138,  2140,
    2144,  2145,  2156,  2157,  2161,  2162,  2178,  2194,  2195,  2198,
    2199,  2200,  2209,  2210,  2226,  2242,  2244,  2251,  2293,  2294,
    2297,  2298,  2299,  2302,  2303,  2304,  2305,  2306,  2307,  2308,
    2309,  2312,  2320,  2330,  2347,  2354,  2361,  2368,  2375,  2380,
    2385,  2386,  2387,  2388,  2389,  2392,  2401,  2408,  2433,  2449,
    2450,  2455,  2474,  2483,  2495,  2510,  2511,  2514,  2514,  2524,
    2525,  2526,  2527,  2528,  2529,  2530,  2531,  2532,  2535,  2538,
    2539,  2542,  2549,  2552,  2559,  2565,  2566,  2575,  2576,  2577,
    2580,  2581,  2593,  2617,  2628,  2659,  2663,  2673,  2687,  2699,
    2700,  2702,  2703,  2704,  2718,  2719,  2720,  2721,  2722,  2723,
    2724,  2728,  2729,  2730,  2743,  2749,  2750,  2751,  2752,  2753,
    2754,  2755,  2756,  2757,  2758,  2759,  2760,  2761,  2762,  2763,
    2781,  2782,  2783,  2784,  2785,  2786,  2787,  2788,  2789,  2790,
    2791,  2792,  2793,  2794,  2795,  2796,  2797,  2799,  2801,  2802,
    2803,  2804,  2805,  2808,  2826,  2827,  2828,  2831,  2832,  2833,
    2834,  2835,  2836,  2837,  2838,  2839,  2840,  2841,  2842,  2843,
    2844,  2845,  2846,  2847,  2848,  2849,  2850,  2851,  2852,  2853,
    2854,  2855,  2856,  2857,  2858,  2859,  2860,  2861,  2862,  2863,
    2864,  2865,  2873,  2881,  2889,  2897,  2905,  2913,  2921,  2929,
    2937,  2938,  2940,  2948,  2956,  2964,  2973,  2982,  2991,  2999,
    3008,  3016,  3017,  3019,  3022,  3023,  3024,  3025,  3032,  3039,
    3040,  3046,  3053,  3054,  3060,  3067,  3068,  3074,  3077,  3080,
    3081,  3082,  3085,  3086,  3087,  3096,  3105,  3106,  3107,  3108,
    3109,  3110,  3111,  3112,  3113,  3114,  3115,  3116,  3117,  3118,
    3119,  3120,  3121,  3122,  3126,  3130,  3131,  3132,  3133,  3134,
    3135,  3136,  3137,  3138,  3139,  3140,  3141,  3142,  3143,  3144,
    3145,  3146,  3147,  3148,  3149,  3150,  3151,  3152,  3153,  3154,
    3155,  3156,  3157,  3165,  3173,  3181,  3182,  3184,  3186,  3197,
    3198,  3199,  3215,  3216,  3217,  3221,  3224,  3225,  3228,  3231,
    3234,  3237,  3240,  3243,  3246,  3249,  3252,  3255,  3256,  3257,
    3260,  3261,  3262,  3262,  3290,  3292,  3294,  3295,  3298,  3315,
    3319,  3323,  3327,  3332,  3336,  3341,  3345,  3349,  3353
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "FORWARD", "FORWARD_TCP", "FORWARD_TLS",
  "FORWARD_SCTP", "FORWARD_UDP", "EXIT", "DROP", "RETURN", "BREAK",
  "LOG_TOK", "ERROR", "ROUTE", "ROUTE_REQUEST", "ROUTE_FAILURE",
  "ROUTE_ONREPLY", "ROUTE_REPLY", "ROUTE_BRANCH", "ROUTE_SEND",
  "ROUTE_EVENT", "EXEC", "SET_HOST", "SET_HOSTPORT", "SET_HOSTPORTTRANS",
  "PREFIX", "STRIP", "STRIP_TAIL", "SET_USERPHONE", "APPEND_BRANCH",
  "REMOVE_BRANCH", "CLEAR_BRANCHES", "SET_USER", "SET_USERPASS",
  "SET_PORT", "SET_URI", "REVERT_URI", "FORCE_RPORT", "ADD_LOCAL_RPORT",
  "FORCE_TCP_ALIAS", "UDP_MTU", "UDP_MTU_TRY_PROTO", "UDP4_RAW",
  "UDP4_RAW_MTU", "UDP4_RAW_TTL", "IF", "ELSE", "SET_ADV_ADDRESS",
  "SET_ADV_PORT", "FORCE_SEND_SOCKET", "SET_FWD_NO_CONNECT",
  "SET_RPL_NO_CONNECT", "SET_FWD_CLOSE", "SET_RPL_CLOSE", "SWITCH", "CASE",
  "DEFAULT", "WHILE", "CFG_SELECT", "CFG_RESET", "URIHOST", "URIPORT",
  "MAX_LEN", "SETFLAG", "RESETFLAG", "ISFLAGSET", "SETAVPFLAG",
  "RESETAVPFLAG", "ISAVPFLAGSET", "METHOD", "URI", "FROM_URI", "TO_URI",
  "SRCIP", "SRCPORT", "DSTIP", "DSTPORT", "TOIP", "TOPORT", "SNDIP",
  "SNDPORT", "SNDPROTO", "SNDAF", "PROTO", "AF", "MYSELF", "MSGLEN", "UDP",
  "TCP", "TLS", "SCTP", "WS", "WSS", "DEBUG_V", "FORK", "FORK_DELAY",
  "MODINIT_DELAY", "LOGSTDERROR", "LOGFACILITY", "LOGNAME", "LOGCOLOR",
  "LOGPREFIX", "LOGPREFIXMODE", "LOGENGINETYPE", "LOGENGINEDATA", "LISTEN",
  "ADVERTISE", "ALIAS", "SR_AUTO_ALIASES", "DNS", "REV_DNS",
  "DNS_TRY_IPV6", "DNS_TRY_NAPTR", "DNS_SRV_LB", "DNS_UDP_PREF",
  "DNS_TCP_PREF", "DNS_TLS_PREF", "DNS_SCTP_PREF", "DNS_RETR_TIME",
  "DNS_RETR_NO", "DNS_SERVERS_NO", "DNS_USE_SEARCH", "DNS_SEARCH_FMATCH",
  "DNS_NAPTR_IGNORE_RFC", "DNS_CACHE_INIT", "DNS_USE_CACHE",
  "DNS_USE_FAILOVER", "DNS_CACHE_FLAGS", "DNS_CACHE_NEG_TTL",
  "DNS_CACHE_MIN_TTL", "DNS_CACHE_MAX_TTL", "DNS_CACHE_MEM",
  "DNS_CACHE_GC_INT", "DNS_CACHE_DEL_NONEXP", "DNS_CACHE_REC_PREF",
  "AUTO_BIND_IPV6", "DST_BLST_INIT", "USE_DST_BLST", "DST_BLST_MEM",
  "DST_BLST_TTL", "DST_BLST_GC_INT", "DST_BLST_UDP_IMASK",
  "DST_BLST_TCP_IMASK", "DST_BLST_TLS_IMASK", "DST_BLST_SCTP_IMASK",
  "PORT", "STAT", "CHILDREN", "SOCKET_WORKERS", "ASYNC_WORKERS",
  "ASYNC_USLEEP", "CHECK_VIA", "PHONE2TEL", "MEMLOG", "MEMDBG", "MEMSUM",
  "MEMSAFETY", "MEMJOIN", "MEMSTATUSMODE", "CORELOG", "SIP_WARNING",
  "SERVER_SIGNATURE", "SERVER_HEADER", "USER_AGENT_HEADER", "REPLY_TO_VIA",
  "LOADMODULE", "LOADPATH", "MODPARAM", "CFGENGINE", "MAXBUFFER",
  "SQL_BUFFER_SIZE", "USER", "GROUP", "CHROOT", "WDIR", "RUNDIR", "MHOMED",
  "DISABLE_TCP", "TCP_ACCEPT_ALIASES", "TCP_CHILDREN",
  "TCP_CONNECT_TIMEOUT", "TCP_SEND_TIMEOUT", "TCP_CON_LIFETIME",
  "TCP_POLL_METHOD", "TCP_MAX_CONNECTIONS", "TLS_MAX_CONNECTIONS",
  "TCP_NO_CONNECT", "TCP_SOURCE_IPV4", "TCP_SOURCE_IPV6",
  "TCP_OPT_FD_CACHE", "TCP_OPT_BUF_WRITE", "TCP_OPT_CONN_WQ_MAX",
  "TCP_OPT_WQ_MAX", "TCP_OPT_RD_BUF", "TCP_OPT_WQ_BLK",
  "TCP_OPT_DEFER_ACCEPT", "TCP_OPT_DELAYED_ACK", "TCP_OPT_SYNCNT",
  "TCP_OPT_LINGER2", "TCP_OPT_KEEPALIVE", "TCP_OPT_KEEPIDLE",
  "TCP_OPT_KEEPINTVL", "TCP_OPT_KEEPCNT", "TCP_OPT_CRLF_PING",
  "TCP_OPT_ACCEPT_NO_CL", "TCP_CLONE_RCVBUF", "DISABLE_TLS", "ENABLE_TLS",
  "TLSLOG", "TLS_PORT_NO", "TLS_METHOD", "TLS_HANDSHAKE_TIMEOUT",
  "TLS_SEND_TIMEOUT", "SSLv23", "SSLv2", "SSLv3", "TLSv1", "TLS_VERIFY",
  "TLS_REQUIRE_CERTIFICATE", "TLS_CERTIFICATE", "TLS_PRIVATE_KEY",
  "TLS_CA_LIST", "DISABLE_SCTP", "ENABLE_SCTP", "SCTP_CHILDREN",
  "ADVERTISED_ADDRESS", "ADVERTISED_PORT", "DISABLE_CORE", "OPEN_FD_LIMIT",
  "SHM_MEM_SZ", "SHM_FORCE_ALLOC", "MLOCK_PAGES", "REAL_TIME", "RT_PRIO",
  "RT_POLICY", "RT_TIMER1_PRIO", "RT_TIMER1_POLICY", "RT_TIMER2_PRIO",
  "RT_TIMER2_POLICY", "MCAST_LOOPBACK", "MCAST_TTL", "MCAST", "TOS",
  "PMTU_DISCOVERY", "KILL_TIMEOUT", "MAX_WLOOPS", "PVBUFSIZE",
  "PVBUFSLOTS", "HTTP_REPLY_PARSE", "VERSION_TABLE_CFG", "CFG_DESCRIPTION",
  "SERVER_ID", "MAX_RECURSIVE_LEVEL", "MAX_BRANCHES_PARAM",
  "LATENCY_CFG_LOG", "LATENCY_LOG", "LATENCY_LIMIT_DB",
  "LATENCY_LIMIT_ACTION", "MSG_TIME", "ONSEND_RT_REPLY", "FLAGS_DECL",
  "AVPFLAGS_DECL", "ATTR_MARK", "SELECT_MARK", "ATTR_FROM", "ATTR_TO",
  "ATTR_FROMURI", "ATTR_TOURI", "ATTR_FROMUSER", "ATTR_TOUSER",
  "ATTR_FROMDOMAIN", "ATTR_TODOMAIN", "ATTR_GLOBAL", "ADDEQ", "SUBST",
  "SUBSTDEF", "SUBSTDEFS", "EQUAL", "LOG_OR", "LOG_AND", "BIN_OR",
  "BIN_AND", "BIN_XOR", "BIN_LSHIFT", "BIN_RSHIFT", "STRDIFF", "STREQ",
  "INTDIFF", "INTEQ", "MATCH", "DIFF", "EQUAL_T", "LTE", "GTE", "LT", "GT",
  "MINUS", "PLUS", "MODULO", "SLASH", "STAR", "BIN_NOT", "UNARY", "NOT",
  "DEFINED", "STRCAST", "INTCAST", "DOT", "STRLEN", "STREMPTY", "NUMBER",
  "ID", "NUM_ID", "STRING", "IPV6ADDR", "PVAR", "AVP_OR_PVAR",
  "EVENT_RT_NAME", "COMMA", "SEMICOLON", "RPAREN", "LPAREN", "LBRACE",
  "RBRACE", "LBRACK", "RBRACK", "CR", "COLON", "$accept", "cfg",
  "statements", "statement", "@1", "@2", "@3", "@4", "@5", "listen_id",
  "listen_id_lst", "listen_id2", "proto", "eqproto", "port", "phostport",
  "listen_phostport", "id_lst", "intno", "flags_decl", "flag_list",
  "flag_spec", "flag_name", "avpflags_decl", "avpflag_list",
  "avpflag_spec", "assign_stm", "cfg_var_id", "cfg_var_idn", "cfg_var",
  "module_stm", "ip", "ipv4", "ipv6addr", "ipv6", "route_name",
  "route_main", "route_stm", "failure_route_stm", "route_reply_main",
  "onreply_route_stm", "@6", "@7", "branch_route_stm", "send_route_stm",
  "event_route_stm", "preprocess_stm", "equalop", "cmpop", "strop",
  "rve_equalop", "rve_cmpop", "uri_type", "eint_op_onsend", "eint_op",
  "eip_op_onsend", "eip_op", "exp_elem", "ipnet", "host", "host_if_id",
  "host_or_if", "fcmd", "stm", "actions", "action", "if_cmd", "ct_rval",
  "single_case", "case_stms", "switch_cmd", "while_cmd", "select_param",
  "select_params", "select_id", "@8", "attr_class_spec", "attr_name_spec",
  "attr_spec", "attr_mark", "attr_id", "attr_id_num_idx", "attr_id_no_idx",
  "attr_id_ass", "attr_id_any", "attr_id_any_str", "pvar", "avp_pvar",
  "assign_op", "lval", "rval", "rve_un_op", "rval_expr", "assign_action",
  "avpflag_oper", "cmd", "@9", "func_params", "func_param", "ret_cmd", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,   366,   367,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   406,   407,   408,   409,   410,   411,   412,   413,   414,
     415,   416,   417,   418,   419,   420,   421,   422,   423,   424,
     425,   426,   427,   428,   429,   430,   431,   432,   433,   434,
     435,   436,   437,   438,   439,   440,   441,   442,   443,   444,
     445,   446,   447,   448,   449,   450,   451,   452,   453,   454,
     455,   456,   457,   458,   459,   460,   461,   462,   463,   464,
     465,   466,   467,   468,   469,   470,   471,   472,   473,   474,
     475,   476,   477,   478,   479,   480,   481,   482,   483,   484,
     485,   486,   487,   488,   489,   490,   491,   492,   493,   494,
     495,   496,   497,   498,   499,   500,   501,   502,   503,   504,
     505,   506,   507,   508,   509,   510,   511,   512,   513,   514,
     515,   516,   517,   518,   519,   520,   521,   522,   523,   524,
     525,   526,   527,   528,   529,   530,   531,   532,   533,   534,
     535,   536,   537,   538,   539,   540,   541,   542,   543,   544,
     545,   546,   547,   548,   549,   550,   551,   552,   553,   554,
     555,   556,   557,   558,   559,   560,   561,   562,   563,   564,
     565,   566,   567,   568,   569,   570,   571,   572,   573,   574,
     575,   576,   577,   578,   579,   580,   581,   582,   583
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   329,   330,   331,   331,   331,   332,   332,   332,   332,
     332,   333,   332,   334,   332,   332,   335,   332,   336,   332,
     337,   332,   332,   332,   338,   338,   338,   339,   339,   340,
     340,   341,   341,   341,   341,   341,   342,   342,   342,   342,
     342,   342,   342,   343,   343,   344,   344,   344,   344,   344,
     345,   345,   345,   345,   345,   346,   346,   347,   347,   348,
     348,   349,   349,   350,   350,   351,   351,   352,   352,   353,
     353,   354,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   355,   355,
     355,   355,   355,   355,   355,   355,   355,   355,   356,   356,
     357,   357,   357,   358,   358,   358,   358,   358,   358,   358,
     359,   359,   359,   359,   359,   359,   359,   359,   359,   359,
     359,   359,   359,   360,   360,   361,   362,   363,   363,   364,
     364,   364,   365,   365,   366,   366,   366,   366,   367,   367,
     367,   368,   368,   370,   369,   369,   369,   371,   369,   369,
     372,   372,   372,   373,   373,   373,   374,   374,   375,   375,
     375,   375,   375,   375,   376,   376,   376,   376,   377,   377,
     377,   377,   378,   378,   379,   379,   379,   379,   379,   379,
     379,   380,   380,   380,   380,   381,   381,   381,   382,   382,
     382,   383,   383,   383,   383,   383,   384,   384,   385,   385,
     385,   386,   386,   386,   386,   386,   386,   386,   386,   386,
     386,   386,   386,   386,   386,   386,   386,   386,   386,   386,
     386,   386,   386,   386,   386,   386,   386,   386,   386,   386,
     387,   387,   387,   387,   388,   388,   388,   388,   388,   389,
     389,   389,   390,   390,   390,   390,   390,   391,   392,   392,
     393,   393,   393,   394,   394,   394,   394,   394,   394,   394,
     394,   395,   395,   396,   397,   397,   397,   397,   397,   397,
     397,   397,   397,   397,   397,   398,   398,   399,   399,   399,
     399,   400,   401,   401,   401,   402,   402,   404,   403,   405,
     405,   405,   405,   405,   405,   405,   405,   405,   406,   407,
     407,   408,   409,   410,   411,   412,   412,   413,   413,   413,
     414,   414,   414,   415,   416,   417,   418,   418,   418,   419,
     419,   419,   419,   419,   419,   419,   419,   419,   419,   419,
     419,   420,   420,   420,   421,   421,   421,   421,   421,   421,
     421,   421,   421,   421,   421,   421,   421,   421,   421,   421,
     421,   421,   421,   421,   421,   421,   421,   421,   421,   421,
     421,   421,   421,   421,   421,   421,   421,   421,   421,   421,
     421,   421,   421,   422,   423,   423,   423,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   424,   424,   424,   424,   424,   424,   424,   424,
     424,   424,   425,   424,   424,   426,   426,   426,   427,   428,
     428,   428,   428,   428,   428,   428,   428,   428,   428
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     1,     2,     1,     1,     1,     1,
       1,     0,     2,     0,     2,     1,     0,     2,     0,     2,
       0,     2,     1,     1,     1,     1,     1,     1,     3,     3,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     3,     3,     5,     3,
       1,     3,     3,     5,     3,     1,     2,     1,     2,     2,
       2,     1,     3,     1,     3,     1,     1,     2,     2,     1,
       3,     1,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     2,     3,     2,     3,     2,     3,     2,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     2,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     2,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     2,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     2,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     2,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     2,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     2,     3,     2,     3,     2,     3,     2,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     7,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     2,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     1,     2,     1,     1,
       1,     1,     1,     5,     5,     7,     7,     5,     8,     8,
       2,     2,     2,     2,     3,     3,     8,     8,     2,     2,
       2,     3,     3,     1,     1,     7,     1,     1,     3,     1,
       1,     1,     1,     1,     4,     7,     2,     2,     4,     7,
       2,     1,     1,     0,     5,     2,     2,     0,     8,     5,
       4,     7,     2,     4,     7,     2,     7,     2,     2,     2,
       2,     2,     2,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     3,     3,     3,     2,     3,     3,     3,     2,     3,
       3,     3,     3,     2,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     3,     2,     3,     3,     3,     2,
       3,     3,     1,     3,     1,     3,     3,     3,     3,     1,
       1,     1,     1,     3,     3,     3,     3,     1,     1,     3,
       2,     1,     2,     2,     1,     1,     1,     2,     2,     1,
       2,     3,     5,     1,     4,     5,     3,     4,     3,     2,
       4,     5,     3,     4,     4,     2,     1,     5,     4,     2,
       5,     3,     1,     4,     4,     3,     1,     0,     3,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       3,     1,     2,     5,     4,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     3,     3,     3,
       3,     1,     1,     1,     1,     2,     2,     2,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     4,     4,     2,     2,     2,     2,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       4,     4,     2,     3,     1,     1,     1,     3,     4,     4,
       4,     6,     6,     6,     6,     6,     4,     2,     4,     4,
       4,     4,     6,     6,     6,     6,     6,     4,     2,     4,
       4,     4,     4,     6,     6,     6,     6,     6,     4,     2,
       4,     4,     4,     4,     6,     6,     6,     6,     6,     4,
       2,     4,     4,     4,     4,     6,     6,     6,     6,     6,
       4,     2,     4,     4,     6,     2,     4,     4,     4,     2,
       4,     4,     2,     4,     4,     2,     6,     6,     6,     4,
       2,     6,     2,     4,     4,     4,     2,     4,     4,     4,
       2,     4,     4,     2,     4,     4,     2,     4,     4,     2,
       4,     3,     2,     4,     3,     2,     4,     3,     4,     2,
       4,     4,     2,     4,     4,     2,     4,     4,     2,     4,
       4,     2,     4,     4,     2,     4,     3,     1,     3,     1,
       3,     1,     4,     3,     1,     4,     4,     4,     4,     4,
       2,     4,     4,     2,     4,     4,     2,     3,     1,     3,
       1,     3,     1,     3,     1,     6,     6,     2,     4,     4,
       2,     4,     0,     5,     2,     0,     3,     1,     1,     3,
       2,     1,     3,     2,     1,     1,     3,     2,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     409,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   408,    22,    23,
       0,     0,     4,     0,     0,     0,     0,     0,     8,     9,
       6,     0,   406,    10,     0,    15,     7,   407,   455,     0,
     456,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   101,     0,   103,     0,   105,     0,
     107,     0,   109,     0,   111,     0,   113,     0,   115,     0,
     117,     0,   119,     0,   121,     0,   123,     0,   125,     0,
     127,     0,   129,     0,   131,     0,   133,     0,   135,     0,
     139,     0,   137,     0,   141,     0,   143,     0,   145,     0,
     147,     0,   149,     0,   151,     0,   153,     0,   155,     0,
     157,     0,   159,     0,   161,     0,   163,     0,   165,     0,
     167,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   421,   420,   423,     0,   422,   428,     0,   430,
       0,   429,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   252,     0,   254,     0,   256,     0,
     258,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   368,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    60,    66,    65,    59,    61,    63,    68,
      71,    67,    69,   469,   468,   471,   470,   473,   472,     1,
       5,     3,     0,     0,     0,    12,     0,    14,     0,    17,
       0,    19,     0,    21,     0,     0,   453,   439,   440,   441,
       0,   397,   396,   395,   394,   399,    31,    32,    33,    34,
      35,   398,   401,     0,    57,   400,   403,   402,   405,   404,
      73,    72,    75,    74,    77,    76,    79,    78,    81,    80,
      83,    82,    85,    84,    87,    86,    89,    88,    91,    90,
      93,    92,    95,    94,   324,   551,   549,   550,    25,   436,
       0,     0,    30,    50,     0,    55,   322,    24,   433,   437,
     434,   552,    26,   326,   325,   328,   327,    97,    96,    99,
      98,   100,   102,   104,   106,   108,   110,   112,   114,   116,
     118,   120,   122,   124,   126,   128,   130,   132,   134,   138,
     136,   140,   142,   144,   146,   148,   150,   152,   154,   156,
     158,   160,   162,   164,   166,   174,   168,   169,   176,   175,
     178,   177,   180,   179,   182,   181,   184,   183,   186,   185,
     188,   187,   190,   189,   192,   191,   194,   193,   196,   195,
     198,   197,   200,   199,   202,   201,   315,   314,   317,   316,
     319,   318,   321,   320,   425,   424,     0,   432,   431,   171,
     170,   173,   172,   207,   206,   205,   210,   209,   208,   213,
     212,   211,   216,   215,   214,   219,   218,   217,   221,   220,
     223,   222,   225,   224,   227,   226,   229,   228,   231,   230,
     233,   232,   236,   234,   235,   238,   237,   240,   239,   242,
     241,   244,     0,   243,   246,   245,   248,   247,   250,   249,
     251,   253,   255,   257,   260,   259,   262,   261,   264,   263,
     266,   265,   268,   267,   270,   269,   272,   271,   274,   273,
     276,   275,   278,   277,   280,   279,   282,   281,   284,   283,
     286,   285,   288,   287,   293,   289,   290,   291,   292,   305,
     304,   307,   306,   295,   294,   297,   296,   299,   298,   301,
     300,   303,   302,   309,   308,   311,   310,   313,   312,   330,
     329,   332,   331,   334,   333,   336,   335,   338,   337,   340,
     339,   342,   341,   344,   343,   346,   345,   348,   347,   350,
     349,   352,   351,   354,   353,   356,   355,   358,   357,   360,
     359,   363,   361,   362,   366,   364,   365,   367,   370,   369,
     372,   371,   374,   373,   376,   375,   378,   377,   204,   203,
     379,   380,   381,   385,   384,   383,   382,   387,   386,   389,
     388,   391,   390,   393,   392,     0,     0,     0,   446,     0,
     447,     0,   450,     0,     0,   462,     0,     0,   465,     0,
       0,   467,     0,   411,   412,   410,     0,     0,     0,     0,
      58,     0,    27,     0,     0,     0,     0,    56,     0,     0,
       0,     0,    62,    64,    70,     0,     0,     0,     0,     0,
       0,   854,   851,   855,   858,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   807,   809,   811,   814,     0,     0,     0,     0,
       0,   828,   830,   832,   834,     0,     0,     0,     0,     0,
       0,     0,   684,   685,   686,   611,     0,   623,   624,   569,
       0,     0,   561,   564,   565,   566,     0,   615,   616,   626,
     627,   628,     0,     0,     0,   557,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   459,     0,     0,
       0,    29,   438,    54,    44,    43,    51,    52,     0,   556,
     551,   554,   555,   553,     0,     0,   697,     0,   719,     0,
     730,     0,   741,     0,   708,     0,     0,   495,   496,   497,
     508,   501,   509,   502,   507,   499,   506,   498,     0,   500,
       0,   503,     0,   504,   597,   643,   642,   641,     0,     0,
       0,     0,     0,   630,     0,     0,   629,     0,   505,     0,
     510,     0,   636,   635,   634,     0,   617,   619,   618,   631,
     632,   633,   644,     0,   853,     0,   850,     0,   857,   745,
       0,   762,     0,   766,     0,     0,   770,     0,   789,     0,
     792,     0,   773,     0,   779,     0,   776,     0,   782,     0,
     785,     0,     0,   798,     0,   801,     0,   795,     0,   804,
       0,     0,     0,     0,     0,     0,     0,     0,   820,     0,
     823,     0,   826,     0,     0,     0,     0,     0,   589,     0,
       0,   837,     0,   840,     0,   749,     0,   752,     0,   755,
       0,   844,     0,   570,   563,   562,   444,   560,   599,   600,
     601,   602,   603,   604,   605,   606,   607,   608,     0,   609,
     612,   625,     0,   568,   760,     0,   567,   448,     0,   460,
       0,   463,     0,     0,   417,   413,   414,     0,   454,     0,
       0,    28,     0,     0,     0,     0,     0,     0,   544,     0,
     687,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   514,   477,   476,   483,   475,   474,   482,
       0,     0,     0,   539,     0,     0,   682,   665,   668,   647,
     667,   646,     0,     0,     0,   852,   617,   618,   632,   633,
       0,     0,     0,     0,   518,     0,   523,   481,   480,   479,
     478,     0,     0,   535,     0,   612,   666,   645,     0,     0,
       0,     0,     0,     0,     0,   489,   488,   487,   486,   490,
     485,   484,   494,   493,   492,   491,     0,     0,     0,     0,
       0,     0,     0,   849,   856,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   781,     0,   784,     0,
     787,     0,     0,     0,     0,     0,     0,     0,     0,   806,
     808,   810,     0,     0,   813,     0,     0,     0,   571,   558,
       0,     0,     0,     0,     0,    45,     0,     0,   827,   829,
     831,   833,     0,   591,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   845,     0,     0,   683,     0,   622,
       0,   620,     0,   621,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    53,   323,     0,     0,     0,   698,     0,
     696,     0,   689,     0,   690,     0,     0,     0,   688,   720,
       0,   718,     0,   711,     0,   712,     0,   710,   731,     0,
     729,     0,   722,     0,   723,     0,   721,   742,     0,   740,
       0,   733,     0,   734,     0,   732,   709,     0,   707,     0,
     700,     0,   701,     0,   699,   513,     0,   511,   529,    36,
      37,    38,    39,    40,    41,    42,   527,   528,   526,   524,
     525,   538,   536,   537,   592,   596,   598,     0,     0,     0,
       0,   640,   662,   639,   638,   637,   517,     0,   515,   522,
     520,   521,   519,   534,     0,    57,     0,   542,   530,   532,
     531,     0,   679,   661,   678,   660,   674,   653,   675,   654,
     655,   656,   657,   670,   649,   669,   648,   673,   652,   672,
     651,   671,   650,   677,   659,   676,   658,   746,     0,   743,
     763,     0,   767,   765,   764,   768,   771,   769,   790,   788,
     793,   791,   774,   772,   780,   778,   777,   775,   786,   783,
     799,   797,   802,   800,   796,   794,   805,   803,   815,   812,
     817,   816,     0,     0,   819,   818,   822,   821,   825,     0,
       0,   824,     0,     0,     0,   588,   586,     0,   838,     0,
     841,   839,   747,   748,   750,   751,   753,   754,   848,     0,
     847,   610,   614,     0,   759,   612,     0,     0,     0,     0,
       0,   415,   416,     0,   458,     0,   426,   427,   445,     0,
       0,     0,     0,   548,   546,   547,   545,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     680,   663,   681,   664,     0,     0,     0,     0,   559,   572,
      49,    46,    47,   590,     0,     0,     0,   573,   579,   587,
     585,    57,     0,     0,   843,     0,     0,     0,   449,   461,
     464,   466,   418,   419,   435,   694,   695,   692,   693,   691,
     716,   717,   714,   715,   713,   727,   728,   725,   726,   724,
     738,   739,   736,   737,   735,   705,   706,   703,   704,   702,
       0,     0,   595,   543,   541,   540,   613,   744,   761,     0,
     582,     0,     0,     0,     0,   835,   836,   846,   758,   757,
     756,   594,   593,    48,     0,   583,   577,   584,     0,     0,
       0
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,   180,   181,   182,   183,   184,   185,   186,   187,   502,
     803,   503,   504,  1336,   906,  1237,   505,   506,   956,   188,
     416,   417,   418,   189,   421,   422,   190,   191,   796,   192,
     193,   507,   508,   509,   510,   450,   434,   435,   437,   194,
     195,   798,   898,   439,   441,   443,   196,  1119,  1152,  1120,
    1181,  1182,   957,   958,   959,   960,   961,   962,  1368,  1092,
     511,   512,   963,  1228,   871,   872,   873,  1526,  1446,  1447,
     874,   875,  1345,  1346,   964,  1125,  1058,  1059,  1060,   965,
     966,   967,   968,   879,   969,  1262,   970,   971,  1062,   882,
     972,   973,  1140,   883,   884,   885,  1042,  1459,  1460,   886
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -1077
static const yytype_int16 yypact[] =
{
    2449,  -233,    41,    11,  -227,  -208,  -142,  -121,   -92,   -64,
   -1077,   -39,    -9,     0,     1,    15,    23,   356,   394,   395,
     400,   403,   420,   427,   432,   472,   500,   505,   482,   513,
     619,   639,   643,   660,   678,   679,   696,   715,   750,   756,
     769,   770,   779,   799,   800,   805,   807,   808,   810,   824,
     825,   847,   856,   859,   860,   861,   862,   871,   880,   882,
     883,   885,   521,   535,   540,   541,   560,   561,   566,   574,
     641,   656,   683,   743,   757,   759,   762,   774,   795,   809,
     815,   821,    92,   190,    47,   217,   836,   840,   845,   848,
     873,   874,   884,   887,   895,   903,   904,   909,   926,   932,
     938,   942,   943,   945,   946,   948,   950,   951,   886,   891,
     892,   893,   965,   967,   968,   969,   970,   972,   973,   979,
     980,   981,   982,   983,   984,   986,   987,   998,   999,  1000,
    1001,  1005,  1006,  1007,  1008,  1009,  1010,  1011,  1012,  1017,
    1018,  1021,  1022,  1023,  1024,  1025,  1028,  1029,  1030,  1031,
    1032,  1035,  1037,  1038,  1039,  1047,   897,  1048,  1049,  1050,
    1051,  1052,  1053,  1088,  1089,  1090,  1091,  1092,  1093,  1094,
    1097,  1098,   187,   194,   131,   206,   219, -1077, -1077, -1077,
      79,  1600, -1077,   914,    90,   237,   324,   570, -1077, -1077,
   -1077,  -253, -1077, -1077,   -66, -1077, -1077, -1077, -1077,   454,
   -1077,    42,   140,   752,   293,   201,   257,   299,   313,   473,
     504,   506,    43,   230,   525,   239,   579,   240,   241,    37,
      64,   580,   591,   600, -1077,   471, -1077,   612, -1077,   632,
   -1077,  -174, -1077,  -174, -1077,  -174, -1077,  -174, -1077,   662,
   -1077,   706, -1077,   707, -1077,   735, -1077,   771, -1077,   817,
   -1077,   908, -1077,  1066, -1077,  1067, -1077,  1068, -1077,  1069,
   -1077,  1070, -1077,  1071, -1077,  1072, -1077,  1073, -1077,  1074,
   -1077,  1075, -1077,  1077, -1077,  1078, -1077,  1079, -1077,  1080,
   -1077,  1081, -1077,  1083, -1077,  1084, -1077,  1085, -1077,  1086,
   -1077,  1087,   601,   392,   611,   616,   621,   625,   628,   630,
     310,   312,   314,   316,   317,   319,   322,   631,   634,   242,
     243,   635, -1077, -1077, -1077,   244, -1077, -1077,   653, -1077,
     245, -1077,   636,   637,   197,   207,   211,   215,   222,   638,
     640,   644,   648,   345,   360,   414,   231,   649,   651,   652,
     654,    16,   657,   658, -1077,  1095, -1077,  1096, -1077,  1101,
   -1077,  1102,   659,   661,   664,   665,   666,   667,   668,   669,
     673,   674,   675,   676,   681,   684,   685,   939,   686,   687,
     688,   689,   246,   247,   248,   690,   691,   692,    14,   693,
     694,   695,   698,   699,   700,   701,   702,   703,   708,   711,
     712,   713,   714,   716,   235,   287, -1077,  1127,   722,   725,
     727,   728,   730,   250,  1128,  1129,  1130,   466,   470,   731,
     732,   733,   734, -1077, -1077, -1077, -1077,   633,   844, -1077,
   -1077, -1077,   898, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
    -233, -1077,    49,    34,   671, -1077,    68, -1077,    82, -1077,
     104, -1077,    20, -1077,   -27,  1131, -1077, -1077, -1077, -1077,
    1076, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077,  1132, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077,  1138, -1077, -1077, -1077, -1077,
     924,  1135, -1077,  1116,  1119,   941,  1292, -1077, -1077, -1077,
   -1077, -1077,  -221, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077,  1082, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077,  1138, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077,  -201,  1140,  -201, -1077,   454,
   -1077, 11017, -1077, 11017,   454, -1077, 11017,   454, -1077, 11017,
     454, -1077,  1134, -1077, -1077, -1077,  1122,  1141, 11017,    35,
   -1077,  1142,  1137,  1133,  1187,   262,   919, -1077,   924,   276,
     282,  1144, -1077, -1077, -1077,  1188,    51,    58,    65,    66,
      80, 10100, 10306, 10421, -1077,    91,    94,   103,  1146,   106,
     113,   114,   115,   117,   118,   119,   120,  1193,   133,   134,
     142,   143,  1194,  1195,  1196,  1197,  1198, 10507,   144,   148,
     155,  1200,  1201,  1204,  1205,  6023, 10507,   157,   158,   159,
     162,   164, -1077, -1077, -1077, -1077,   166, -1077, -1077, -1077,
       4,  3479, -1077, -1077, -1077, -1077,   928, -1077, -1077, -1077,
   -1077, -1077,  1125,  1208,   167, -1077,  1209,  3628,  1206,  3801,
    1207,  3870,  1212,  1257,   108,  1147,  3950, -1077,  1139,  1158,
     924, -1077, -1077, -1077, -1077, -1077, -1077,  1202,  1203, -1077,
   -1077, -1077, -1077, -1077,  1215,  1262, -1077,   109, -1077,    56,
   -1077,    89, -1077,   132, -1077,   138,   768, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,   622, -1077,
     622, -1077,   820, -1077, -1077,  1132, -1077, -1077,  6224,  6346,
    6547,  1264,  1265, -1077,  5377, 10950, -1077,   789, -1077,   775,
   -1077,   804, -1077, -1077, -1077,   928, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077,  6669,  1379,  5578,  1379,  5700,  1379, -1077,
     199, -1077,   252, -1077,  6870,  1274, -1077,   253, -1077,   260,
   -1077,   261, -1077,   263, -1077,   739, -1077,   740, -1077,  1268,
   -1077,   176,  1269, -1077,   264, -1077,   265, -1077,   269, -1077,
     270,  1270,  1271,  1272,   179,   788,  6992,  9984, -1077,   147,
   -1077,   745, -1077,    84,  1273,  1275,  1276,  1277, -1077,  1064,
    9984, -1077,   271, -1077,   272, -1077,   542, -1077,   604, -1077,
     786, -1077,  1280, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,  1287, -1077,
    1279, -1077, 10507, -1077, -1077,   168, -1077, -1077,  1282, -1077,
    1283, -1077,  1284,  1285, -1077,  1153,  1154,   -27, -1077, 11017,
    1288, -1077,  -150,  1299,  -234, 11017,  1290,  -136, -1077,   -94,
   -1077,   -45,  -237,  1291,   -32,   -23,   428,   -22,  1318,   443,
     483,   508,   838,  1319,   546,   645,   744,   894,  1325,   753,
     803,   822,   906, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
    7193,  5054,  5255, -1077,  1112,  1301, -1077, -1077, -1077, -1077,
   -1077, -1077,  7315,  7516,  1326, -1077,  1370,  1371,  1372,  1373,
    1136,  1331,  1329,  4019, -1077,  7638, -1077, -1077, -1077, -1077,
   -1077,  7839,  7961, -1077,  2759,  1330, -1077, -1077,  8162,  8284,
    8485,  8607, 10507, 10507, 10507, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077,  8808,  8930,  9131,  9253,
    9454,  9576,  9777, -1077, -1077,  1333,  1337,  1360,  1361,  1364,
    1363,    61,  1191,  1365,  1366,  1367,  1368,  1369,  1386,  1493,
    1494,  1495,  1496,  1530,  1542,  1543, -1077,  1544, -1077,  1545,
   -1077,  1546,  1547,  1548,  1549,  1550,  1551,  1552,  1553, -1077,
   -1077, -1077,  1557,  1558, -1077,  1582,  1583, 11017,  1644, -1077,
    1584,  1585,  1586,  1587,  1588,  1589,  1590,  1592, -1077, -1077,
   -1077, -1077,    18, -1077,  1593,  1591,  1594,  1595,  1598,  1602,
    1603,  1604,  1619,  1620, 10507,  1380,  1616,  1379,   826, -1077,
     928, -1077,  1624, -1077, 11017, 11017, 11017, 11017,  1597,  1607,
    1666,  4192,  1637, -1077, -1077,  1625,  1634,  4341, -1077,   -21,
   -1077,  1655, -1077,  1657, -1077,   218,   223,  1658, -1077, -1077,
     -16, -1077,  1659, -1077,  1661, -1077,  1670, -1077, -1077,    -8,
   -1077,  1671, -1077,  1675, -1077,  1676, -1077, -1077,   127, -1077,
    1677, -1077,  1685, -1077,  1698, -1077, -1077,   503, -1077,  1699,
   -1077,  1700, -1077,  1701, -1077, -1077,  1994,   974, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077,   974, -1077, -1077,
     974, -1077, -1077, -1077,  1688, -1077,  1706,  1694,  1263,  1703,
    1601, -1077, -1077, -1077, -1077, -1077, -1077,  2063,   974, -1077,
     974, -1077,   879, -1077,  2132,  1138,  1925,  1735, -1077,  -219,
     974,  -258, -1077,  2447, -1077,  2704, -1077,  2742, -1077,  1210,
    1281,  2894,  1336, -1077,   -90, -1077,   -90, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077,   974, -1077,   879, -1077,  1723, -1077,
   -1077,  1724, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077,  4410, 10828, -1077, -1077, -1077, -1077, -1077,   307,
     924, -1077,  1715,  5901,  1713, -1077, -1077,   850, -1077, 10627,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,  1379,   890,
   -1077, -1077, -1077,  -201, -1077, -1077,   236,  4514,  4583,  4732,
    4905, -1077, -1077,  -133, -1077,  1739, -1077, -1077, -1077,  1730,
    1734,  1736,  1744, -1077, -1077, -1077, -1077,  1757,  1758,  1759,
    1760,  1761,  1762,  1763,  1772,  1783,  1785,  1786,  1787,  1789,
    1798,  1799,  1803,  1804,  1805,  1813,  1826,  1827,   -76,  1301,
   -1077, -1077, -1077, -1077,    22,  1823,  1829,  1830, -1077, -1077,
   -1077, -1077,  1728, -1077,  1824,  9899,  1825,  1379, 11017, -1077,
   -1077,  1841,  2235, 10507, -1077,  1852,  1854,  1855, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077, -1077,
    1851,  1853, -1077, -1077,  1138, -1077, -1077, -1077, -1077,  -150,
   11017,  1861,  1865,  2846,  2915, -1077, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077,  3088, 11017, 11017, -1077,  3237,  3306,
    3410
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
   -1077, -1077, -1077,  2013, -1077, -1077, -1077, -1077, -1077,  -376,
    1295,  1396,  -199,  1105, -1076, -1077, -1077,  -173,  -204, -1077,
    1428, -1077,  -172, -1077,  1451, -1077, -1077, -1077,  1152, -1077,
   -1077,  -899,  1890,  1731,  1893,  -600, -1077, -1077, -1077, -1077,
   -1077, -1077, -1077, -1077, -1077, -1077, -1077,  -931, -1077,  -849,
   -1077, -1077,  1107, -1077, -1077, -1077,  1111, -1077, -1077,    12,
    -576, -1077,   -59, -1022,  -773,  -674, -1077,   718,   791, -1077,
   -1077, -1077,   741, -1077, -1077, -1077, -1077,   985,  -951,  -135,
    -749, -1077,  -695, -1077, -1077, -1077,  -479,  -725, -1077, -1077,
   -1077, -1077,   160,   173, -1077, -1077, -1077, -1077,   719, -1077
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -843
static const yytype_int16 yytable[] =
{
     465,   420,   710,   471,   461,  1043,  1273,  1121,  1243,  1122,
     887,  1124,   200,   889,  1155,   709,   891,   644,  1091,  1442,
    1096,   791,  1101,  1573,  1106,   896,  1111,   524,  1151,   525,
     793,   526,   877,   527,   877,   780,   897,   877,   494,   463,
     877,  1479,   198,   451,   480,   197,  1488,   514,   317,   877,
     778,   201,   916,   464,  1493,   444,   881,  1093,   881,   918,
    1285,   881,  1041,   463,   881,   513,   920,   922,  1462,   782,
     202,  1286,   445,   881,  1443,  1444,   809,   464,  1285,   429,
    1275,   924,  1287,   785,  1288,  1234,   878,   810,   878,  1286,
    1098,   878,   979,   312,   878,   981,   571,   573,   575,   577,
     579,   581,   583,   878,   983,   788,   436,   986,  1145,  1074,
    1086,   414,  1154,   415,   988,   990,   992,  1094,   994,   996,
     998,  1000,   877,   463,   802,   456,   457,   458,   459,   627,
     629,   631,   423,  1103,  1003,  1005,   203,   464,   877,  1108,
     877,   453,   877,  1007,  1009,  1018,   881,   877,  1230,  1020,
    1099,   904,   456,   457,   458,   459,  1022,   204,  1031,  1033,
    1035,   905,   881,  1037,   881,  1039,   881,  1041,  1064,  1258,
    1087,   881,   456,   457,   458,   459,   878,  1207,  1542,   815,
    1222,  1543,  1143,  1279,   888,  1280,   205,   890,   413,  1498,
     892,   314,   878,  1104,   878,   419,   878,  1047,   603,  1109,
    1185,   878,   466,   764,   766,  1136,   877,   425,   606,  1178,
    1179,  1180,   609,  1047,   206,  1047,   612,  1047,   319,  1483,
     427,   463,  1047,   615,  1485,  1281,  1136,  1282,  1136,  1139,
     881,   482,   632,   911,   913,   464,   741,  1536,  1570,   207,
     486,   490,   492,   588,   590,   594,   597,   697,   699,   701,
    1139,   758,  1139,  1188,  1194,  1367,   438,   446,   468,  1137,
     878,  1196,  1198,   903,  1200,  1211,  1213,  1136,   877,   208,
    1215,  1217,  1244,  1246,  1283,  1285,  1284,   909,   209,   210,
    1137,   877,  1137,   912,   794,   795,  1286,  1290,   744,  1291,
    1480,  1139,   881,   211,   462,  1489,  1292,  1296,  1293,  1297,
     470,   212,   880,  1494,   880,   881,  1271,   880,  1520,  1465,
     880,   570,  1277,   572,   472,   574,  1261,   576,   578,   880,
     580,  1137,   878,   582,  1044,   495,   496,   497,   498,   499,
     877,   499,   807,  1574,  -452,   878,   877,   499,   460,   501,
    1263,   501,  1445,  1229,   440,   792,   626,   501,   495,   496,
     497,   498,   499,   452,   881,   481,  1229,  -443,  -457,   500,
     881,   628,   501,  1521,  -451,   460,   199,   642,  1088,   318,
    1095,   499,  -442,   917,   779,   495,   496,   497,   498,   499,
     919,   501,  1403,  -842,   878,   460,   500,   921,   923,   501,
     878,   783,   880,   784,   877,   495,   496,   497,   498,   499,
     642,  1088,   925,  1100,   499,   786,   313,   787,   880,   501,
     880,  1519,   880,   980,   501,   630,   982,   880,   881,  1075,
     642,  1088,  1076,  1089,   499,   984,  1124,   789,   987,   790,
    1090,   865,   908,  1124,   501,   989,   991,   993,  1499,   995,
     997,   999,  1001,   642,  1088,   424,  1105,   499,   878,   642,
    1088,   454,  1110,   499,  1432,  1004,  1006,   501,   495,   496,
     497,   498,   499,   501,  1008,  1010,  1019,   763,   315,  1047,
    1021,   765,   501,   463,   474,  1138,   880,  1023,   877,  1032,
    1034,  1036,  1259,   224,  1038,   868,  1040,   464,  -842,  1065,
    1223,  1467,  1468,  1469,  1470,   320,  1138,  1208,  1138,   414,
    1224,   415,   881,  1593,   316,   476,   414,   478,   415,   604,
    1186,   605,   467,  1187,   226,   877,   877,   877,   877,   607,
     426,   608,   877,   610,   802,   611,   484,   613,   877,   614,
    1484,   321,   878,   428,   616,  1486,   617,  1138,   880,   881,
     881,   881,   881,   633,   483,   634,   881,   742,   414,   743,
     415,   880,   881,   487,   491,   493,   589,   591,   595,   598,
     698,   700,   702,   904,   759,  1503,  1189,  1195,   469,   878,
     878,   878,   878,   905,  1197,  1199,   878,  1201,  1212,  1214,
     488,   515,   878,  1216,  1218,  1245,  1247,   910,   496,   497,
     463,   442,   517,   910,   496,   497,   463,  1047,   745,   746,
     880,   519,   555,  1047,   464,   420,   880,   463,   904,   463,
     464,   463,   558,   463,   463,  1575,   463,   560,   905,   463,
     228,   464,   562,   464,   473,   464,   564,   464,   464,   566,
     464,   568,   584,   464,   213,   586,   592,   599,   601,   618,
     230,   620,   463,  1231,   232,   622,   876,  1235,   876,   624,
     635,   876,   637,   639,   876,   641,   464,   463,   646,   648,
     654,   234,   656,   876,   880,   658,   660,   662,   664,   666,
     668,   464,   214,   215,   670,   672,   674,   676,   216,   236,
     238,   217,   678,   877,   877,   680,   682,   689,   691,   693,
     695,   703,   705,   707,   711,   713,   715,   240,   218,   717,
     719,   721,   723,   725,   727,   219,   557,   881,   881,   729,
     220,   463,   731,   733,   735,   737,   242,   739,   877,   877,
     877,   877,   870,   748,   870,   464,   750,   870,   752,   754,
     870,   756,   767,   769,   771,   773,   876,   878,   878,   870,
    1202,  1204,   881,   881,   881,   881,  1232,  1294,   880,  1295,
     221,   244,   876,   455,   876,  1584,   876,   246,  1047,  1229,
     225,   876,  1299,   463,  1300,   447,   448,   463,   449,  1113,
     248,   250,   878,   878,   878,   878,  1146,   464,   222,   877,
     252,   464,   521,   223,   475,   880,   880,   880,   880,  1225,
    1144,   227,   880,  1047,  1047,  1047,  1047,  1209,   880,   292,
     254,   256,  1301,   881,  1302,  1153,   258,  1594,   260,   262,
    1598,   264,   870,   293,  1504,   477,  1226,   479,   294,   295,
     876,  1123,  1599,  1600,  1236,   266,   268,  1303,   870,  1304,
     870,   877,   870,   878,   877,   877,   485,   870,   296,   297,
     456,   457,   458,   459,   298,   877,   877,   877,   270,   877,
     877,   877,   299,  1248,   414,   881,   415,   272,   881,   881,
     274,   276,   278,   280,  1249,  1308,  1251,  1309,  1253,   881,
     881,   881,   282,   881,   881,   881,   456,   457,   458,   459,
    1276,   284,   876,   286,   288,   878,   290,   344,   878,   878,
     489,   516,   346,   348,   350,   876,   870,   229,   396,   878,
     878,   878,   518,   878,   878,   878,  1443,  1444,  1114,  1115,
    1047,   520,   556,  1117,  1118,  1250,   414,   231,   415,   300,
    1047,   233,   559,   522,  1047,  1047,  1047,   561,   432,   433,
    1260,  1097,   563,  1102,   301,  1107,   565,  1112,   235,   567,
     684,   569,   585,   523,   876,   587,   593,   600,   602,   619,
     876,   621,   775,   880,   880,   623,   237,   239,   870,   625,
     636,   302,   638,   640,  1310,   642,  1311,   596,   647,   649,
     655,   870,   657,   528,   241,   659,   661,   663,   665,   667,
     669,   974,   976,   978,   671,   673,   675,   677,   880,   880,
     880,   880,   679,   243,   781,   681,   683,   690,   692,   694,
     696,   704,   706,   708,   712,   714,   716,  1017,   876,   718,
     720,   722,   724,   726,   728,  1029,  1030,   529,   530,   730,
     870,   303,   732,   734,   736,   738,   870,   740,   245,   456,
     457,   458,   459,   749,   247,   304,   751,   305,   753,   755,
     306,   757,   768,   770,   772,   774,   531,   249,   251,   880,
    1203,  1205,   307,   460,  1114,  1115,  1233,   253,  1116,  1117,
    1118,  1114,  1115,  1312,  1522,  1313,  1117,  1118,  1147,  1148,
    1149,  1150,  1317,   308,  1318,  1114,  1115,   255,   257,  1116,
    1117,  1118,   532,   259,   870,   261,   263,   309,   265,   460,
    1114,  1115,   876,   310,  1116,  1117,  1118,  1252,   414,   311,
     415,   880,   267,   269,   880,   880,  1114,  1115,  1127,  1129,
    1131,  1117,  1118,  1341,   322,   880,   880,   880,   323,   880,
     880,   880,  1319,   324,  1320,   271,   325,  1141,   533,   876,
     876,   876,   876,  1157,   273,  1285,   876,   275,   277,   279,
     281,  1321,   876,  1322,  1192,  1463,  1286,  1464,  1141,   283,
    1141,   326,   327,   685,   686,   687,   688,  1305,   285,  1306,
     287,   289,   328,   291,   345,   329,  1369,  1515,   870,   347,
     349,   351,   776,   330,  1529,   397,  1176,  1177,  1178,  1179,
    1180,   331,   332,   927,   928,   929,   930,   333,   932,  1141,
     934,  1285,   936,  1048,  1049,  1050,  1051,  1052,  1053,  1054,
    1055,  1056,  1286,  1285,   334,   870,   870,   870,   870,  1533,
     335,  1534,   870,  1314,  1286,  1315,   336,   777,   870,   534,
     337,   338,  1257,   339,   340,  1323,   341,  1324,   342,   343,
     495,   496,   497,   498,   499,   495,   496,   497,   498,   499,
    1057,   500,   460,   352,   501,   353,   354,   355,   356,   501,
     357,   358,   495,   496,   497,   498,   499,   359,   360,   361,
     362,   363,   364,   500,   365,   366,   501,  1172,  1173,  1174,
    1175,  1176,  1177,  1178,  1179,  1180,   367,   368,   369,   370,
    1327,  1337,  1340,   371,   372,   373,   374,   375,   376,   377,
     378,  1535,  1348,  1350,  1537,   379,   380,   876,   876,   381,
     382,   383,   384,   385,  1571,  1358,   386,   387,   388,   389,
     390,  1360,  1362,   391,  1370,   392,   393,   394,  1373,  1375,
    1377,  1379,  1380,  1381,  1382,   395,   398,   399,   400,   401,
     402,   403,   876,   876,   876,   876,  1384,  1386,  1388,  1390,
    1392,  1394,  1396,  1158,  1159,  1160,  1161,  1162,  1163,  1164,
    1165,  1166,  1167,  1168,  1169,  1170,  1171,  1172,  1173,  1174,
    1175,  1176,  1177,  1178,  1179,  1180,   404,   405,   406,   407,
     408,   409,   410,   870,   870,   411,   412,   535,   536,   537,
     538,   539,   540,   541,   542,   543,   544,  1242,   545,   546,
     547,   548,   549,   876,   550,   551,   552,   553,   554,   808,
     894,   811,   799,  1061,  1268,  1269,   650,   651,   870,   870,
     870,   870,   652,   653,  1458,  1158,  1159,  1160,  1161,  1162,
    1163,  1164,  1165,  1166,  1167,  1168,  1169,  1170,  1171,  1172,
    1173,  1174,  1175,  1176,  1177,  1178,  1179,  1180,   747,   760,
     761,   762,   797,   800,   805,   876,   801,   806,   876,   876,
     499,   813,   893,   899,   901,  1077,   900,  1352,   914,   876,
     876,   876,  1079,   876,   876,   876,  1080,   895,   985,   870,
    1158,  1159,  1160,  1161,  1162,  1163,  1164,  1165,  1166,  1167,
    1168,  1169,  1170,  1171,  1172,  1173,  1174,  1175,  1176,  1177,
    1178,  1179,  1180,  1162,  1163,  1164,  1165,  1166,  1167,  1168,
    1169,  1170,  1171,  1172,  1173,  1174,  1175,  1176,  1177,  1178,
    1179,  1180,  1404,   902,   915,  1002,  1011,  1012,  1013,  1014,
    1015,   870,  1024,  1025,   870,   870,  1026,  1027,  1063,  1066,
    1082,  1083,  1068,  1070,  1084,   870,   870,   870,  1072,   870,
     870,   870,  1158,  1159,  1160,  1161,  1162,  1163,  1164,  1165,
    1166,  1167,  1168,  1169,  1170,  1171,  1172,  1173,  1174,  1175,
    1176,  1177,  1178,  1179,  1180,  1163,  1164,  1165,  1166,  1167,
    1168,  1169,  1170,  1171,  1172,  1173,  1174,  1175,  1176,  1177,
    1178,  1179,  1180,  1073,  1511,  1085,  1132,  1133,  1193,  1206,
    1210,  1219,  1220,  1221,  1238,  1255,  1239,  1240,  1241,  1272,
      -2,   430,  1254,  1527,  1256,  1264,  1265,  1266,  1267,  1532,
    1274,  1278,  1289,  1344,   -11,   -11,   -13,     2,     3,   -16,
     -18,   -20,  1165,  1166,  1167,  1168,  1169,  1170,  1171,  1172,
    1173,  1174,  1175,  1176,  1177,  1178,  1179,  1180,     4,  1298,
    1307,     5,     6,     7,     8,     9,  1316,  1351,  -615,  -616,
    -627,  -628,  1353,  1354,  1397,  1371,  1398,    10,  1158,  1159,
    1160,  1161,  1162,  1163,  1164,  1165,  1166,  1167,  1168,  1169,
    1170,  1171,  1172,  1173,  1174,  1175,  1176,  1177,  1178,  1179,
    1180,  1399,  1400,  1401,  1402,  1527,  1405,  1406,  1407,  1408,
    1409,  1433,  1057,  1458,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    23,  1410,    24,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    93,    94,    95,
      96,    97,    98,    99,   100,   101,   102,   103,   104,   105,
     106,   107,   108,   109,   110,   111,   112,   113,   114,   115,
     116,   117,   118,   119,   120,   121,   122,   123,   124,   125,
     126,   127,   128,   129,  1411,  1412,  1413,  1414,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   139,   140,   141,
     142,   143,   144,   145,   146,   147,   148,   149,   150,   151,
     152,   153,   154,   155,   156,   157,   158,   159,   160,   161,
     162,  1415,   163,   164,   165,   166,   167,   168,   169,   170,
     171,   172,   173,  1416,  1417,  1418,  1419,  1420,  1421,  1422,
    1423,  1424,  1425,  1426,  1427,   174,   175,   176,  1428,  1429,
    1158,  1159,  1160,  1161,  1162,  1163,  1164,  1165,  1166,  1167,
    1168,  1169,  1170,  1171,  1172,  1173,  1174,  1175,  1176,  1177,
    1178,  1179,  1180,  1430,  1431,  1434,  1435,  1436,  1437,  1438,
    1449,  1471,   177,  1441,  1448,  1450,  1451,  1439,  1440,  1452,
     178,  1472,  1513,  1453,  1454,  1455,  1041,   179,  -544,  -544,
    -544,  -544,  -544,  -544,  -544,  -544,  -544,  -544,  -544,  -544,
    1456,  1457,  1462,  1466,  1473,  1475,  1476,  -544,  -544,  -544,
    -544,  -544,  -544,  -544,  -544,  1477,  -544,  -544,  -544,  -544,
    -544,  -544,  -544,  -544,  -544,  -544,  1481,  -544,  1482,  1487,
    1490,  -544,  1491,  -544,  -544,  -544,  -544,  -544,  -544,  -544,
    -544,  1492,  1495,  -544,  -544,  -544,  1496,  1497,  1500,  -544,
    -544,  -544,  -544,  -544,  -544,  1041,  1501,  -512,  -512,  -512,
    -512,  -512,  -512,  -512,  -512,  -512,  -512,  -512,  -512,  1502,
    1505,  1506,  1507,  1508,  1509,  1510,  -512,  -512,  -512,  -512,
    -512,  -512,  -512,  -512,  1512,  -512,  -512,  -512,  -512,  -512,
    -512,  -512,  -512,  -512,  -512,  1514,  -512,  1516,  1517,  1523,
    -512,  1528,  -512,  -512,  -512,  -512,  -512,  -512,  -512,  -512,
    1544,  1545,  -512,  -512,  -512,  1546,  1579,  1547,  -512,  -512,
    -512,  -512,  -512,  -512,  1123,  1548,  -516,  -516,  -516,  -516,
    -516,  -516,  -516,  -516,  -516,  -516,  -516,  -516,  1549,  1550,
    1551,  1552,  1553,  1554,  1555,  -516,  -516,  -516,  -516,  -516,
    -516,  -516,  -516,  1556,  -516,  -516,  -516,  -516,  -516,  -516,
    -516,  -516,  -516,  -516,  1557,  -516,  1558,  1559,  1560,  -516,
    1561,  -516,  -516,  -516,  -516,  -516,  -516,  -516,  -516,  1562,
    1563,  -516,  -516,  -516,  1564,  1565,  1566,  -516,  -516,  -516,
    -516,  -516,  -516,  1123,  1567,  -533,  -533,  -533,  -533,  -533,
    -533,  -533,  -533,  -533,  -533,  -533,  -533,  1568,  1569,  1576,
    1577,  1578,  1580,  1583,  -533,  -533,  -533,  -533,  -533,  -533,
    -533,  -533,  1585,  -533,  -533,  -533,  -533,  -533,  -533,  -533,
    -533,  -533,  -533,  1588,  -533,  1589,  1590,  1591,  -533,  1592,
    -533,  -533,  -533,  -533,  -533,  -533,  -533,  -533,  -544,  1595,
    -533,  -533,  -533,  1596,   431,  1081,  -533,  -533,  -533,  -533,
    -533,  -533,   907,   812,  -544,  -544,  -544,  -544,  -544,  -544,
    -544,  -544,  -544,  -544,  -544,  -544,  -544,  -544,  -544,  -544,
    -544,  -544,  -544,  -544,  -544,  -544,  -544,  1339,   814,  1270,
     643,  1342,   804,  -544,   645,  1343,     0,  -544,  1530,     0,
    1461,  -544,  -544,  1582,  -544,  -544,  -544,  -842,  -544,     0,
    1572,     0,  1587,  -544,     0,     0,     0,  -512,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  -512,  -512,  -512,  -512,  -512,  -512,  -512,
    -512,  -512,  -512,  -512,  -512,  -512,  -512,  -512,  -512,  -512,
    -512,  -512,  -512,  -512,  -512,  -512,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  -512,     0,     0,     0,
    -512,  -512,     0,  -512,  -512,  -512,  -842,  -512,     0,     0,
       0,     0,  -512,     0,     0,     0,  -516,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,  -516,  -516,  -516,  -516,  -516,  -516,  -516,  -516,
    -516,  -516,  -516,  -516,  -516,  -516,  -516,  -516,  -516,  -516,
    -516,  -516,  -516,  -516,  -516,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,  -516,     0,     0,     0,  -516,
    -516,     0,  -516,  -516,  -516,     0,  -516,     0,     0,     0,
       0,  -516,     0,     0,     0,  -533,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,  -533,  -533,  -533,  -533,  -533,  -533,  -533,  -533,  -533,
    -533,  -533,  -533,  -533,  -533,  -533,  -533,  -533,  -533,  -533,
    -533,  -533,  -533,  -533,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,  -533,     0,     0,     0,  -533,  -533,
       1,  -533,  -533,  -533,     0,  -533,     0,     0,     0,     0,
    -533,     0,     0,   -11,   -11,   -13,     2,     3,   -16,   -18,
     -20,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     4,     0,     0,
       5,     6,     7,     8,     9,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    10,     0,     0,     0,
       0,     0,     0,     0,  1158,  1159,  1160,  1161,  1162,  1163,
    1164,  1165,  1166,  1167,  1168,  1169,  1170,  1171,  1172,  1173,
    1174,  1175,  1176,  1177,  1178,  1179,  1180,     0,     0,     0,
       0,     0,     0,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,    23,  1586,    24,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57,    58,    59,    60,    61,    62,    63,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    88,    89,    90,    91,    92,    93,    94,    95,    96,
      97,    98,    99,   100,   101,   102,   103,   104,   105,   106,
     107,   108,   109,   110,   111,   112,   113,   114,   115,   116,
     117,   118,   119,   120,   121,   122,   123,   124,   125,   126,
     127,   128,   129,     0,     0,     0,     0,   130,   131,   132,
     133,   134,   135,   136,   137,   138,   139,   140,   141,   142,
     143,   144,   145,   146,   147,   148,   149,   150,   151,   152,
     153,   154,   155,   156,   157,   158,   159,   160,   161,   162,
       0,   163,   164,   165,   166,   167,   168,   169,   170,   171,
     172,   173,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   174,   175,   176,  1159,  1160,  1161,
    1162,  1163,  1164,  1165,  1166,  1167,  1168,  1169,  1170,  1171,
    1172,  1173,  1174,  1175,  1176,  1177,  1178,  1179,  1180,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
    1363,   177,   816,   817,   818,   819,   820,     0,     0,   178,
       0,   825,   826,   827,     0,     0,   179,     0,     0,     0,
       0,   828,   829,   830,   831,   832,   833,   834,   835,     0,
     836,   837,   838,   839,   840,   841,   842,   843,   844,   845,
       0,   846,     0,     0,     0,     0,     0,   848,   849,   850,
     851,   852,   853,   854,     0,     0,     0,     0,   857,   858,
       0,     0,     0,   859,   860,   861,   862,   863,   864,   926,
     927,   928,   929,   930,   931,   932,   933,   934,   935,   936,
     937,   938,   939,   940,   941,  1364,   943,  1597,     0,   816,
     817,   818,   819,   820,   821,   822,   823,   824,   825,   826,
     827,     0,     0,     0,     0,     0,     0,     0,   828,   829,
     830,   831,   832,   833,   834,   835,     0,   836,   837,   838,
     839,   840,   841,   842,   843,   844,   845,     0,   846,     0,
       0,     0,   847,     0,   848,   849,   850,   851,   852,   853,
     854,   855,  -576,  -576,   856,   857,   858,     0,     0,     0,
     859,   860,   861,   862,   863,   864,  1045,     0,   816,   817,
     818,   819,   820,   821,   822,   823,   824,   825,   826,   827,
       0,     0,     0,     0,     0,     0,     0,   828,   829,   830,
     831,   832,   833,   834,   835,     0,   836,   837,   838,   839,
     840,   841,   842,   843,   844,   845,     0,   846,     0,     0,
       0,   847,     0,   848,   849,   850,   851,   852,   853,   854,
     855,  -578,  -578,   856,   857,   858,     0,     0,     0,   859,
     860,   861,   862,   863,   864,  1160,  1161,  1162,  1163,  1164,
    1165,  1166,  1167,  1168,  1169,  1170,  1171,  1172,  1173,  1174,
    1175,  1176,  1177,  1178,  1179,  1180,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   865,   944,  1161,  1162,  1163,  1164,  1165,  1166,
    1167,  1168,  1169,  1170,  1171,  1172,  1173,  1174,  1175,  1176,
    1177,  1178,  1179,  1180,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   945,     0,     0,     0,
       0,   946,     0,   947,   948,   949,   950,     0,   951,   952,
    1365,  1366,     0,   953,   499,   867,   868,     0,     0,     0,
       0,  1016,   955,     0,   501,     0,     0,     0,     0,  1045,
       0,   816,   817,   818,   819,   820,   821,   822,   823,   824,
     825,   826,   827,     0,     0,     0,     0,     0,     0,   865,
     828,   829,   830,   831,   832,   833,   834,   835,     0,   836,
     837,   838,   839,   840,   841,   842,   843,   844,   845,     0,
     846,     0,     0,     0,   847,     0,   848,   849,   850,   851,
     852,   853,   854,   855,  -580,  -580,   856,   857,   858,     0,
       0,     0,   859,   860,   861,   862,   863,   864,   866,     0,
       0,     0,   867,   868,     0,     0,   869,     0,     0,     0,
    -576,     0,     0,     0,     0,     0,     0,     0,   865,  1164,
    1165,  1166,  1167,  1168,  1169,  1170,  1171,  1172,  1173,  1174,
    1175,  1176,  1177,  1178,  1179,  1180,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   866,     0,     0,
       0,   867,   868,     0,     0,   869,     0,     0,  1045,  -578,
     816,   817,   818,   819,   820,   821,   822,   823,   824,   825,
     826,   827,     0,     0,     0,     0,     0,     0,     0,   828,
     829,   830,   831,   832,   833,   834,   835,     0,   836,   837,
     838,   839,   840,   841,   842,   843,   844,   845,     0,   846,
       0,     0,     0,   847,     0,   848,   849,   850,   851,   852,
     853,   854,   855,  -574,  -574,   856,   857,   858,     0,     0,
       0,   859,   860,   861,   862,   863,   864,  1045,     0,   816,
     817,   818,   819,   820,   821,   822,   823,   824,   825,   826,
     827,     0,     0,     0,     0,     0,     0,     0,   828,   829,
     830,   831,   832,   833,   834,   835,     0,   836,   837,   838,
     839,   840,   841,   842,   843,   844,   845,     0,   846,     0,
       0,   865,   847,     0,   848,   849,   850,   851,   852,   853,
     854,   855,  -581,  -581,   856,   857,   858,     0,     0,     0,
     859,   860,   861,   862,   863,   864,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     866,     0,     0,     0,   867,   868,     0,     0,   869,     0,
       0,  1045,  -580,   816,   817,   818,   819,   820,   821,   822,
     823,   824,   825,   826,   827,     0,     0,     0,     0,     0,
       0,     0,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,     0,   847,     0,   848,   849,
     850,   851,   852,   853,   854,   855,  -575,  -575,   856,   857,
     858,     0,     0,     0,   859,   860,   861,   862,   863,   864,
    1045,     0,   816,   817,   818,   819,   820,   821,   822,   823,
     824,   825,   826,   827,     0,     0,     0,     0,     0,     0,
     865,   828,   829,   830,   831,   832,   833,   834,   835,     0,
     836,   837,   838,   839,   840,   841,   842,   843,   844,   845,
       0,   846,     0,     0,     0,   847,     0,   848,   849,   850,
     851,   852,   853,   854,   855,     0,     0,   856,   857,   858,
       0,     0,     0,   859,   860,   861,   862,   863,   864,   866,
       0,     0,     0,   867,   868,     0,     0,   869,     0,     0,
       0,  -574,     0,     0,     0,     0,     0,     0,     0,   865,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   866,     0,
       0,     0,   867,   868,     0,     0,   869,     0,     0,  1045,
    -581,   816,   817,   818,   819,   820,   821,   822,   823,   824,
     825,   826,   827,     0,     0,     0,     0,     0,     0,     0,
     828,   829,   830,   831,   832,   833,   834,   835,     0,   836,
     837,   838,   839,   840,   841,   842,   843,   844,   845,     0,
     846,     0,     0,   865,   847,     0,   848,   849,   850,   851,
     852,   853,   854,   855,     0,     0,   856,   857,   858,     0,
       0,     0,   859,   860,   861,   862,   863,   864,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   866,     0,     0,     0,   867,   868,     0,     0,
     869,     0,     0,     0,  -575,     0,     0,     0,     0,     0,
       0,     0,   865,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   866,     0,     0,     0,   867,   868,     0,     0,   869,
       0,     0,  1045,  1046,   816,   817,   818,   819,   820,   821,
     822,   823,   824,   825,   826,   827,     0,     0,     0,     0,
       0,     0,     0,   828,   829,   830,   831,   832,   833,   834,
     835,     0,   836,   837,   838,   839,   840,   841,   842,   843,
     844,   845,     0,   846,     0,     0,     0,   847,     0,   848,
     849,   850,   851,   852,   853,   854,   855,     0,     0,   856,
     857,   858,     0,     0,     0,   859,   860,   861,   862,   863,
     864,  1045,     0,   816,   817,   818,   819,   820,   821,   822,
     823,   824,   825,   826,   827,     0,     0,     0,     0,     0,
       0,   865,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,     0,   847,     0,   848,   849,
     850,   851,   852,   853,   854,   855,     0,     0,   856,   857,
     858,     0,     0,     0,   859,   860,   861,   862,   863,   864,
     866,     0,     0,     0,   867,   868,     0,     0,   869,     0,
       0,  1045,  1067,   816,   817,   818,   819,   820,   821,   822,
     823,   824,   825,   826,   827,     0,     0,     0,     0,     0,
       0,     0,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,     0,   847,     0,   848,   849,
     850,   851,   852,   853,   854,   855,     0,     0,   856,   857,
     858,     0,     0,     0,   859,   860,   861,   862,   863,   864,
    1045,     0,   816,   817,   818,   819,   820,   821,   822,   823,
     824,   825,   826,   827,     0,     0,     0,     0,     0,     0,
       0,   828,   829,   830,   831,   832,   833,   834,   835,     0,
     836,   837,   838,   839,   840,   841,   842,   843,   844,   845,
       0,   846,     0,     0,   865,   847,     0,   848,   849,   850,
     851,   852,   853,   854,   855,     0,     0,   856,   857,   858,
       0,     0,     0,   859,   860,   861,   862,   863,   864,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   866,     0,     0,     0,   867,   868,     0,
       0,   869,     0,     0,     0,  1069,     0,     0,     0,     0,
       0,     0,     0,   865,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   866,     0,     0,     0,   867,   868,     0,     0,
     869,     0,     0,  1045,  1071,   816,   817,   818,   819,   820,
     821,   822,   823,   824,   825,   826,   827,     0,     0,     0,
       0,     0,     0,   865,   828,   829,   830,   831,   832,   833,
     834,   835,     0,   836,   837,   838,   839,   840,   841,   842,
     843,   844,   845,     0,   846,     0,     0,     0,   847,     0,
     848,   849,   850,   851,   852,   853,   854,   855,     0,     0,
     856,   857,   858,     0,     0,     0,   859,   860,   861,   862,
     863,   864,   866,     0,     0,     0,   867,   868,     0,     0,
     869,     0,     0,     0,  1078,     0,     0,     0,     0,     0,
       0,     0,   865,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   866,     0,     0,     0,   867,   868,     0,     0,   869,
       0,     0,  1045,  1355,   816,   817,   818,   819,   820,   821,
     822,   823,   824,   825,   826,   827,     0,     0,     0,     0,
       0,     0,     0,   828,   829,   830,   831,   832,   833,   834,
     835,     0,   836,   837,   838,   839,   840,   841,   842,   843,
     844,   845,     0,   846,     0,     0,     0,   847,     0,   848,
     849,   850,   851,   852,   853,   854,   855,     0,     0,   856,
     857,   858,     0,     0,     0,   859,   860,   861,   862,   863,
     864,  1045,     0,   816,   817,   818,   819,   820,   821,   822,
     823,   824,   825,   826,   827,     0,     0,     0,     0,     0,
       0,     0,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,   865,   847,     0,   848,   849,
     850,   851,   852,   853,   854,   855,     0,     0,   856,   857,
     858,     0,     0,     0,   859,   860,   861,   862,   863,   864,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   866,     0,     0,     0,   867,   868,
       0,     0,   869,     0,     0,  1045,  1474,   816,   817,   818,
     819,   820,   821,   822,   823,   824,   825,   826,   827,     0,
       0,     0,     0,     0,     0,     0,   828,   829,   830,   831,
     832,   833,   834,   835,     0,   836,   837,   838,   839,   840,
     841,   842,   843,   844,   845,     0,   846,     0,     0,     0,
     847,     0,   848,   849,   850,   851,   852,   853,   854,   855,
       0,     0,   856,   857,   858,     0,     0,     0,   859,   860,
     861,   862,   863,   864,  1045,     0,   816,   817,   818,   819,
     820,   821,   822,   823,   824,   825,   826,   827,     0,     0,
       0,     0,     0,     0,   865,   828,   829,   830,   831,   832,
     833,   834,   835,     0,   836,   837,   838,   839,   840,   841,
     842,   843,   844,   845,     0,   846,     0,     0,     0,   847,
       0,   848,   849,   850,   851,   852,   853,   854,   855,     0,
       0,   856,   857,   858,     0,     0,     0,   859,   860,   861,
     862,   863,   864,   866,     0,     0,     0,   867,   868,     0,
       0,   869,     0,     0,     0,  1478,     0,     0,     0,     0,
       0,     0,     0,   865,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   866,     0,     0,     0,   867,   868,     0,     0,
     869,     0,     0,  1045,  1518,   816,   817,   818,   819,   820,
     821,   822,   823,   824,   825,   826,   827,     0,     0,     0,
       0,     0,     0,     0,   828,   829,   830,   831,   832,   833,
     834,   835,     0,   836,   837,   838,   839,   840,   841,   842,
     843,   844,   845,     0,   846,     0,     0,   865,   847,     0,
     848,   849,   850,   851,   852,   853,   854,   855,     0,     0,
     856,   857,   858,     0,     0,     0,   859,   860,   861,   862,
     863,   864,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   866,     0,     0,     0,
     867,   868,     0,     0,   869,     0,     0,     0,  1538,     0,
       0,     0,     0,     0,     0,     0,   865,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   866,     0,     0,     0,   867,
     868,     0,     0,   869,     0,     0,  1045,  1539,   816,   817,
     818,   819,   820,   821,   822,   823,   824,   825,   826,   827,
       0,     0,     0,     0,     0,     0,     0,   828,   829,   830,
     831,   832,   833,   834,   835,     0,   836,   837,   838,   839,
     840,   841,   842,   843,   844,   845,     0,   846,     0,     0,
       0,   847,     0,   848,   849,   850,   851,   852,   853,   854,
     855,     0,     0,   856,   857,   858,     0,     0,     0,   859,
     860,   861,   862,   863,   864,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   865,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   866,     0,     0,     0,   867,   868,
       0,     0,   869,     0,     0,  1328,  1540,   816,   817,   818,
     819,   820,     0,     0,     0,     0,   825,   826,   827,     0,
       0,     0,     0,     0,     0,     0,   828,   829,   830,   831,
     832,   833,   834,   835,     0,   836,   837,   838,   839,   840,
     841,   842,   843,   844,   845,     0,   846,     0,     0,     0,
       0,     0,   848,   849,   850,   851,   852,   853,   854,     0,
       0,     0,     0,   857,   858,     0,     0,     0,   859,   860,
     861,   862,   863,   864,   926,   927,   928,   929,   930,   931,
     932,   933,   934,   935,   936,   937,   938,   939,   940,   941,
     942,   943,  1329,  1330,  1331,  1332,  1333,  1334,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   865,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   866,     0,     0,
       0,   867,   868,     0,     0,   869,     0,     0,     0,  1541,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,  1338,     0,   816,   817,
     818,   819,   820,     0,     0,     0,     0,   825,   826,   827,
       0,     0,     0,     0,     0,     0,     0,   828,   829,   830,
     831,   832,   833,   834,   835,     0,   836,   837,   838,   839,
     840,   841,   842,   843,   844,   845,     0,   846,     0,     0,
       0,     0,     0,   848,   849,   850,   851,   852,   853,   854,
       0,     0,     0,     0,   857,   858,     0,   865,   944,   859,
     860,   861,   862,   863,   864,   926,   927,   928,   929,   930,
     931,   932,   933,   934,   935,   936,   937,   938,   939,   940,
     941,   942,   943,  1329,  1330,  1331,  1332,  1333,  1334,     0,
       0,   945,     0,     0,     0,  1335,   946,     0,   947,   948,
     949,   950,     0,   951,   952,   464,   866,     0,   953,     0,
     867,   868,     0,     0,     0,     0,  1016,   955,  1134,     0,
     816,   817,   818,   819,   820,     0,     0,     0,     0,   825,
     826,   827,     0,     0,     0,     0,     0,     0,     0,   828,
     829,   830,   831,   832,   833,   834,   835,     0,   836,   837,
     838,   839,   840,   841,   842,   843,   844,   845,     0,   846,
       0,     0,     0,     0,     0,   848,   849,   850,   851,   852,
     853,   854,     0,     0,     0,     0,   857,   858,     0,     0,
       0,   859,   860,   861,   862,   863,   864,   926,   927,   928,
     929,   930,   931,   932,   933,   934,   935,   936,   937,   938,
     939,   940,   941,   942,   943,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   865,   944,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   945,     0,     0,     0,  1335,   946,     0,   947,
     948,   949,   950,     0,   951,   952,   464,   866,     0,   953,
       0,   867,   868,     0,     0,     0,     0,  1016,   955,  1134,
       0,   816,   817,   818,   819,   820,     0,     0,     0,     0,
     825,   826,   827,     0,     0,     0,     0,     0,     0,     0,
     828,   829,   830,   831,   832,   833,   834,   835,     0,   836,
     837,   838,   839,   840,   841,   842,   843,   844,   845,     0,
     846,     0,     0,     0,     0,     0,   848,   849,   850,   851,
     852,   853,   854,     0,     0,     0,     0,   857,   858,     0,
     865,   944,   859,   860,   861,   862,   863,   864,   926,   927,
     928,   929,   930,   931,   932,   933,   934,   935,   936,   937,
     938,   939,   940,   941,   942,   943,     0,     0,     0,     0,
       0,     0,     0,     0,   945,     0,     0,     0,     0,   946,
       0,   947,   948,   949,   950,     0,   951,   952,   464,   866,
       0,   953,     0,   867,   868,     0,     0,     0,  1135,  1016,
     955,  1134,     0,   816,   817,   818,   819,   820,     0,     0,
       0,     0,   825,   826,   827,     0,     0,     0,     0,     0,
       0,     0,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,     0,     0,     0,   848,   849,
     850,   851,   852,   853,   854,     0,     0,     0,     0,   857,
     858,     0,     0,     0,   859,   860,   861,   862,   863,   864,
     926,   927,   928,   929,   930,   931,   932,   933,   934,   935,
     936,   937,   938,   939,   940,   941,   942,   943,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   865,   944,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   945,     0,     0,     0,     0,
     946,     0,   947,   948,   949,   950,     0,   951,   952,   464,
     866,     0,   953,     0,   867,   868,     0,     0,     0,  1183,
    1016,   955,  1524,     0,   816,   817,   818,   819,   820,     0,
       0,     0,     0,   825,   826,   827,     0,     0,     0,     0,
       0,     0,     0,   828,   829,   830,   831,   832,   833,   834,
     835,     0,   836,   837,   838,   839,   840,   841,   842,   843,
     844,   845,     0,   846,     0,     0,     0,     0,     0,   848,
     849,   850,   851,   852,   853,   854,     0,     0,     0,     0,
     857,   858,     0,   865,   944,   859,   860,   861,   862,   863,
     864,   926,   927,   928,   929,   930,   931,   932,   933,   934,
     935,   936,   937,   938,   939,   940,   941,   942,   943,     0,
       0,     0,     0,     0,     0,     0,     0,   945,     0,     0,
       0,     0,   946,     0,   947,   948,   949,   950,     0,   951,
     952,   464,   866,     0,   953,     0,   867,   868,     0,     0,
       0,  1184,  1016,   955,  1028,     0,   816,   817,   818,   819,
     820,     0,     0,     0,     0,   825,   826,   827,     0,     0,
       0,     0,     0,     0,     0,   828,   829,   830,   831,   832,
     833,   834,   835,     0,   836,   837,   838,   839,   840,   841,
     842,   843,   844,   845,     0,   846,     0,     0,     0,     0,
       0,   848,   849,   850,   851,   852,   853,   854,     0,     0,
       0,     0,   857,   858,     0,     0,     0,   859,   860,   861,
     862,   863,   864,   926,   927,   928,   929,   930,   931,   932,
     933,   934,   935,   936,   937,   938,   939,   940,   941,   942,
     943,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   865,   944,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   945,     0,
       0,  1525,     0,   946,     0,   947,   948,   949,   950,     0,
     951,   952,   464,   866,     0,   953,     0,   867,   868,     0,
       0,     0,     0,  1016,   955,  1126,     0,   816,   817,   818,
     819,   820,     0,     0,     0,     0,   825,   826,   827,     0,
       0,     0,     0,     0,     0,     0,   828,   829,   830,   831,
     832,   833,   834,   835,     0,   836,   837,   838,   839,   840,
     841,   842,   843,   844,   845,     0,   846,     0,     0,     0,
       0,     0,   848,   849,   850,   851,   852,   853,   854,     0,
       0,     0,     0,   857,   858,     0,   865,   944,   859,   860,
     861,   862,   863,   864,   926,   927,   928,   929,   930,   931,
     932,   933,   934,   935,   936,   937,   938,   939,   940,   941,
     942,   943,     0,     0,     0,     0,     0,     0,     0,     0,
     945,     0,     0,     0,     0,   946,     0,   947,   948,   949,
     950,     0,   951,   952,   464,   866,     0,   953,     0,   867,
     868,     0,     0,     0,     0,  1016,   955,  1128,     0,   816,
     817,   818,   819,   820,     0,     0,     0,     0,   825,   826,
     827,     0,     0,     0,     0,     0,     0,     0,   828,   829,
     830,   831,   832,   833,   834,   835,     0,   836,   837,   838,
     839,   840,   841,   842,   843,   844,   845,     0,   846,     0,
       0,     0,     0,     0,   848,   849,   850,   851,   852,   853,
     854,     0,     0,     0,     0,   857,   858,     0,     0,     0,
     859,   860,   861,   862,   863,   864,   926,   927,   928,   929,
     930,   931,   932,   933,   934,   935,   936,   937,   938,   939,
     940,   941,   942,   943,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   865,   944,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   945,     0,     0,     0,     0,   946,     0,   947,   948,
     949,   950,     0,   951,   952,   464,   866,     0,   953,     0,
     867,   868,     0,     0,     0,     0,  1016,   955,  1130,     0,
     816,   817,   818,   819,   820,     0,     0,     0,     0,   825,
     826,   827,     0,     0,     0,     0,     0,     0,     0,   828,
     829,   830,   831,   832,   833,   834,   835,     0,   836,   837,
     838,   839,   840,   841,   842,   843,   844,   845,     0,   846,
       0,     0,     0,     0,     0,   848,   849,   850,   851,   852,
     853,   854,     0,     0,     0,     0,   857,   858,     0,   865,
     944,   859,   860,   861,   862,   863,   864,   926,   927,   928,
     929,   930,   931,   932,   933,   934,   935,   936,   937,   938,
     939,   940,   941,   942,   943,     0,     0,     0,     0,     0,
       0,     0,     0,   945,     0,     0,     0,     0,   946,     0,
     947,   948,   949,   950,     0,   951,   952,   464,   866,     0,
     953,     0,   867,   868,     0,     0,     0,     0,  1016,   955,
    1156,     0,   816,   817,   818,   819,   820,     0,     0,     0,
       0,   825,   826,   827,     0,     0,     0,     0,     0,     0,
       0,   828,   829,   830,   831,   832,   833,   834,   835,     0,
     836,   837,   838,   839,   840,   841,   842,   843,   844,   845,
       0,   846,     0,     0,     0,     0,     0,   848,   849,   850,
     851,   852,   853,   854,     0,     0,     0,     0,   857,   858,
       0,     0,     0,   859,   860,   861,   862,   863,   864,   926,
     927,   928,   929,   930,   931,   932,   933,   934,   935,   936,
     937,   938,   939,   940,   941,   942,   943,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     865,   944,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   945,     0,     0,     0,     0,   946,
       0,   947,   948,   949,   950,     0,   951,   952,   464,   866,
       0,   953,     0,   867,   868,     0,     0,     0,     0,  1016,
     955,  1190,     0,   816,   817,   818,   819,   820,     0,     0,
       0,     0,   825,   826,   827,     0,     0,     0,     0,     0,
       0,     0,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,     0,     0,     0,   848,   849,
     850,   851,   852,   853,   854,     0,     0,     0,     0,   857,
     858,     0,   865,   944,   859,   860,   861,   862,   863,   864,
     926,   927,   928,   929,   930,   931,   932,   933,   934,   935,
     936,   937,   938,   939,   940,   941,   942,   943,     0,     0,
       0,     0,     0,     0,     0,     0,   945,     0,     0,     0,
       0,   946,     0,   947,   948,   949,   950,     0,   951,   952,
     464,   866,     0,   953,     0,   867,   868,     0,     0,     0,
       0,  1016,   955,  1134,     0,   816,   817,   818,   819,   820,
       0,     0,     0,     0,   825,   826,   827,     0,     0,     0,
       0,     0,     0,     0,   828,   829,   830,   831,   832,   833,
     834,   835,     0,   836,   837,   838,   839,   840,   841,   842,
     843,   844,   845,     0,   846,     0,     0,     0,     0,     0,
     848,   849,   850,   851,   852,   853,   854,     0,     0,     0,
       0,   857,   858,     0,     0,     0,   859,   860,   861,   862,
     863,   864,   926,   927,   928,   929,   930,   931,   932,   933,
     934,   935,   936,   937,   938,   939,   940,   941,   942,   943,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   865,   944,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   945,     0,     0,
       0,     0,   946,     0,   947,   948,   949,   950,     0,   951,
     952,   464,  1191,     0,   953,     0,   867,   868,     0,     0,
       0,     0,  1016,   955,  1325,     0,   816,   817,   818,   819,
     820,     0,     0,     0,     0,   825,   826,   827,     0,     0,
       0,     0,     0,     0,     0,   828,   829,   830,   831,   832,
     833,   834,   835,     0,   836,   837,   838,   839,   840,   841,
     842,   843,   844,   845,     0,   846,     0,     0,     0,     0,
       0,   848,   849,   850,   851,   852,   853,   854,     0,     0,
       0,     0,   857,   858,     0,   865,   944,   859,   860,   861,
     862,   863,   864,   926,   927,   928,   929,   930,   931,   932,
     933,   934,   935,   936,   937,   938,   939,   940,   941,   942,
     943,     0,     0,     0,     0,     0,     0,     0,     0,   945,
       0,     0,     0,     0,   946,     0,   947,   948,   949,   950,
       0,   951,   952,   464,   866,     0,   953,     0,   867,   868,
       0,     0,     0,     0,  1016,   955,  1347,     0,   816,   817,
     818,   819,   820,     0,     0,     0,     0,   825,   826,   827,
       0,     0,     0,     0,     0,     0,     0,   828,   829,   830,
     831,   832,   833,   834,   835,     0,   836,   837,   838,   839,
     840,   841,   842,   843,   844,   845,     0,   846,     0,     0,
       0,     0,     0,   848,   849,   850,   851,   852,   853,   854,
       0,     0,     0,     0,   857,   858,     0,     0,     0,   859,
     860,   861,   862,   863,   864,   926,   927,   928,   929,   930,
     931,   932,   933,   934,   935,   936,   937,   938,   939,   940,
     941,   942,   943,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   865,   944,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     945,     0,     0,     0,     0,   946,     0,   947,   948,   949,
     950,     0,   951,   952,   464,  1326,     0,   953,     0,   867,
     868,     0,     0,     0,     0,  1016,   955,  1349,     0,   816,
     817,   818,   819,   820,     0,     0,     0,     0,   825,   826,
     827,     0,     0,     0,     0,     0,     0,     0,   828,   829,
     830,   831,   832,   833,   834,   835,     0,   836,   837,   838,
     839,   840,   841,   842,   843,   844,   845,     0,   846,     0,
       0,     0,     0,     0,   848,   849,   850,   851,   852,   853,
     854,     0,     0,     0,     0,   857,   858,     0,   865,   944,
     859,   860,   861,   862,   863,   864,   926,   927,   928,   929,
     930,   931,   932,   933,   934,   935,   936,   937,   938,   939,
     940,   941,   942,   943,     0,     0,     0,     0,     0,     0,
       0,     0,   945,     0,     0,     0,     0,   946,     0,   947,
     948,   949,   950,     0,   951,   952,   464,   866,     0,   953,
       0,   867,   868,     0,     0,     0,     0,  1016,   955,  1356,
       0,   816,   817,   818,   819,   820,     0,     0,     0,     0,
     825,   826,   827,     0,     0,     0,     0,     0,     0,     0,
     828,   829,   830,   831,   832,   833,   834,   835,     0,   836,
     837,   838,   839,   840,   841,   842,   843,   844,   845,     0,
     846,     0,     0,     0,     0,     0,   848,   849,   850,   851,
     852,   853,   854,     0,     0,     0,     0,   857,   858,     0,
       0,     0,   859,   860,   861,   862,   863,   864,   926,   927,
     928,   929,   930,   931,   932,   933,   934,   935,   936,   937,
     938,   939,   940,   941,  1357,   943,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   865,
     944,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   945,     0,     0,     0,     0,   946,     0,
     947,   948,   949,   950,     0,   951,   952,   464,   866,     0,
     953,     0,   867,   868,     0,     0,     0,     0,  1016,   955,
    1359,     0,   816,   817,   818,   819,   820,     0,     0,     0,
       0,   825,   826,   827,     0,     0,     0,     0,     0,     0,
       0,   828,   829,   830,   831,   832,   833,   834,   835,     0,
     836,   837,   838,   839,   840,   841,   842,   843,   844,   845,
       0,   846,     0,     0,     0,     0,     0,   848,   849,   850,
     851,   852,   853,   854,     0,     0,     0,     0,   857,   858,
       0,   865,   944,   859,   860,   861,   862,   863,   864,   926,
     927,   928,   929,   930,   931,   932,   933,   934,   935,   936,
     937,   938,   939,   940,   941,   942,   943,     0,     0,     0,
       0,     0,     0,     0,     0,   945,     0,     0,     0,     0,
     946,     0,   947,   948,   949,   950,     0,   951,   952,   464,
     866,     0,   953,     0,   867,   868,     0,     0,     0,     0,
    1016,   955,  1361,     0,   816,   817,   818,   819,   820,     0,
       0,     0,     0,   825,   826,   827,     0,     0,     0,     0,
       0,     0,     0,   828,   829,   830,   831,   832,   833,   834,
     835,     0,   836,   837,   838,   839,   840,   841,   842,   843,
     844,   845,     0,   846,     0,     0,     0,     0,     0,   848,
     849,   850,   851,   852,   853,   854,     0,     0,     0,     0,
     857,   858,     0,     0,     0,   859,   860,   861,   862,   863,
     864,   926,   927,   928,   929,   930,   931,   932,   933,   934,
     935,   936,   937,   938,   939,   940,   941,   942,   943,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   865,   944,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   945,     0,     0,     0,
       0,   946,     0,   947,   948,   949,   950,     0,   951,   952,
     464,   866,     0,   953,     0,   867,   868,     0,     0,     0,
       0,  1016,   955,  1372,     0,   816,   817,   818,   819,   820,
       0,     0,     0,     0,   825,   826,   827,     0,     0,     0,
       0,     0,     0,     0,   828,   829,   830,   831,   832,   833,
     834,   835,     0,   836,   837,   838,   839,   840,   841,   842,
     843,   844,   845,     0,   846,     0,     0,     0,     0,     0,
     848,   849,   850,   851,   852,   853,   854,     0,     0,     0,
       0,   857,   858,     0,   865,   944,   859,   860,   861,   862,
     863,   864,   926,   927,   928,   929,   930,   931,   932,   933,
     934,   935,   936,   937,   938,   939,   940,   941,   942,   943,
       0,     0,     0,     0,     0,     0,     0,     0,   945,     0,
       0,     0,     0,   946,     0,   947,   948,   949,   950,     0,
     951,   952,   464,   866,     0,   953,     0,   867,   868,     0,
       0,     0,     0,  1016,   955,  1374,     0,   816,   817,   818,
     819,   820,     0,     0,     0,     0,   825,   826,   827,     0,
       0,     0,     0,     0,     0,     0,   828,   829,   830,   831,
     832,   833,   834,   835,     0,   836,   837,   838,   839,   840,
     841,   842,   843,   844,   845,     0,   846,     0,     0,     0,
       0,     0,   848,   849,   850,   851,   852,   853,   854,     0,
       0,     0,     0,   857,   858,     0,     0,     0,   859,   860,
     861,   862,   863,   864,   926,   927,   928,   929,   930,   931,
     932,   933,   934,   935,   936,   937,   938,   939,   940,   941,
     942,   943,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   865,   944,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   945,
       0,     0,     0,     0,   946,     0,   947,   948,   949,   950,
       0,   951,   952,   464,   866,     0,   953,     0,   867,   868,
       0,     0,     0,     0,  1016,   955,  1376,     0,   816,   817,
     818,   819,   820,     0,     0,     0,     0,   825,   826,   827,
       0,     0,     0,     0,     0,     0,     0,   828,   829,   830,
     831,   832,   833,   834,   835,     0,   836,   837,   838,   839,
     840,   841,   842,   843,   844,   845,     0,   846,     0,     0,
       0,     0,     0,   848,   849,   850,   851,   852,   853,   854,
       0,     0,     0,     0,   857,   858,     0,   865,   944,   859,
     860,   861,   862,   863,   864,   926,   927,   928,   929,   930,
     931,   932,   933,   934,   935,   936,   937,   938,   939,   940,
     941,   942,   943,     0,     0,     0,     0,     0,     0,     0,
       0,   945,     0,     0,     0,     0,   946,     0,   947,   948,
     949,   950,     0,   951,   952,   464,   866,     0,   953,     0,
     867,   868,     0,     0,     0,     0,  1016,   955,  1378,     0,
     816,   817,   818,   819,   820,     0,     0,     0,     0,   825,
     826,   827,     0,     0,     0,     0,     0,     0,     0,   828,
     829,   830,   831,   832,   833,   834,   835,     0,   836,   837,
     838,   839,   840,   841,   842,   843,   844,   845,     0,   846,
       0,     0,     0,     0,     0,   848,   849,   850,   851,   852,
     853,   854,     0,     0,     0,     0,   857,   858,     0,     0,
       0,   859,   860,   861,   862,   863,   864,   926,   927,   928,
     929,   930,   931,   932,   933,   934,   935,   936,   937,   938,
     939,   940,   941,   942,   943,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   865,   944,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   945,     0,     0,     0,     0,   946,     0,   947,
     948,   949,   950,     0,   951,   952,   464,   866,     0,   953,
       0,   867,   868,     0,     0,     0,     0,  1016,   955,  1383,
       0,   816,   817,   818,   819,   820,     0,     0,     0,     0,
     825,   826,   827,     0,     0,     0,     0,     0,     0,     0,
     828,   829,   830,   831,   832,   833,   834,   835,     0,   836,
     837,   838,   839,   840,   841,   842,   843,   844,   845,     0,
     846,     0,     0,     0,     0,     0,   848,   849,   850,   851,
     852,   853,   854,     0,     0,     0,     0,   857,   858,     0,
     865,   944,   859,   860,   861,   862,   863,   864,   926,   927,
     928,   929,   930,   931,   932,   933,   934,   935,   936,   937,
     938,   939,   940,   941,   942,   943,     0,     0,     0,     0,
       0,     0,     0,     0,   945,     0,     0,     0,     0,   946,
       0,   947,   948,   949,   950,     0,   951,   952,   464,   866,
       0,   953,     0,   867,   868,     0,     0,     0,     0,  1016,
     955,  1385,     0,   816,   817,   818,   819,   820,     0,     0,
       0,     0,   825,   826,   827,     0,     0,     0,     0,     0,
       0,     0,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,     0,     0,     0,   848,   849,
     850,   851,   852,   853,   854,     0,     0,     0,     0,   857,
     858,     0,     0,     0,   859,   860,   861,   862,   863,   864,
     926,   927,   928,   929,   930,   931,   932,   933,   934,   935,
     936,   937,   938,   939,   940,   941,   942,   943,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   865,   944,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   945,     0,     0,     0,     0,
     946,     0,   947,   948,   949,   950,     0,   951,   952,   464,
     866,     0,   953,     0,   867,   868,     0,     0,     0,     0,
    1016,   955,  1387,     0,   816,   817,   818,   819,   820,     0,
       0,     0,     0,   825,   826,   827,     0,     0,     0,     0,
       0,     0,     0,   828,   829,   830,   831,   832,   833,   834,
     835,     0,   836,   837,   838,   839,   840,   841,   842,   843,
     844,   845,     0,   846,     0,     0,     0,     0,     0,   848,
     849,   850,   851,   852,   853,   854,     0,     0,     0,     0,
     857,   858,     0,   865,   944,   859,   860,   861,   862,   863,
     864,   926,   927,   928,   929,   930,   931,   932,   933,   934,
     935,   936,   937,   938,   939,   940,   941,   942,   943,     0,
       0,     0,     0,     0,     0,     0,     0,   945,     0,     0,
       0,     0,   946,     0,   947,   948,   949,   950,     0,   951,
     952,   464,   866,     0,   953,     0,   867,   868,     0,     0,
       0,     0,  1016,   955,  1389,     0,   816,   817,   818,   819,
     820,     0,     0,     0,     0,   825,   826,   827,     0,     0,
       0,     0,     0,     0,     0,   828,   829,   830,   831,   832,
     833,   834,   835,     0,   836,   837,   838,   839,   840,   841,
     842,   843,   844,   845,     0,   846,     0,     0,     0,     0,
       0,   848,   849,   850,   851,   852,   853,   854,     0,     0,
       0,     0,   857,   858,     0,     0,     0,   859,   860,   861,
     862,   863,   864,   926,   927,   928,   929,   930,   931,   932,
     933,   934,   935,   936,   937,   938,   939,   940,   941,   942,
     943,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   865,   944,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   945,     0,
       0,     0,     0,   946,     0,   947,   948,   949,   950,     0,
     951,   952,   464,   866,     0,   953,     0,   867,   868,     0,
       0,     0,     0,  1016,   955,  1391,     0,   816,   817,   818,
     819,   820,     0,     0,     0,     0,   825,   826,   827,     0,
       0,     0,     0,     0,     0,     0,   828,   829,   830,   831,
     832,   833,   834,   835,     0,   836,   837,   838,   839,   840,
     841,   842,   843,   844,   845,     0,   846,     0,     0,     0,
       0,     0,   848,   849,   850,   851,   852,   853,   854,     0,
       0,     0,     0,   857,   858,     0,   865,   944,   859,   860,
     861,   862,   863,   864,   926,   927,   928,   929,   930,   931,
     932,   933,   934,   935,   936,   937,   938,   939,   940,   941,
     942,   943,     0,     0,     0,     0,     0,     0,     0,     0,
     945,     0,     0,     0,     0,   946,     0,   947,   948,   949,
     950,     0,   951,   952,   464,   866,     0,   953,     0,   867,
     868,     0,     0,     0,     0,  1016,   955,  1393,     0,   816,
     817,   818,   819,   820,     0,     0,     0,     0,   825,   826,
     827,     0,     0,     0,     0,     0,     0,     0,   828,   829,
     830,   831,   832,   833,   834,   835,     0,   836,   837,   838,
     839,   840,   841,   842,   843,   844,   845,     0,   846,     0,
       0,     0,     0,     0,   848,   849,   850,   851,   852,   853,
     854,     0,     0,     0,     0,   857,   858,     0,     0,     0,
     859,   860,   861,   862,   863,   864,   926,   927,   928,   929,
     930,   931,   932,   933,   934,   935,   936,   937,   938,   939,
     940,   941,   942,   943,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   865,   944,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   945,     0,     0,     0,     0,   946,     0,   947,   948,
     949,   950,     0,   951,   952,   464,   866,     0,   953,     0,
     867,   868,     0,     0,     0,     0,  1016,   955,  1395,     0,
     816,   817,   818,   819,   820,     0,     0,     0,     0,   825,
     826,   827,     0,     0,     0,     0,     0,     0,     0,   828,
     829,   830,   831,   832,   833,   834,   835,     0,   836,   837,
     838,   839,   840,   841,   842,   843,   844,   845,     0,   846,
       0,     0,     0,     0,     0,   848,   849,   850,   851,   852,
     853,   854,     0,     0,     0,     0,   857,   858,     0,   865,
     944,   859,   860,   861,   862,   863,   864,   926,   927,   928,
     929,   930,   931,   932,   933,   934,   935,   936,   937,   938,
     939,   940,   941,   942,   943,     0,     0,     0,     0,     0,
       0,     0,     0,   945,     0,     0,     0,     0,   946,     0,
     947,   948,   949,   950,     0,   951,   952,   464,   866,     0,
     953,     0,   867,   868,     0,     0,     0,     0,  1016,   955,
    1581,     0,   816,   817,   818,   819,   820,     0,     0,     0,
       0,   825,   826,   827,     0,     0,     0,     0,     0,     0,
       0,   828,   829,   830,   831,   832,   833,   834,   835,     0,
     836,   837,   838,   839,   840,   841,   842,   843,   844,   845,
       0,   846,     0,     0,     0,     0,     0,   848,   849,   850,
     851,   852,   853,   854,     0,     0,     0,     0,   857,   858,
       0,     0,     0,   859,   860,   861,   862,   863,   864,   926,
     927,   928,   929,   930,   931,   932,   933,   934,   935,   936,
     937,   938,   939,   940,   941,   942,   943,   816,   817,   818,
     819,   820,   821,   822,   823,   824,   825,   826,   827,     0,
       0,     0,     0,     0,     0,     0,   828,   829,   830,   831,
     832,   833,   834,   835,     0,   836,   837,   838,   839,   840,
     841,   842,   843,   844,   845,     0,   846,     0,     0,     0,
     847,     0,   848,   849,   850,   851,   852,   853,   854,   855,
     865,   944,   856,   857,   858,     0,     0,     0,   859,   860,
     861,   862,   863,   864,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   945,     0,     0,     0,     0,   946,
       0,   947,   948,   949,   950,     0,   951,   952,   464,   866,
       0,   953,     0,   867,   868,     0,     0,     0,     0,  1016,
     955,     0,     0,   816,   817,   818,   819,   820,     0,     0,
       0,     0,   825,   826,   827,     0,     0,     0,     0,     0,
       0,     0,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,     0,     0,     0,   848,   849,
     850,   851,   852,   853,   854,     0,     0,     0,     0,   857,
     858,     0,   865,   944,   859,   860,   861,   862,   863,   864,
     926,   927,   928,   929,   930,   931,   932,   933,   934,   935,
     936,   937,   938,   939,   940,   941,   942,   943,     0,     0,
       0,     0,     0,     0,     0,     0,   945,     0,     0,     0,
       0,   946,     0,   947,   948,   949,   950,     0,   951,   952,
     464,   866,     0,   953,     0,   867,   868,     0,     0,     0,
       0,  1016,   955,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   865,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,  1158,  1159,  1160,  1161,  1162,  1163,  1164,
    1165,  1166,  1167,  1168,  1169,  1170,  1171,  1172,  1173,  1174,
    1175,  1176,  1177,  1178,  1179,  1180,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   866,     0,     0,     0,
     867,   868,     0,     0,   869,     0,     0,  1227,     0,   816,
     817,   818,   819,   820,     0,     0,     0,     0,   825,   826,
     827,     0,     0,     0,     0,     0,     0,     0,   828,   829,
     830,   831,   832,   833,   834,   835,     0,   836,   837,   838,
     839,   840,   841,   842,   843,   844,   845,     0,   846,     0,
       0,     0,     0,     0,   848,   849,   850,   851,   852,   853,
     854,     0,     0,   865,   944,   857,   858,     0,     0,     0,
     859,   860,   861,   862,   863,   864,   926,   927,   928,   929,
     930,   931,   932,   933,   934,   935,   936,   937,   938,   939,
     940,   941,   942,   943,     0,     0,     0,   945,     0,     0,
       0,     0,   946,     0,   947,   948,   949,   950,     0,   951,
     952,   464,   866,     0,   953,     0,   867,   868,     0,     0,
       0,     0,   954,   955,   816,   817,   818,   819,   820,     0,
       0,     0,     0,   825,   826,   827,     0,     0,     0,     0,
       0,     0,     0,   828,   829,   830,   831,   832,   833,   834,
     835,     0,   836,   837,   838,   839,   840,   841,   842,   843,
     844,   845,     0,   846,     0,     0,     0,     0,     0,   848,
     849,   850,   851,   852,   853,   854,     0,     0,     0,     0,
     857,   858,     0,     0,     0,   859,   860,   861,   862,   863,
     864,   926,   927,   928,   929,   930,   931,   932,   933,   934,
     935,   936,   937,   938,   939,   940,   941,   942,   943,     0,
     816,   817,   818,   819,   820,     0,     0,     0,     0,   825,
     826,   827,     0,     0,     0,     0,     0,     0,     0,   828,
     829,   830,   831,   832,   833,   834,   835,     0,   836,   837,
     838,   839,   840,   841,   842,   843,   844,   845,     0,   846,
       0,     0,     0,     0,     0,   848,   849,   850,   851,   852,
     853,   854,     0,     0,     0,     0,   857,   858,     0,   865,
     944,   859,   860,   861,   862,   863,   864,   926,   927,   928,
     929,   930,   931,   932,   933,   934,   935,   936,   937,   938,
     939,   940,   941,   942,   943,     0,     0,     0,     0,     0,
       0,     0,     0,   945,     0,     0,     0,     0,   946,     0,
     947,   948,   949,   950,     0,   951,   952,   464,   866,     0,
     953,     0,   867,   868,     0,     0,     0,     0,   975,   955,
     816,   817,   818,   819,   820,     0,     0,     0,     0,   825,
     826,   827,     0,     0,     0,     0,     0,     0,     0,   828,
     829,   830,   831,   832,   833,   834,   835,     0,   836,   837,
     838,   839,   840,   841,   842,   843,   844,   845,     0,   846,
       0,     0,     0,     0,     0,   848,   849,   850,   851,   852,
     853,   854,     0,     0,   865,   944,   857,   858,     0,     0,
       0,   859,   860,   861,   862,   863,   864,   926,   927,   928,
     929,   930,   931,   932,   933,   934,   935,   936,   937,   938,
     939,   940,   941,   942,   943,     0,     0,     0,   945,     0,
       0,     0,     0,   946,     0,   947,   948,   949,   950,     0,
     951,   952,   464,   866,     0,   953,     0,   867,   868,     0,
       0,     0,     0,   977,   955,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     865,   944,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   945,     0,     0,     0,     0,   946,
       0,   947,   948,   949,   950,     0,   951,   952,   464,   866,
       0,   953,     0,   867,   868,     0,     0,     0,     0,  1016,
     955,   816,   817,   818,   819,   820,   821,   822,   823,   824,
     825,   826,   827,     0,     0,     0,     0,     0,     0,     0,
     828,   829,   830,   831,   832,   833,   834,   835,     0,   836,
     837,   838,   839,   840,   841,   842,   843,   844,   845,     0,
     846,     0,     0,     0,   847,     0,   848,   849,   850,   851,
     852,   853,   854,   855,     0,     0,   856,   857,   858,     0,
     865,   944,   859,   860,   861,   862,   863,   864,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   945,     0,     0,     0,     0,   946,
       0,   947,   948,   949,   950,     0,   951,   952,  1531,   866,
       0,   953,     0,   867,   868,     0,     0,     0,     0,  1016,
     955,  1142,     0,   816,   817,   818,   819,   820,   821,   822,
     823,   824,   825,   826,   827,     0,     0,     0,     0,     0,
       0,     0,   828,   829,   830,   831,   832,   833,   834,   835,
       0,   836,   837,   838,   839,   840,   841,   842,   843,   844,
     845,     0,   846,     0,     0,     0,   847,     0,   848,   849,
     850,   851,   852,   853,   854,   855,     0,     0,   856,   857,
     858,     0,     0,     0,   859,   860,   861,   862,   863,   864,
     816,   817,   818,   819,   820,   821,   822,   823,   824,   825,
     826,   827,     0,     0,     0,     0,     0,     0,     0,   828,
     829,   830,   831,   832,   833,   834,   835,     0,   836,   837,
     838,   839,   840,   841,   842,   843,   844,   845,     0,   846,
       0,     0,     0,   847,     0,   848,   849,   850,   851,   852,
     853,   854,   855,     0,     0,   856,   857,   858,     0,     0,
       0,   859,   860,   861,   862,   863,   864,     0,     0,     0,
       0,   865,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     866,     0,     0,     0,   867,   868,     0,     0,   869,     0,
       0,  1227,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   865,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   866,     0,     0,     0,   867,   868,     0,     0,
     869,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     865,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   866,
       0,     0,     0,   867,   868,     0,     0,   869
};

static const yytype_int16 yycheck[] =
{
     204,   173,   378,   207,   203,     1,  1082,   938,  1030,   940,
     783,   942,     1,   786,   965,     1,   789,     1,   917,     1,
     919,     1,   921,     1,   923,   798,   925,   231,   959,   233,
      57,   235,   781,   237,   783,     1,     1,   786,     1,   297,
     789,    62,     1,     1,     1,   278,    62,   220,     1,   798,
       1,   278,     1,   311,    62,   308,   781,     1,   783,     1,
     297,   786,     1,   297,   789,     1,     1,     1,   326,     1,
     278,   308,   325,   798,    56,    57,   297,   311,   297,     0,
     314,     1,   319,     1,   321,     1,   781,   308,   783,   308,
       1,   786,     1,     1,   789,     1,   300,   301,   302,   303,
     304,   305,   306,   798,     1,     1,    16,     1,   957,     1,
       1,   312,   961,   314,     1,     1,     1,    61,     1,     1,
       1,     1,   871,   297,   500,    88,    89,    90,    91,   333,
     334,   335,     1,     1,     1,     1,   278,   311,   887,     1,
     889,     1,   891,     1,     1,     1,   871,   896,     1,     1,
      61,   301,    88,    89,    90,    91,     1,   278,     1,     1,
       1,   311,   887,     1,   889,     1,   891,     1,     1,     1,
      61,   896,    88,    89,    90,    91,   871,     1,   311,   779,
       1,   314,   955,   319,   784,   321,   278,   787,     1,    62,
     790,     1,   887,    61,   889,     1,   891,   871,     1,    61,
       1,   896,     1,   407,   408,   954,   955,     1,     1,   299,
     300,   301,     1,   887,   278,   889,     1,   891,     1,     1,
       1,   297,   896,     1,     1,   319,   975,   321,   977,   954,
     955,     1,     1,   809,   810,   311,     1,     1,   314,   278,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     975,     1,   977,     1,     1,  1154,    19,   323,     1,   954,
     955,     1,     1,     1,     1,     1,     1,  1016,  1017,   278,
       1,     1,     1,     1,   319,   297,   321,     1,   278,   278,
     975,  1030,   977,     1,   311,   312,   308,   319,     1,   321,
     311,  1016,  1017,   278,     1,   311,   319,   319,   321,   321,
       1,   278,   781,   311,   783,  1030,  1079,   786,     1,  1260,
     789,     1,  1085,     1,     1,     1,  1065,     1,     1,   798,
       1,  1016,  1017,     1,   320,   311,   312,   313,   314,   315,
    1079,   315,   505,   311,   323,  1030,  1085,   315,   301,   325,
    1065,   325,   324,  1017,    20,   325,     1,   325,   311,   312,
     313,   314,   315,   311,  1079,   312,  1030,   323,   323,   322,
    1085,     1,   325,  1439,   323,   301,   325,   311,   312,   322,
     314,   315,   323,   322,   325,   311,   312,   313,   314,   315,
     322,   325,   321,   322,  1079,   301,   322,   322,   322,   325,
    1085,   323,   871,   325,  1143,   311,   312,   313,   314,   315,
     311,   312,   322,   314,   315,   323,   314,   325,   887,   325,
     889,  1433,   891,   322,   325,     1,   322,   896,  1143,   311,
     311,   312,   314,   314,   315,   322,  1357,   323,   322,   325,
     321,   263,   808,  1364,   325,   322,   322,   322,   311,   322,
     322,   322,   322,   311,   312,   314,   314,   315,  1143,   311,
     312,   311,   314,   315,  1227,   322,   322,   325,   311,   312,
     313,   314,   315,   325,   322,   322,   322,     1,   278,  1143,
     322,     1,   325,   297,     1,   954,   955,   322,  1227,   322,
     322,   322,   314,     1,   322,   317,   322,   311,   322,   322,
     311,  1264,  1265,  1266,  1267,   278,   975,   321,   977,   312,
     321,   314,  1227,  1579,   314,     1,   312,     1,   314,   312,
     311,   314,   311,   314,     1,  1264,  1265,  1266,  1267,   312,
     314,   314,  1271,   312,   900,   314,     1,   312,  1277,   314,
     312,   314,  1227,   314,   312,   312,   314,  1016,  1017,  1264,
    1265,  1266,  1267,   312,   314,   314,  1271,   312,   312,   314,
     314,  1030,  1277,   314,   314,   314,   314,   314,   314,   314,
     314,   314,   314,   301,   314,    62,   314,   314,   311,  1264,
    1265,  1266,  1267,   311,   314,   314,  1271,   314,   314,   314,
       1,     1,  1277,   314,   314,   314,   314,   311,   312,   313,
     297,    21,     1,   311,   312,   313,   297,  1271,   311,   312,
    1079,     1,     1,  1277,   311,   777,  1085,   297,   301,   297,
     311,   297,     1,   297,   297,  1514,   297,     1,   311,   297,
       1,   311,     1,   311,   311,   311,     1,   311,   311,     1,
     311,     1,     1,   311,   278,     1,     1,     1,     1,     1,
       1,     1,   297,  1019,     1,     1,   781,  1023,   783,     1,
       1,   786,     1,     1,   789,     1,   311,   297,     1,     1,
       1,     1,     1,   798,  1143,     1,     1,     1,     1,     1,
       1,   311,   278,   278,     1,     1,     1,     1,   278,     1,
       1,   278,     1,  1432,  1433,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,   278,     1,
       1,     1,     1,     1,     1,   278,   314,  1432,  1433,     1,
     278,   297,     1,     1,     1,     1,     1,     1,  1467,  1468,
    1469,  1470,   781,     1,   783,   311,     1,   786,     1,     1,
     789,     1,     1,     1,     1,     1,   871,  1432,  1433,   798,
       1,     1,  1467,  1468,  1469,  1470,     1,   319,  1227,   321,
     278,     1,   887,     1,   889,  1528,   891,     1,  1432,  1433,
     278,   896,   319,   297,   321,   311,   312,   297,   314,     1,
       1,     1,  1467,  1468,  1469,  1470,     1,   311,   278,  1528,
       1,   311,   311,   278,   311,  1264,  1265,  1266,  1267,     1,
       1,   278,  1271,  1467,  1468,  1469,  1470,  1001,  1277,   278,
       1,     1,   319,  1528,   321,     1,     1,  1580,     1,     1,
    1583,     1,   871,   278,   311,   311,  1015,   311,   278,   278,
     955,     1,  1595,  1596,  1023,     1,     1,   319,   887,   321,
     889,  1580,   891,  1528,  1583,  1584,   311,   896,   278,   278,
      88,    89,    90,    91,   278,  1594,  1595,  1596,     1,  1598,
    1599,  1600,   278,   311,   312,  1580,   314,     1,  1583,  1584,
       1,     1,     1,     1,  1036,   319,  1038,   321,  1040,  1594,
    1595,  1596,     1,  1598,  1599,  1600,    88,    89,    90,    91,
    1084,     1,  1017,     1,     1,  1580,     1,     1,  1583,  1584,
     311,   311,     1,     1,     1,  1030,   955,   278,     1,  1594,
    1595,  1596,   311,  1598,  1599,  1600,    56,    57,   286,   287,
    1584,   311,   311,   291,   292,   311,   312,   278,   314,   278,
    1594,   278,   311,   311,  1598,  1599,  1600,   311,    14,    15,
    1065,   919,   311,   921,   278,   923,   311,   925,   278,   311,
       1,   311,   311,   311,  1079,   311,   311,   311,   311,   311,
    1085,   311,   319,  1432,  1433,   311,   278,   278,  1017,   311,
     311,   278,   311,   311,   319,   311,   321,   314,   311,   311,
     311,  1030,   311,   311,   278,   311,   311,   311,   311,   311,
     311,   821,   822,   823,   311,   311,   311,   311,  1467,  1468,
    1469,  1470,   311,   278,   323,   311,   311,   311,   311,   311,
     311,   311,   311,   311,   311,   311,   311,   847,  1143,   311,
     311,   311,   311,   311,   311,   855,   856,   311,   311,   311,
    1079,   278,   311,   311,   311,   311,  1085,   311,   278,    88,
      89,    90,    91,   311,   278,   278,   311,   278,   311,   311,
     278,   311,   311,   311,   311,   311,   311,   278,   278,  1528,
     311,   311,   278,   301,   286,   287,   311,   278,   290,   291,
     292,   286,   287,   319,  1440,   321,   291,   292,   293,   294,
     295,   296,   319,   278,   321,   286,   287,   278,   278,   290,
     291,   292,   311,   278,  1143,   278,   278,   278,   278,   301,
     286,   287,  1227,   278,   290,   291,   292,   311,   312,   278,
     314,  1580,   278,   278,  1583,  1584,   286,   287,   948,   949,
     950,   291,   292,     1,   278,  1594,  1595,  1596,   278,  1598,
    1599,  1600,   319,   278,   321,   278,   278,   954,   311,  1264,
    1265,  1266,  1267,   973,   278,   297,  1271,   278,   278,   278,
     278,   319,  1277,   321,   984,   319,   308,   321,   975,   278,
     977,   278,   278,   214,   215,   216,   217,   319,   278,   321,
     278,   278,   278,   278,   278,   278,  1154,  1371,  1227,   278,
     278,   278,   328,   278,   324,   278,   297,   298,   299,   300,
     301,   278,   278,    71,    72,    73,    74,   278,    76,  1016,
      78,   297,    80,   265,   266,   267,   268,   269,   270,   271,
     272,   273,   308,   297,   278,  1264,  1265,  1266,  1267,   319,
     278,   321,  1271,   319,   308,   321,   278,   319,  1277,   311,
     278,   278,  1062,   278,   278,   319,   278,   321,   278,   278,
     311,   312,   313,   314,   315,   311,   312,   313,   314,   315,
     312,   322,   301,   278,   325,   278,   278,   278,   278,   325,
     278,   278,   311,   312,   313,   314,   315,   278,   278,   278,
     278,   278,   278,   322,   278,   278,   325,   293,   294,   295,
     296,   297,   298,   299,   300,   301,   278,   278,   278,   278,
    1120,  1121,  1122,   278,   278,   278,   278,   278,   278,   278,
     278,  1463,  1132,  1133,  1466,   278,   278,  1432,  1433,   278,
     278,   278,   278,   278,  1508,  1145,   278,   278,   278,   278,
     278,  1151,  1152,   278,  1154,   278,   278,   278,  1158,  1159,
    1160,  1161,  1162,  1163,  1164,   278,   278,   278,   278,   278,
     278,   278,  1467,  1468,  1469,  1470,  1176,  1177,  1178,  1179,
    1180,  1181,  1182,   279,   280,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,   278,   278,   278,   278,
     278,   278,   278,  1432,  1433,   278,   278,   311,   311,   311,
     311,   311,   311,   311,   311,   311,   311,   323,   311,   311,
     311,   311,   311,  1528,   311,   311,   311,   311,   311,   107,
     278,   319,   326,   278,   251,   251,   311,   311,  1467,  1468,
    1469,  1470,   311,   311,  1254,   279,   280,   281,   282,   283,
     284,   285,   286,   287,   288,   289,   290,   291,   292,   293,
     294,   295,   296,   297,   298,   299,   300,   301,   311,   311,
     311,   311,   311,   311,   328,  1580,   308,   328,  1583,  1584,
     315,   311,   318,   311,   321,   308,   319,   321,   314,  1594,
    1595,  1596,   323,  1598,  1599,  1600,   308,   326,   322,  1528,
     279,   280,   281,   282,   283,   284,   285,   286,   287,   288,
     289,   290,   291,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,   283,   284,   285,   286,   287,   288,   289,
     290,   291,   292,   293,   294,   295,   296,   297,   298,   299,
     300,   301,   321,   326,   326,   322,   322,   322,   322,   322,
     322,  1580,   322,   322,  1583,  1584,   322,   322,   320,   320,
     328,   328,   326,   326,   319,  1594,  1595,  1596,   326,  1598,
    1599,  1600,   279,   280,   281,   282,   283,   284,   285,   286,
     287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,   284,   285,   286,   287,   288,
     289,   290,   291,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,   326,   321,   323,   322,   322,   314,   321,
     321,   321,   321,   321,   321,   308,   321,   321,   321,   311,
       0,     1,   322,  1443,   325,   323,   323,   323,   323,  1449,
     311,   321,   321,   312,    14,    15,    16,    17,    18,    19,
      20,    21,   286,   287,   288,   289,   290,   291,   292,   293,
     294,   295,   296,   297,   298,   299,   300,   301,    38,   321,
     321,    41,    42,    43,    44,    45,   321,   321,   278,   278,
     278,   278,   321,   324,   321,   325,   319,    57,   279,   280,
     281,   282,   283,   284,   285,   286,   287,   288,   289,   290,
     291,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,   321,   321,   319,   321,  1525,   321,   321,   321,   321,
     321,    47,   312,  1533,    94,    95,    96,    97,    98,    99,
     100,   101,   102,   103,   104,   105,   106,   321,   108,   109,
     110,   111,   112,   113,   114,   115,   116,   117,   118,   119,
     120,   121,   122,   123,   124,   125,   126,   127,   128,   129,
     130,   131,   132,   133,   134,   135,   136,   137,   138,   139,
     140,   141,   142,   143,   144,   145,   146,   147,   148,   149,
     150,   151,   152,   153,   154,   155,   156,   157,   158,   159,
     160,   161,   162,   163,   164,   165,   166,   167,   168,   169,
     170,   171,   172,   173,   174,   175,   176,   177,   178,   179,
     180,   181,   182,   183,   184,   185,   186,   187,   188,   189,
     190,   191,   192,   193,   194,   195,   196,   197,   198,   199,
     200,   201,   202,   203,   204,   205,   206,   207,   208,   209,
     210,   211,   212,   213,   321,   321,   321,   321,   218,   219,
     220,   221,   222,   223,   224,   225,   226,   227,   228,   229,
     230,   231,   232,   233,   234,   235,   236,   237,   238,   239,
     240,   241,   242,   243,   244,   245,   246,   247,   248,   249,
     250,   321,   252,   253,   254,   255,   256,   257,   258,   259,
     260,   261,   262,   321,   321,   321,   321,   321,   321,   321,
     321,   321,   321,   321,   321,   275,   276,   277,   321,   321,
     279,   280,   281,   282,   283,   284,   285,   286,   287,   288,
     289,   290,   291,   292,   293,   294,   295,   296,   297,   298,
     299,   300,   301,   321,   321,   321,   321,   321,   321,   321,
     319,   314,   312,   321,   321,   321,   321,   328,   328,   321,
     320,   314,   321,   321,   321,   321,     1,   327,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
     321,   321,   326,   319,   278,   308,   321,    22,    23,    24,
      25,    26,    27,    28,    29,   321,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,   311,    42,   311,   311,
     311,    46,   311,    48,    49,    50,    51,    52,    53,    54,
      55,   311,   311,    58,    59,    60,   311,   311,   311,    64,
      65,    66,    67,    68,    69,     1,   311,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,   311,
     311,   311,   311,   325,   308,   321,    22,    23,    24,    25,
      26,    27,    28,    29,   321,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,   300,    42,   314,   314,   324,
      46,   328,    48,    49,    50,    51,    52,    53,    54,    55,
     311,   321,    58,    59,    60,   321,   328,   321,    64,    65,
      66,    67,    68,    69,     1,   321,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,   321,   321,
     321,   321,   321,   321,   321,    22,    23,    24,    25,    26,
      27,    28,    29,   321,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,   321,    42,   321,   321,   321,    46,
     321,    48,    49,    50,    51,    52,    53,    54,    55,   321,
     321,    58,    59,    60,   321,   321,   321,    64,    65,    66,
      67,    68,    69,     1,   321,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,   321,   321,   326,
     321,   321,   328,   328,    22,    23,    24,    25,    26,    27,
      28,    29,   321,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,   321,    42,   321,   321,   326,    46,   326,
      48,    49,    50,    51,    52,    53,    54,    55,   263,   328,
      58,    59,    60,   328,   181,   900,    64,    65,    66,    67,
      68,    69,   806,   775,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,  1122,   777,  1077,
     340,  1124,   501,   308,   341,  1124,    -1,   312,  1447,    -1,
    1255,   316,   317,  1525,   319,   320,   321,   322,   323,    -1,
    1509,    -1,  1533,   328,    -1,    -1,    -1,   263,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   279,   280,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,
     316,   317,    -1,   319,   320,   321,   322,   323,    -1,    -1,
      -1,    -1,   328,    -1,    -1,    -1,   263,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   279,   280,   281,   282,   283,   284,   285,   286,
     287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
     297,   298,   299,   300,   301,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,   316,
     317,    -1,   319,   320,   321,    -1,   323,    -1,    -1,    -1,
      -1,   328,    -1,    -1,    -1,   263,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   279,   280,   281,   282,   283,   284,   285,   286,   287,
     288,   289,   290,   291,   292,   293,   294,   295,   296,   297,
     298,   299,   300,   301,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,   316,   317,
       1,   319,   320,   321,    -1,   323,    -1,    -1,    -1,    -1,
     328,    -1,    -1,    14,    15,    16,    17,    18,    19,    20,
      21,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,    -1,    -1,
      41,    42,    43,    44,    45,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    57,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,    -1,    -1,    -1,
      -1,    -1,    -1,    94,    95,    96,    97,    98,    99,   100,
     101,   102,   103,   104,   105,   106,   321,   108,   109,   110,
     111,   112,   113,   114,   115,   116,   117,   118,   119,   120,
     121,   122,   123,   124,   125,   126,   127,   128,   129,   130,
     131,   132,   133,   134,   135,   136,   137,   138,   139,   140,
     141,   142,   143,   144,   145,   146,   147,   148,   149,   150,
     151,   152,   153,   154,   155,   156,   157,   158,   159,   160,
     161,   162,   163,   164,   165,   166,   167,   168,   169,   170,
     171,   172,   173,   174,   175,   176,   177,   178,   179,   180,
     181,   182,   183,   184,   185,   186,   187,   188,   189,   190,
     191,   192,   193,   194,   195,   196,   197,   198,   199,   200,
     201,   202,   203,   204,   205,   206,   207,   208,   209,   210,
     211,   212,   213,    -1,    -1,    -1,    -1,   218,   219,   220,
     221,   222,   223,   224,   225,   226,   227,   228,   229,   230,
     231,   232,   233,   234,   235,   236,   237,   238,   239,   240,
     241,   242,   243,   244,   245,   246,   247,   248,   249,   250,
      -1,   252,   253,   254,   255,   256,   257,   258,   259,   260,
     261,   262,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   275,   276,   277,   280,   281,   282,
     283,   284,   285,   286,   287,   288,   289,   290,   291,   292,
     293,   294,   295,   296,   297,   298,   299,   300,   301,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
       1,   312,     3,     4,     5,     6,     7,    -1,    -1,   320,
      -1,    12,    13,    14,    -1,    -1,   327,    -1,    -1,    -1,
      -1,    22,    23,    24,    25,    26,    27,    28,    29,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    -1,    -1,    -1,    -1,    59,    60,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    87,     1,    -1,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,
      24,    25,    26,    27,    28,    29,    -1,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    -1,
      -1,    -1,    46,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    -1,    -1,    -1,
      64,    65,    66,    67,    68,    69,     1,    -1,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,
      25,    26,    27,    28,    29,    -1,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    -1,    42,    -1,    -1,
      -1,    46,    -1,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    -1,    -1,    -1,    64,
      65,    66,    67,    68,    69,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   263,   264,   282,   283,   284,   285,   286,   287,
     288,   289,   290,   291,   292,   293,   294,   295,   296,   297,
     298,   299,   300,   301,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,
      -1,   302,    -1,   304,   305,   306,   307,    -1,   309,   310,
     311,   312,    -1,   314,   315,   316,   317,    -1,    -1,    -1,
      -1,   322,   323,    -1,   325,    -1,    -1,    -1,    -1,     1,
      -1,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,   263,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    -1,
      42,    -1,    -1,    -1,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    -1,
      -1,    -1,    64,    65,    66,    67,    68,    69,   312,    -1,
      -1,    -1,   316,   317,    -1,    -1,   320,    -1,    -1,    -1,
     324,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,    -1,    -1,
      -1,   316,   317,    -1,    -1,   320,    -1,    -1,     1,   324,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      -1,    -1,    -1,    46,    -1,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    69,     1,    -1,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,
      24,    25,    26,    27,    28,    29,    -1,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    -1,
      -1,   263,    46,    -1,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    58,    59,    60,    -1,    -1,    -1,
      64,    65,    66,    67,    68,    69,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     312,    -1,    -1,    -1,   316,   317,    -1,    -1,   320,    -1,
      -1,     1,   324,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,    -1,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    58,    59,
      60,    -1,    -1,    -1,    64,    65,    66,    67,    68,    69,
       1,    -1,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,
     263,    22,    23,    24,    25,    26,    27,    28,    29,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    -1,    -1,    -1,    46,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    58,    59,    60,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    69,   312,
      -1,    -1,    -1,   316,   317,    -1,    -1,   320,    -1,    -1,
      -1,   324,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,    -1,
      -1,    -1,   316,   317,    -1,    -1,   320,    -1,    -1,     1,
     324,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    -1,
      42,    -1,    -1,   263,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    -1,    -1,    58,    59,    60,    -1,
      -1,    -1,    64,    65,    66,    67,    68,    69,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   312,    -1,    -1,    -1,   316,   317,    -1,    -1,
     320,    -1,    -1,    -1,   324,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   263,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   312,    -1,    -1,    -1,   316,   317,    -1,    -1,   320,
      -1,    -1,     1,   324,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    22,    23,    24,    25,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    -1,    42,    -1,    -1,    -1,    46,    -1,    48,
      49,    50,    51,    52,    53,    54,    55,    -1,    -1,    58,
      59,    60,    -1,    -1,    -1,    64,    65,    66,    67,    68,
      69,     1,    -1,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,   263,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,    -1,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    -1,    -1,    58,    59,
      60,    -1,    -1,    -1,    64,    65,    66,    67,    68,    69,
     312,    -1,    -1,    -1,   316,   317,    -1,    -1,   320,    -1,
      -1,     1,   324,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,    -1,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    -1,    -1,    58,    59,
      60,    -1,    -1,    -1,    64,    65,    66,    67,    68,    69,
       1,    -1,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    22,    23,    24,    25,    26,    27,    28,    29,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    -1,    -1,   263,    46,    -1,    48,    49,    50,
      51,    52,    53,    54,    55,    -1,    -1,    58,    59,    60,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    69,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   312,    -1,    -1,    -1,   316,   317,    -1,
      -1,   320,    -1,    -1,    -1,   324,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   263,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   312,    -1,    -1,    -1,   316,   317,    -1,    -1,
     320,    -1,    -1,     1,   324,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    -1,    -1,    -1,
      -1,    -1,    -1,   263,    22,    23,    24,    25,    26,    27,
      28,    29,    -1,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    -1,    42,    -1,    -1,    -1,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    -1,    -1,
      58,    59,    60,    -1,    -1,    -1,    64,    65,    66,    67,
      68,    69,   312,    -1,    -1,    -1,   316,   317,    -1,    -1,
     320,    -1,    -1,    -1,   324,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   263,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   312,    -1,    -1,    -1,   316,   317,    -1,    -1,   320,
      -1,    -1,     1,   324,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    22,    23,    24,    25,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    -1,    42,    -1,    -1,    -1,    46,    -1,    48,
      49,    50,    51,    52,    53,    54,    55,    -1,    -1,    58,
      59,    60,    -1,    -1,    -1,    64,    65,    66,    67,    68,
      69,     1,    -1,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,   263,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    -1,    -1,    58,    59,
      60,    -1,    -1,    -1,    64,    65,    66,    67,    68,    69,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,   316,   317,
      -1,    -1,   320,    -1,    -1,     1,   324,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,
      26,    27,    28,    29,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,
      46,    -1,    48,    49,    50,    51,    52,    53,    54,    55,
      -1,    -1,    58,    59,    60,    -1,    -1,    -1,    64,    65,
      66,    67,    68,    69,     1,    -1,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,   263,    22,    23,    24,    25,    26,
      27,    28,    29,    -1,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,    46,
      -1,    48,    49,    50,    51,    52,    53,    54,    55,    -1,
      -1,    58,    59,    60,    -1,    -1,    -1,    64,    65,    66,
      67,    68,    69,   312,    -1,    -1,    -1,   316,   317,    -1,
      -1,   320,    -1,    -1,    -1,   324,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   263,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   312,    -1,    -1,    -1,   316,   317,    -1,    -1,
     320,    -1,    -1,     1,   324,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    22,    23,    24,    25,    26,    27,
      28,    29,    -1,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    -1,    42,    -1,    -1,   263,    46,    -1,
      48,    49,    50,    51,    52,    53,    54,    55,    -1,    -1,
      58,    59,    60,    -1,    -1,    -1,    64,    65,    66,    67,
      68,    69,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,
     316,   317,    -1,    -1,   320,    -1,    -1,    -1,   324,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   263,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,   316,
     317,    -1,    -1,   320,    -1,    -1,     1,   324,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,
      25,    26,    27,    28,    29,    -1,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    -1,    42,    -1,    -1,
      -1,    46,    -1,    48,    49,    50,    51,    52,    53,    54,
      55,    -1,    -1,    58,    59,    60,    -1,    -1,    -1,    64,
      65,    66,    67,    68,    69,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   263,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,   316,   317,
      -1,    -1,   320,    -1,    -1,     1,   324,     3,     4,     5,
       6,     7,    -1,    -1,    -1,    -1,    12,    13,    14,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,
      26,    27,    28,    29,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,
      -1,    -1,    48,    49,    50,    51,    52,    53,    54,    -1,
      -1,    -1,    -1,    59,    60,    -1,    -1,    -1,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    88,    89,    90,    91,    92,    93,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,    -1,    -1,
      -1,   316,   317,    -1,    -1,   320,    -1,    -1,    -1,   324,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,     1,    -1,     3,     4,
       5,     6,     7,    -1,    -1,    -1,    -1,    12,    13,    14,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,
      25,    26,    27,    28,    29,    -1,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    -1,    42,    -1,    -1,
      -1,    -1,    -1,    48,    49,    50,    51,    52,    53,    54,
      -1,    -1,    -1,    -1,    59,    60,    -1,   263,   264,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    -1,
      -1,   297,    -1,    -1,    -1,   301,   302,    -1,   304,   305,
     306,   307,    -1,   309,   310,   311,   312,    -1,   314,    -1,
     316,   317,    -1,    -1,    -1,    -1,   322,   323,     1,    -1,
       3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,
      13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,
      53,    54,    -1,    -1,    -1,    -1,    59,    60,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,   264,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   297,    -1,    -1,    -1,   301,   302,    -1,   304,
     305,   306,   307,    -1,   309,   310,   311,   312,    -1,   314,
      -1,   316,   317,    -1,    -1,    -1,    -1,   322,   323,     1,
      -1,     3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    -1,
      42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,
      52,    53,    54,    -1,    -1,    -1,    -1,    59,    60,    -1,
     263,   264,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,
      -1,   304,   305,   306,   307,    -1,   309,   310,   311,   312,
      -1,   314,    -1,   316,   317,    -1,    -1,    -1,   321,   322,
     323,     1,    -1,     3,     4,     5,     6,     7,    -1,    -1,
      -1,    -1,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,
      50,    51,    52,    53,    54,    -1,    -1,    -1,    -1,    59,
      60,    -1,    -1,    -1,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   263,   264,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,
     302,    -1,   304,   305,   306,   307,    -1,   309,   310,   311,
     312,    -1,   314,    -1,   316,   317,    -1,    -1,    -1,   321,
     322,   323,     1,    -1,     3,     4,     5,     6,     7,    -1,
      -1,    -1,    -1,    12,    13,    14,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    22,    23,    24,    25,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,
      49,    50,    51,    52,    53,    54,    -1,    -1,    -1,    -1,
      59,    60,    -1,   263,   264,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,
      -1,    -1,   302,    -1,   304,   305,   306,   307,    -1,   309,
     310,   311,   312,    -1,   314,    -1,   316,   317,    -1,    -1,
      -1,   321,   322,   323,     1,    -1,     3,     4,     5,     6,
       7,    -1,    -1,    -1,    -1,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,    26,
      27,    28,    29,    -1,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,    -1,
      -1,    48,    49,    50,    51,    52,    53,    54,    -1,    -1,
      -1,    -1,    59,    60,    -1,    -1,    -1,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   263,   264,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,
      -1,   300,    -1,   302,    -1,   304,   305,   306,   307,    -1,
     309,   310,   311,   312,    -1,   314,    -1,   316,   317,    -1,
      -1,    -1,    -1,   322,   323,     1,    -1,     3,     4,     5,
       6,     7,    -1,    -1,    -1,    -1,    12,    13,    14,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,
      26,    27,    28,    29,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,
      -1,    -1,    48,    49,    50,    51,    52,    53,    54,    -1,
      -1,    -1,    -1,    59,    60,    -1,   263,   264,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     297,    -1,    -1,    -1,    -1,   302,    -1,   304,   305,   306,
     307,    -1,   309,   310,   311,   312,    -1,   314,    -1,   316,
     317,    -1,    -1,    -1,    -1,   322,   323,     1,    -1,     3,
       4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,    13,
      14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,
      24,    25,    26,    27,    28,    29,    -1,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    -1,
      -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,    53,
      54,    -1,    -1,    -1,    -1,    59,    60,    -1,    -1,    -1,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,   264,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   297,    -1,    -1,    -1,    -1,   302,    -1,   304,   305,
     306,   307,    -1,   309,   310,   311,   312,    -1,   314,    -1,
     316,   317,    -1,    -1,    -1,    -1,   322,   323,     1,    -1,
       3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,
      13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,
      53,    54,    -1,    -1,    -1,    -1,    59,    60,    -1,   263,
     264,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,    -1,
     304,   305,   306,   307,    -1,   309,   310,   311,   312,    -1,
     314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,   323,
       1,    -1,     3,     4,     5,     6,     7,    -1,    -1,    -1,
      -1,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    22,    23,    24,    25,    26,    27,    28,    29,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    -1,    -1,    -1,    -1,    59,    60,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    87,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     263,   264,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,
      -1,   304,   305,   306,   307,    -1,   309,   310,   311,   312,
      -1,   314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,
     323,     1,    -1,     3,     4,     5,     6,     7,    -1,    -1,
      -1,    -1,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,
      50,    51,    52,    53,    54,    -1,    -1,    -1,    -1,    59,
      60,    -1,   263,   264,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,
      -1,   302,    -1,   304,   305,   306,   307,    -1,   309,   310,
     311,   312,    -1,   314,    -1,   316,   317,    -1,    -1,    -1,
      -1,   322,   323,     1,    -1,     3,     4,     5,     6,     7,
      -1,    -1,    -1,    -1,    12,    13,    14,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    22,    23,    24,    25,    26,    27,
      28,    29,    -1,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    49,    50,    51,    52,    53,    54,    -1,    -1,    -1,
      -1,    59,    60,    -1,    -1,    -1,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   263,   264,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,
      -1,    -1,   302,    -1,   304,   305,   306,   307,    -1,   309,
     310,   311,   312,    -1,   314,    -1,   316,   317,    -1,    -1,
      -1,    -1,   322,   323,     1,    -1,     3,     4,     5,     6,
       7,    -1,    -1,    -1,    -1,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,    26,
      27,    28,    29,    -1,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,    -1,
      -1,    48,    49,    50,    51,    52,    53,    54,    -1,    -1,
      -1,    -1,    59,    60,    -1,   263,   264,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   297,
      -1,    -1,    -1,    -1,   302,    -1,   304,   305,   306,   307,
      -1,   309,   310,   311,   312,    -1,   314,    -1,   316,   317,
      -1,    -1,    -1,    -1,   322,   323,     1,    -1,     3,     4,
       5,     6,     7,    -1,    -1,    -1,    -1,    12,    13,    14,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,
      25,    26,    27,    28,    29,    -1,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    -1,    42,    -1,    -1,
      -1,    -1,    -1,    48,    49,    50,    51,    52,    53,    54,
      -1,    -1,    -1,    -1,    59,    60,    -1,    -1,    -1,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   263,   264,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     297,    -1,    -1,    -1,    -1,   302,    -1,   304,   305,   306,
     307,    -1,   309,   310,   311,   312,    -1,   314,    -1,   316,
     317,    -1,    -1,    -1,    -1,   322,   323,     1,    -1,     3,
       4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,    13,
      14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,
      24,    25,    26,    27,    28,    29,    -1,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    -1,
      -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,    53,
      54,    -1,    -1,    -1,    -1,    59,    60,    -1,   263,   264,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   297,    -1,    -1,    -1,    -1,   302,    -1,   304,
     305,   306,   307,    -1,   309,   310,   311,   312,    -1,   314,
      -1,   316,   317,    -1,    -1,    -1,    -1,   322,   323,     1,
      -1,     3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    -1,
      42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,
      52,    53,    54,    -1,    -1,    -1,    -1,    59,    60,    -1,
      -1,    -1,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,
     264,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,    -1,
     304,   305,   306,   307,    -1,   309,   310,   311,   312,    -1,
     314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,   323,
       1,    -1,     3,     4,     5,     6,     7,    -1,    -1,    -1,
      -1,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    22,    23,    24,    25,    26,    27,    28,    29,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    -1,    -1,    -1,    -1,    59,    60,
      -1,   263,   264,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    87,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,
     302,    -1,   304,   305,   306,   307,    -1,   309,   310,   311,
     312,    -1,   314,    -1,   316,   317,    -1,    -1,    -1,    -1,
     322,   323,     1,    -1,     3,     4,     5,     6,     7,    -1,
      -1,    -1,    -1,    12,    13,    14,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    22,    23,    24,    25,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,
      49,    50,    51,    52,    53,    54,    -1,    -1,    -1,    -1,
      59,    60,    -1,    -1,    -1,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   263,   264,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,
      -1,   302,    -1,   304,   305,   306,   307,    -1,   309,   310,
     311,   312,    -1,   314,    -1,   316,   317,    -1,    -1,    -1,
      -1,   322,   323,     1,    -1,     3,     4,     5,     6,     7,
      -1,    -1,    -1,    -1,    12,    13,    14,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    22,    23,    24,    25,    26,    27,
      28,    29,    -1,    31,    32,    33,    34,    35,    36,    37,
      38,    39,    40,    -1,    42,    -1,    -1,    -1,    -1,    -1,
      48,    49,    50,    51,    52,    53,    54,    -1,    -1,    -1,
      -1,    59,    60,    -1,   263,   264,    64,    65,    66,    67,
      68,    69,    70,    71,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    83,    84,    85,    86,    87,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,
      -1,    -1,    -1,   302,    -1,   304,   305,   306,   307,    -1,
     309,   310,   311,   312,    -1,   314,    -1,   316,   317,    -1,
      -1,    -1,    -1,   322,   323,     1,    -1,     3,     4,     5,
       6,     7,    -1,    -1,    -1,    -1,    12,    13,    14,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,
      26,    27,    28,    29,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,
      -1,    -1,    48,    49,    50,    51,    52,    53,    54,    -1,
      -1,    -1,    -1,    59,    60,    -1,    -1,    -1,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   263,   264,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   297,
      -1,    -1,    -1,    -1,   302,    -1,   304,   305,   306,   307,
      -1,   309,   310,   311,   312,    -1,   314,    -1,   316,   317,
      -1,    -1,    -1,    -1,   322,   323,     1,    -1,     3,     4,
       5,     6,     7,    -1,    -1,    -1,    -1,    12,    13,    14,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,
      25,    26,    27,    28,    29,    -1,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    -1,    42,    -1,    -1,
      -1,    -1,    -1,    48,    49,    50,    51,    52,    53,    54,
      -1,    -1,    -1,    -1,    59,    60,    -1,   263,   264,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   297,    -1,    -1,    -1,    -1,   302,    -1,   304,   305,
     306,   307,    -1,   309,   310,   311,   312,    -1,   314,    -1,
     316,   317,    -1,    -1,    -1,    -1,   322,   323,     1,    -1,
       3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,
      13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,
      53,    54,    -1,    -1,    -1,    -1,    59,    60,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,   264,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   297,    -1,    -1,    -1,    -1,   302,    -1,   304,
     305,   306,   307,    -1,   309,   310,   311,   312,    -1,   314,
      -1,   316,   317,    -1,    -1,    -1,    -1,   322,   323,     1,
      -1,     3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    -1,
      42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,
      52,    53,    54,    -1,    -1,    -1,    -1,    59,    60,    -1,
     263,   264,    64,    65,    66,    67,    68,    69,    70,    71,
      72,    73,    74,    75,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,
      -1,   304,   305,   306,   307,    -1,   309,   310,   311,   312,
      -1,   314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,
     323,     1,    -1,     3,     4,     5,     6,     7,    -1,    -1,
      -1,    -1,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,
      50,    51,    52,    53,    54,    -1,    -1,    -1,    -1,    59,
      60,    -1,    -1,    -1,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   263,   264,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,
     302,    -1,   304,   305,   306,   307,    -1,   309,   310,   311,
     312,    -1,   314,    -1,   316,   317,    -1,    -1,    -1,    -1,
     322,   323,     1,    -1,     3,     4,     5,     6,     7,    -1,
      -1,    -1,    -1,    12,    13,    14,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    22,    23,    24,    25,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,
      49,    50,    51,    52,    53,    54,    -1,    -1,    -1,    -1,
      59,    60,    -1,   263,   264,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,
      -1,    -1,   302,    -1,   304,   305,   306,   307,    -1,   309,
     310,   311,   312,    -1,   314,    -1,   316,   317,    -1,    -1,
      -1,    -1,   322,   323,     1,    -1,     3,     4,     5,     6,
       7,    -1,    -1,    -1,    -1,    12,    13,    14,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,    26,
      27,    28,    29,    -1,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,    -1,
      -1,    48,    49,    50,    51,    52,    53,    54,    -1,    -1,
      -1,    -1,    59,    60,    -1,    -1,    -1,    64,    65,    66,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    80,    81,    82,    83,    84,    85,    86,
      87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   263,   264,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,
      -1,    -1,    -1,   302,    -1,   304,   305,   306,   307,    -1,
     309,   310,   311,   312,    -1,   314,    -1,   316,   317,    -1,
      -1,    -1,    -1,   322,   323,     1,    -1,     3,     4,     5,
       6,     7,    -1,    -1,    -1,    -1,    12,    13,    14,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,
      26,    27,    28,    29,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,
      -1,    -1,    48,    49,    50,    51,    52,    53,    54,    -1,
      -1,    -1,    -1,    59,    60,    -1,   263,   264,    64,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
      86,    87,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     297,    -1,    -1,    -1,    -1,   302,    -1,   304,   305,   306,
     307,    -1,   309,   310,   311,   312,    -1,   314,    -1,   316,
     317,    -1,    -1,    -1,    -1,   322,   323,     1,    -1,     3,
       4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,    13,
      14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,
      24,    25,    26,    27,    28,    29,    -1,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    -1,
      -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,    53,
      54,    -1,    -1,    -1,    -1,    59,    60,    -1,    -1,    -1,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,   264,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   297,    -1,    -1,    -1,    -1,   302,    -1,   304,   305,
     306,   307,    -1,   309,   310,   311,   312,    -1,   314,    -1,
     316,   317,    -1,    -1,    -1,    -1,   322,   323,     1,    -1,
       3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,
      13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,
      53,    54,    -1,    -1,    -1,    -1,    59,    60,    -1,   263,
     264,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,    -1,
     304,   305,   306,   307,    -1,   309,   310,   311,   312,    -1,
     314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,   323,
       1,    -1,     3,     4,     5,     6,     7,    -1,    -1,    -1,
      -1,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    22,    23,    24,    25,    26,    27,    28,    29,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    54,    -1,    -1,    -1,    -1,    59,    60,
      -1,    -1,    -1,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    87,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    22,    23,    24,    25,
      26,    27,    28,    29,    -1,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    -1,    42,    -1,    -1,    -1,
      46,    -1,    48,    49,    50,    51,    52,    53,    54,    55,
     263,   264,    58,    59,    60,    -1,    -1,    -1,    64,    65,
      66,    67,    68,    69,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,
      -1,   304,   305,   306,   307,    -1,   309,   310,   311,   312,
      -1,   314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,
     323,    -1,    -1,     3,     4,     5,     6,     7,    -1,    -1,
      -1,    -1,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,    49,
      50,    51,    52,    53,    54,    -1,    -1,    -1,    -1,    59,
      60,    -1,   263,   264,    64,    65,    66,    67,    68,    69,
      70,    71,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,    83,    84,    85,    86,    87,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,
      -1,   302,    -1,   304,   305,   306,   307,    -1,   309,   310,
     311,   312,    -1,   314,    -1,   316,   317,    -1,    -1,    -1,
      -1,   322,   323,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   263,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   279,   280,   281,   282,   283,   284,   285,
     286,   287,   288,   289,   290,   291,   292,   293,   294,   295,
     296,   297,   298,   299,   300,   301,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   312,    -1,    -1,    -1,
     316,   317,    -1,    -1,   320,    -1,    -1,   323,    -1,     3,
       4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,    13,
      14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,    23,
      24,    25,    26,    27,    28,    29,    -1,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    -1,    42,    -1,
      -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,    53,
      54,    -1,    -1,   263,   264,    59,    60,    -1,    -1,    -1,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    -1,    -1,    -1,   297,    -1,    -1,
      -1,    -1,   302,    -1,   304,   305,   306,   307,    -1,   309,
     310,   311,   312,    -1,   314,    -1,   316,   317,    -1,    -1,
      -1,    -1,   322,   323,     3,     4,     5,     6,     7,    -1,
      -1,    -1,    -1,    12,    13,    14,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    22,    23,    24,    25,    26,    27,    28,
      29,    -1,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    -1,    42,    -1,    -1,    -1,    -1,    -1,    48,
      49,    50,    51,    52,    53,    54,    -1,    -1,    -1,    -1,
      59,    60,    -1,    -1,    -1,    64,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      79,    80,    81,    82,    83,    84,    85,    86,    87,    -1,
       3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,
      13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,
      53,    54,    -1,    -1,    -1,    -1,    59,    60,    -1,   263,
     264,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,    -1,
     304,   305,   306,   307,    -1,   309,   310,   311,   312,    -1,
     314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,   323,
       3,     4,     5,     6,     7,    -1,    -1,    -1,    -1,    12,
      13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      -1,    -1,    -1,    -1,    -1,    48,    49,    50,    51,    52,
      53,    54,    -1,    -1,   263,   264,    59,    60,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
      83,    84,    85,    86,    87,    -1,    -1,    -1,   297,    -1,
      -1,    -1,    -1,   302,    -1,   304,   305,   306,   307,    -1,
     309,   310,   311,   312,    -1,   314,    -1,   316,   317,    -1,
      -1,    -1,    -1,   322,   323,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     263,   264,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,
      -1,   304,   305,   306,   307,    -1,   309,   310,   311,   312,
      -1,   314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,
     323,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      22,    23,    24,    25,    26,    27,    28,    29,    -1,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    -1,
      42,    -1,    -1,    -1,    46,    -1,    48,    49,    50,    51,
      52,    53,    54,    55,    -1,    -1,    58,    59,    60,    -1,
     263,   264,    64,    65,    66,    67,    68,    69,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   297,    -1,    -1,    -1,    -1,   302,
      -1,   304,   305,   306,   307,    -1,   309,   310,   311,   312,
      -1,   314,    -1,   316,   317,    -1,    -1,    -1,    -1,   322,
     323,     1,    -1,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    22,    23,    24,    25,    26,    27,    28,    29,
      -1,    31,    32,    33,    34,    35,    36,    37,    38,    39,
      40,    -1,    42,    -1,    -1,    -1,    46,    -1,    48,    49,
      50,    51,    52,    53,    54,    55,    -1,    -1,    58,    59,
      60,    -1,    -1,    -1,    64,    65,    66,    67,    68,    69,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    22,
      23,    24,    25,    26,    27,    28,    29,    -1,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    -1,    42,
      -1,    -1,    -1,    46,    -1,    48,    49,    50,    51,    52,
      53,    54,    55,    -1,    -1,    58,    59,    60,    -1,    -1,
      -1,    64,    65,    66,    67,    68,    69,    -1,    -1,    -1,
      -1,   263,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     312,    -1,    -1,    -1,   316,   317,    -1,    -1,   320,    -1,
      -1,   323,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   263,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   312,    -1,    -1,    -1,   316,   317,    -1,    -1,
     320,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     263,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   312,
      -1,    -1,    -1,   316,   317,    -1,    -1,   320
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,     1,    17,    18,    38,    41,    42,    43,    44,    45,
      57,    94,    95,    96,    97,    98,    99,   100,   101,   102,
     103,   104,   105,   106,   108,   109,   110,   111,   112,   113,
     114,   115,   116,   117,   118,   119,   120,   121,   122,   123,
     124,   125,   126,   127,   128,   129,   130,   131,   132,   133,
     134,   135,   136,   137,   138,   139,   140,   141,   142,   143,
     144,   145,   146,   147,   148,   149,   150,   151,   152,   153,
     154,   155,   156,   157,   158,   159,   160,   161,   162,   163,
     164,   165,   166,   167,   168,   169,   170,   171,   172,   173,
     174,   175,   176,   177,   178,   179,   180,   181,   182,   183,
     184,   185,   186,   187,   188,   189,   190,   191,   192,   193,
     194,   195,   196,   197,   198,   199,   200,   201,   202,   203,
     204,   205,   206,   207,   208,   209,   210,   211,   212,   213,
     218,   219,   220,   221,   222,   223,   224,   225,   226,   227,
     228,   229,   230,   231,   232,   233,   234,   235,   236,   237,
     238,   239,   240,   241,   242,   243,   244,   245,   246,   247,
     248,   249,   250,   252,   253,   254,   255,   256,   257,   258,
     259,   260,   261,   262,   275,   276,   277,   312,   320,   327,
     330,   331,   332,   333,   334,   335,   336,   337,   348,   352,
     355,   356,   358,   359,   368,   369,   375,   278,     1,   325,
       1,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,     1,   278,     1,   278,     1,   278,
       1,   278,     1,   278,     1,   278,     1,   278,     1,   278,
       1,   278,     1,   278,     1,   278,     1,   278,     1,   278,
       1,   278,     1,   278,     1,   278,     1,   278,     1,   278,
       1,   278,     1,   278,     1,   278,     1,   278,     1,   278,
       1,   278,     1,   278,     1,   278,     1,   278,     1,   278,
       1,   278,     1,   278,     1,   278,     1,   278,     1,   278,
       1,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,     1,   314,     1,   278,   314,     1,   322,     1,
     278,   314,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,     1,   278,     1,   278,     1,   278,
       1,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,   278,   278,   278,     1,   278,   278,   278,
     278,   278,   278,   278,   278,   278,   278,   278,   278,   278,
     278,   278,   278,     1,   312,   314,   349,   350,   351,     1,
     351,   353,   354,     1,   314,     1,   314,     1,   314,     0,
       1,   332,    14,    15,   365,   366,    16,   367,    19,   372,
      20,   373,    21,   374,   308,   325,   323,   311,   312,   314,
     364,     1,   311,     1,   311,     1,    88,    89,    90,    91,
     301,   341,     1,   297,   311,   347,     1,   311,     1,   311,
       1,   347,     1,   311,     1,   311,     1,   311,     1,   311,
       1,   312,     1,   314,     1,   311,     1,   314,     1,   311,
       1,   314,     1,   314,     1,   311,   312,   313,   314,   315,
     322,   325,   338,   340,   341,   345,   346,   360,   361,   362,
     363,   389,   390,     1,   346,     1,   311,     1,   311,     1,
     311,   311,   311,   311,   347,   347,   347,   347,   311,   311,
     311,   311,   311,   311,   311,   311,   311,   311,   311,   311,
     311,   311,   311,   311,   311,   311,   311,   311,   311,   311,
     311,   311,   311,   311,   311,     1,   311,   314,     1,   311,
       1,   311,     1,   311,     1,   311,     1,   311,     1,   311,
       1,   347,     1,   347,     1,   347,     1,   347,     1,   347,
       1,   347,     1,   347,     1,   311,     1,   311,     1,   314,
       1,   314,     1,   311,     1,   314,   314,     1,   314,     1,
     311,     1,   311,     1,   312,   314,     1,   312,   314,     1,
     312,   314,     1,   312,   314,     1,   312,   314,     1,   311,
       1,   311,     1,   311,     1,   311,     1,   347,     1,   347,
       1,   347,     1,   312,   314,     1,   311,     1,   311,     1,
     311,     1,   311,   361,     1,   363,     1,   311,     1,   311,
     311,   311,   311,   311,     1,   311,     1,   311,     1,   311,
       1,   311,     1,   311,     1,   311,     1,   311,     1,   311,
       1,   311,     1,   311,     1,   311,     1,   311,     1,   311,
       1,   311,     1,   311,     1,   214,   215,   216,   217,     1,
     311,     1,   311,     1,   311,     1,   311,     1,   314,     1,
     314,     1,   314,     1,   311,     1,   311,     1,   311,     1,
     338,     1,   311,     1,   311,     1,   311,     1,   311,     1,
     311,     1,   311,     1,   311,     1,   311,     1,   311,     1,
     311,     1,   311,     1,   311,     1,   311,     1,   311,     1,
     311,     1,   312,   314,     1,   311,   312,   311,     1,   311,
       1,   311,     1,   311,     1,   311,     1,   311,     1,   314,
     311,   311,   311,     1,   347,     1,   347,     1,   311,     1,
     311,     1,   311,     1,   311,   319,   328,   319,     1,   325,
       1,   323,     1,   323,   325,     1,   323,   325,     1,   323,
     325,     1,   325,    57,   311,   312,   357,   311,   370,   326,
     311,   308,   338,   339,   362,   328,   328,   346,   107,   297,
     308,   319,   349,   311,   353,   364,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    22,    23,
      24,    25,    26,    27,    28,    29,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    42,    46,    48,    49,
      50,    51,    52,    53,    54,    55,    58,    59,    60,    64,
      65,    66,    67,    68,    69,   263,   312,   316,   317,   320,
     391,   393,   394,   395,   399,   400,   408,   409,   411,   412,
     415,   416,   418,   422,   423,   424,   428,   393,   364,   393,
     364,   393,   364,   318,   278,   326,   393,     1,   371,   311,
     319,   321,   326,     1,   301,   311,   343,   340,   338,     1,
     311,   389,     1,   389,   314,   326,     1,   322,     1,   322,
       1,   322,     1,   322,     1,   322,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,   264,   297,   302,   304,   305,   306,
     307,   309,   310,   314,   322,   323,   347,   381,   382,   383,
     384,   385,   386,   391,   403,   408,   409,   410,   411,   413,
     415,   416,   419,   420,   421,   322,   421,   322,   421,     1,
     322,     1,   322,     1,   322,   322,     1,   322,     1,   322,
       1,   322,     1,   322,     1,   322,     1,   322,     1,   322,
       1,   322,   322,     1,   322,     1,   322,     1,   322,     1,
     322,   322,   322,   322,   322,   322,   322,   421,     1,   322,
       1,   322,     1,   322,   322,   322,   322,   322,     1,   421,
     421,     1,   322,     1,   322,     1,   322,     1,   322,     1,
     322,     1,   425,     1,   320,     1,   324,   394,   265,   266,
     267,   268,   269,   270,   271,   272,   273,   312,   405,   406,
     407,   278,   417,   320,     1,   322,   320,   324,   326,   324,
     326,   324,   326,   326,     1,   311,   314,   308,   324,   323,
     308,   339,   328,   328,   319,   323,     1,    61,   312,   314,
     321,   360,   388,     1,    61,   314,   360,   388,     1,    61,
     314,   360,   388,     1,    61,   314,   360,   388,     1,    61,
     314,   360,   388,     1,   286,   287,   290,   291,   292,   376,
     378,   376,   376,     1,   376,   404,     1,   421,     1,   421,
       1,   421,   322,   322,     1,   321,   409,   411,   415,   416,
     421,   422,     1,   393,     1,   378,     1,   293,   294,   295,
     296,   376,   377,     1,   378,   407,     1,   421,   279,   280,
     281,   282,   283,   284,   285,   286,   287,   288,   289,   290,
     291,   292,   293,   294,   295,   296,   297,   298,   299,   300,
     301,   379,   380,   321,   321,     1,   311,   314,     1,   314,
       1,   312,   421,   314,     1,   314,     1,   314,     1,   314,
       1,   314,     1,   311,     1,   311,   321,     1,   321,   347,
     321,     1,   314,     1,   314,     1,   314,     1,   314,   321,
     321,   321,     1,   311,   321,     1,   341,   323,   392,   394,
       1,   338,     1,   311,     1,   338,   341,   344,   321,   321,
     321,   321,   323,   392,     1,   314,     1,   314,   311,   351,
     311,   351,   311,   351,   322,   308,   325,   421,     1,   314,
     408,   409,   414,   416,   323,   323,   323,   323,   251,   251,
     357,   393,   311,   343,   311,   314,   347,   393,   321,   319,
     321,   319,   321,   319,   321,   297,   308,   319,   321,   321,
     319,   321,   319,   321,   319,   321,   319,   321,   321,   319,
     321,   319,   321,   319,   321,   319,   321,   321,   319,   321,
     319,   321,   319,   321,   319,   321,   321,   319,   321,   319,
     321,   319,   321,   319,   321,     1,   312,   421,     1,    88,
      89,    90,    91,    92,    93,   301,   342,   421,     1,   342,
     421,     1,   381,   385,   312,   401,   402,     1,   421,     1,
     421,   321,   321,   321,   324,   324,     1,    86,   421,     1,
     421,     1,   421,     1,    86,   311,   312,   360,   387,   388,
     421,   325,     1,   421,     1,   421,     1,   421,     1,   421,
     421,   421,   421,     1,   421,     1,   421,     1,   421,     1,
     421,     1,   421,     1,   421,     1,   421,   321,   319,   321,
     321,   319,   321,   321,   321,   321,   321,   321,   321,   321,
     321,   321,   321,   321,   321,   321,   321,   321,   321,   321,
     321,   321,   321,   321,   321,   321,   321,   321,   321,   321,
     321,   321,   393,    47,   321,   321,   321,   321,   321,   328,
     328,   321,     1,    56,    57,   324,   397,   398,   321,   319,
     321,   321,   321,   321,   321,   321,   321,   321,   421,   426,
     427,   406,   326,   319,   321,   407,   319,   393,   393,   393,
     393,   314,   314,   278,   324,   308,   321,   321,   324,    62,
     311,   311,   311,     1,   312,     1,   312,   311,    62,   311,
     311,   311,   311,    62,   311,   311,   311,   311,    62,   311,
     311,   311,   311,    62,   311,   311,   311,   311,   325,   308,
     321,   321,   321,   321,   300,   347,   314,   314,   324,   392,
       1,   343,   338,   324,     1,   300,   396,   421,   328,   324,
     397,   311,   421,   319,   321,   351,     1,   351,   324,   324,
     324,   324,   311,   314,   311,   321,   321,   321,   321,   321,
     321,   321,   321,   321,   321,   321,   321,   321,   321,   321,
     321,   321,   321,   321,   321,   321,   321,   321,   321,   321,
     314,   347,   401,     1,   311,   360,   326,   321,   321,   328,
     328,     1,   396,   328,   393,   321,   321,   427,   321,   321,
     321,   326,   326,   343,   393,   328,   328,     1,   393,   393,
     393
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 3:
#line 609 "core/cfg.y"
    {}
    break;

  case 4:
#line 610 "core/cfg.y"
    {}
    break;

  case 5:
#line 611 "core/cfg.y"
    { yyerror(""); YYABORT;}
    break;

  case 11:
#line 619 "core/cfg.y"
    {rt=REQUEST_ROUTE;}
    break;

  case 13:
#line 620 "core/cfg.y"
    {rt=FAILURE_ROUTE;}
    break;

  case 16:
#line 622 "core/cfg.y"
    {rt=BRANCH_ROUTE;}
    break;

  case 18:
#line 623 "core/cfg.y"
    {rt=ONSEND_ROUTE;}
    break;

  case 20:
#line 624 "core/cfg.y"
    {rt=EVENT_ROUTE;}
    break;

  case 24:
#line 629 "core/cfg.y"
    {
		if ((yyvsp[(1) - (1)].ipaddr)){
			tmp=ip_addr2a((yyvsp[(1) - (1)].ipaddr));
			if (tmp==0) {
				LM_CRIT("cfg. parser: bad ip address.\n");
				(yyval.strval)=0;
			} else {
				(yyval.strval)=pkg_malloc(strlen(tmp)+1);
				if ((yyval.strval)==0) {
					LM_CRIT("cfg. parser: out of memory.\n");
				} else {
					strncpy((yyval.strval), tmp, strlen(tmp)+1);
				}
			}
		}
	}
    break;

  case 25:
#line 645 "core/cfg.y"
    {
		(yyval.strval)=pkg_malloc(strlen((yyvsp[(1) - (1)].strval))+1);
		if ((yyval.strval)==0) {
				LM_CRIT("cfg. parser: out of memory.\n");
		} else {
				strncpy((yyval.strval), (yyvsp[(1) - (1)].strval), strlen((yyvsp[(1) - (1)].strval))+1);
		}
	}
    break;

  case 26:
#line 653 "core/cfg.y"
    {
		if ((yyvsp[(1) - (1)].strval)){
			(yyval.strval)=pkg_malloc(strlen((yyvsp[(1) - (1)].strval))+1);
			if ((yyval.strval)==0) {
					LM_CRIT("cfg. parser: out of memory.\n");
			} else {
					strncpy((yyval.strval), (yyvsp[(1) - (1)].strval), strlen((yyvsp[(1) - (1)].strval))+1);
			}
		}
	}
    break;

  case 27:
#line 667 "core/cfg.y"
    { (yyval.name_l)=mk_name_lst((yyvsp[(1) - (1)].strval), SI_IS_MHOMED); }
    break;

  case 28:
#line 668 "core/cfg.y"
    { (yyval.name_l)=mk_name_lst((yyvsp[(1) - (3)].strval), SI_IS_MHOMED);
										if ((yyval.name_l)) (yyval.name_l)->next=(yyvsp[(3) - (3)].name_l);
									}
    break;

  case 29:
#line 674 "core/cfg.y"
    { (yyval.name_l)=(yyvsp[(2) - (3)].name_l); }
    break;

  case 30:
#line 675 "core/cfg.y"
    { (yyval.name_l)=mk_name_lst((yyvsp[(1) - (1)].strval), 0); }
    break;

  case 31:
#line 679 "core/cfg.y"
    { (yyval.intval)=PROTO_UDP; }
    break;

  case 32:
#line 680 "core/cfg.y"
    { (yyval.intval)=PROTO_TCP; }
    break;

  case 33:
#line 681 "core/cfg.y"
    { (yyval.intval)=PROTO_TLS; }
    break;

  case 34:
#line 682 "core/cfg.y"
    { (yyval.intval)=PROTO_SCTP; }
    break;

  case 35:
#line 683 "core/cfg.y"
    { (yyval.intval)=0; }
    break;

  case 36:
#line 686 "core/cfg.y"
    { (yyval.intval)=PROTO_UDP; }
    break;

  case 37:
#line 687 "core/cfg.y"
    { (yyval.intval)=PROTO_TCP; }
    break;

  case 38:
#line 688 "core/cfg.y"
    { (yyval.intval)=PROTO_TLS; }
    break;

  case 39:
#line 689 "core/cfg.y"
    { (yyval.intval)=PROTO_SCTP; }
    break;

  case 40:
#line 690 "core/cfg.y"
    { (yyval.intval)=PROTO_WS; }
    break;

  case 41:
#line 691 "core/cfg.y"
    { (yyval.intval)=PROTO_WSS; }
    break;

  case 42:
#line 692 "core/cfg.y"
    { (yyval.intval)=0; }
    break;

  case 43:
#line 695 "core/cfg.y"
    { (yyval.intval)=(yyvsp[(1) - (1)].intval); }
    break;

  case 44:
#line 696 "core/cfg.y"
    { (yyval.intval)=0; }
    break;

  case 45:
#line 699 "core/cfg.y"
    { (yyval.sockid)=mk_listen_id((yyvsp[(1) - (1)].strval), 0, 0); }
    break;

  case 46:
#line 700 "core/cfg.y"
    { (yyval.sockid)=mk_listen_id((yyvsp[(1) - (3)].strval), 0, (yyvsp[(3) - (3)].intval)); }
    break;

  case 47:
#line 701 "core/cfg.y"
    { (yyval.sockid)=mk_listen_id((yyvsp[(3) - (3)].strval), (yyvsp[(1) - (3)].intval), 0); }
    break;

  case 48:
#line 702 "core/cfg.y"
    { (yyval.sockid)=mk_listen_id((yyvsp[(3) - (5)].strval), (yyvsp[(1) - (5)].intval), (yyvsp[(5) - (5)].intval));}
    break;

  case 49:
#line 703 "core/cfg.y"
    { (yyval.sockid)=0; yyerror("port number expected"); }
    break;

  case 50:
#line 707 "core/cfg.y"
    { (yyval.sockid)=mk_listen_id2((yyvsp[(1) - (1)].name_l), 0, 0); }
    break;

  case 51:
#line 708 "core/cfg.y"
    { (yyval.sockid)=mk_listen_id2((yyvsp[(1) - (3)].name_l), 0, (yyvsp[(3) - (3)].intval)); }
    break;

  case 52:
#line 709 "core/cfg.y"
    { (yyval.sockid)=mk_listen_id2((yyvsp[(3) - (3)].name_l), (yyvsp[(1) - (3)].intval), 0); }
    break;

  case 53:
#line 710 "core/cfg.y"
    { (yyval.sockid)=mk_listen_id2((yyvsp[(3) - (5)].name_l), (yyvsp[(1) - (5)].intval), (yyvsp[(5) - (5)].intval));}
    break;

  case 54:
#line 711 "core/cfg.y"
    { (yyval.sockid)=0; yyerror("port number expected"); }
    break;

  case 55:
#line 715 "core/cfg.y"
    {  (yyval.sockid)=(yyvsp[(1) - (1)].sockid) ; }
    break;

  case 56:
#line 716 "core/cfg.y"
    { (yyval.sockid)=(yyvsp[(1) - (2)].sockid);  if ((yyval.sockid)) (yyval.sockid)->next=(yyvsp[(2) - (2)].sockid); }
    break;

  case 58:
#line 720 "core/cfg.y"
    { (yyval.intval)=-(yyvsp[(2) - (2)].intval); }
    break;

  case 60:
#line 724 "core/cfg.y"
    { yyerror("flag list expected\n"); }
    break;

  case 63:
#line 730 "core/cfg.y"
    { if (register_flag((yyvsp[(1) - (1)].strval),-1)<0)
								yyerror("register flag failed");
						}
    break;

  case 64:
#line 733 "core/cfg.y"
    {
						if (register_flag((yyvsp[(1) - (3)].strval), (yyvsp[(3) - (3)].intval))<0)
								yyerror("register flag failed");
										}
    break;

  case 65:
#line 739 "core/cfg.y"
    { (yyval.strval)=(yyvsp[(1) - (1)].strval); }
    break;

  case 66:
#line 740 "core/cfg.y"
    { (yyval.strval)=(yyvsp[(1) - (1)].strval); }
    break;

  case 68:
#line 745 "core/cfg.y"
    { yyerror("avpflag list expected\n"); }
    break;

  case 71:
#line 752 "core/cfg.y"
    {
		if (register_avpflag((yyvsp[(1) - (1)].strval))==0)
			yyerror("cannot declare avpflag");
	}
    break;

  case 72:
#line 758 "core/cfg.y"
    { default_core_cfg.debug=(yyvsp[(3) - (3)].intval); }
    break;

  case 73:
#line 759 "core/cfg.y"
    { yyerror("number  expected"); }
    break;

  case 74:
#line 760 "core/cfg.y"
    { dont_fork= ! (yyvsp[(3) - (3)].intval); }
    break;

  case 75:
#line 761 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 76:
#line 762 "core/cfg.y"
    { set_fork_delay((yyvsp[(3) - (3)].intval)); }
    break;

  case 77:
#line 763 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 78:
#line 764 "core/cfg.y"
    { set_modinit_delay((yyvsp[(3) - (3)].intval)); }
    break;

  case 79:
#line 765 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 80:
#line 766 "core/cfg.y"
    { if (!config_check)  /* if set from cmd line, don't overwrite from yyparse()*/
					if(log_stderr == 0) log_stderr=(yyvsp[(3) - (3)].intval);
				   }
    break;

  case 81:
#line 769 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 82:
#line 770 "core/cfg.y"
    {
		if ( (i_tmp=str2facility((yyvsp[(3) - (3)].strval)))==-1)
			yyerror("bad facility (see syslog(3) man page)");
		if (!config_check)
			default_core_cfg.log_facility=i_tmp;
	}
    break;

  case 83:
#line 776 "core/cfg.y"
    { yyerror("ID expected"); }
    break;

  case 84:
#line 777 "core/cfg.y"
    { log_name=(yyvsp[(3) - (3)].strval); }
    break;

  case 85:
#line 778 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 86:
#line 779 "core/cfg.y"
    { log_color=(yyvsp[(3) - (3)].intval); }
    break;

  case 87:
#line 780 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 88:
#line 781 "core/cfg.y"
    { log_prefix_fmt=(yyvsp[(3) - (3)].strval); }
    break;

  case 89:
#line 782 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 90:
#line 783 "core/cfg.y"
    { log_prefix_mode=(yyvsp[(3) - (3)].intval); }
    break;

  case 91:
#line 784 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 92:
#line 785 "core/cfg.y"
    { _km_log_engine_type=(yyvsp[(3) - (3)].strval); }
    break;

  case 93:
#line 786 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 94:
#line 787 "core/cfg.y"
    { _km_log_engine_data=(yyvsp[(3) - (3)].strval); }
    break;

  case 95:
#line 788 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 96:
#line 789 "core/cfg.y"
    { received_dns|= ((yyvsp[(3) - (3)].intval))?DO_DNS:0; }
    break;

  case 97:
#line 790 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 98:
#line 791 "core/cfg.y"
    { received_dns|= ((yyvsp[(3) - (3)].intval))?DO_REV_DNS:0; }
    break;

  case 99:
#line 792 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 100:
#line 793 "core/cfg.y"
    { default_core_cfg.dns_try_ipv6=(yyvsp[(3) - (3)].intval); }
    break;

  case 101:
#line 794 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 102:
#line 795 "core/cfg.y"
    { IF_NAPTR(default_core_cfg.dns_try_naptr=(yyvsp[(3) - (3)].intval)); }
    break;

  case 103:
#line 796 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 104:
#line 797 "core/cfg.y"
    { IF_DNS_FAILOVER(default_core_cfg.dns_srv_lb=(yyvsp[(3) - (3)].intval)); }
    break;

  case 105:
#line 798 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 106:
#line 799 "core/cfg.y"
    { IF_NAPTR(default_core_cfg.dns_udp_pref=(yyvsp[(3) - (3)].intval));}
    break;

  case 107:
#line 800 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 108:
#line 801 "core/cfg.y"
    { IF_NAPTR(default_core_cfg.dns_tcp_pref=(yyvsp[(3) - (3)].intval));}
    break;

  case 109:
#line 802 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 110:
#line 803 "core/cfg.y"
    { IF_NAPTR(default_core_cfg.dns_tls_pref=(yyvsp[(3) - (3)].intval));}
    break;

  case 111:
#line 804 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 112:
#line 805 "core/cfg.y"
    {
								IF_NAPTR(default_core_cfg.dns_sctp_pref=(yyvsp[(3) - (3)].intval)); }
    break;

  case 113:
#line 807 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 114:
#line 808 "core/cfg.y"
    { default_core_cfg.dns_retr_time=(yyvsp[(3) - (3)].intval); }
    break;

  case 115:
#line 809 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 116:
#line 810 "core/cfg.y"
    { default_core_cfg.dns_retr_no=(yyvsp[(3) - (3)].intval); }
    break;

  case 117:
#line 811 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 118:
#line 812 "core/cfg.y"
    { default_core_cfg.dns_servers_no=(yyvsp[(3) - (3)].intval); }
    break;

  case 119:
#line 813 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 120:
#line 814 "core/cfg.y"
    { default_core_cfg.dns_search_list=(yyvsp[(3) - (3)].intval); }
    break;

  case 121:
#line 815 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 122:
#line 816 "core/cfg.y"
    { default_core_cfg.dns_search_fmatch=(yyvsp[(3) - (3)].intval); }
    break;

  case 123:
#line 817 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 124:
#line 818 "core/cfg.y"
    { default_core_cfg.dns_naptr_ignore_rfc=(yyvsp[(3) - (3)].intval); }
    break;

  case 125:
#line 819 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 126:
#line 820 "core/cfg.y"
    { IF_DNS_CACHE(dns_cache_init=(yyvsp[(3) - (3)].intval)); }
    break;

  case 127:
#line 821 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 128:
#line 822 "core/cfg.y"
    { IF_DNS_CACHE(default_core_cfg.use_dns_cache=(yyvsp[(3) - (3)].intval)); }
    break;

  case 129:
#line 823 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 130:
#line 824 "core/cfg.y"
    { IF_DNS_FAILOVER(default_core_cfg.use_dns_failover=(yyvsp[(3) - (3)].intval));}
    break;

  case 131:
#line 825 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 132:
#line 826 "core/cfg.y"
    { IF_DNS_CACHE(default_core_cfg.dns_cache_flags=(yyvsp[(3) - (3)].intval)); }
    break;

  case 133:
#line 827 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 134:
#line 828 "core/cfg.y"
    { IF_DNS_CACHE(default_core_cfg.dns_neg_cache_ttl=(yyvsp[(3) - (3)].intval)); }
    break;

  case 135:
#line 829 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 136:
#line 830 "core/cfg.y"
    { IF_DNS_CACHE(default_core_cfg.dns_cache_max_ttl=(yyvsp[(3) - (3)].intval)); }
    break;

  case 137:
#line 831 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 138:
#line 832 "core/cfg.y"
    { IF_DNS_CACHE(default_core_cfg.dns_cache_min_ttl=(yyvsp[(3) - (3)].intval)); }
    break;

  case 139:
#line 833 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 140:
#line 834 "core/cfg.y"
    { IF_DNS_CACHE(default_core_cfg.dns_cache_max_mem=(yyvsp[(3) - (3)].intval)); }
    break;

  case 141:
#line 835 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 142:
#line 836 "core/cfg.y"
    { IF_DNS_CACHE(dns_timer_interval=(yyvsp[(3) - (3)].intval)); }
    break;

  case 143:
#line 837 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 144:
#line 838 "core/cfg.y"
    { IF_DNS_CACHE(default_core_cfg.dns_cache_del_nonexp=(yyvsp[(3) - (3)].intval)); }
    break;

  case 145:
#line 839 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 146:
#line 840 "core/cfg.y"
    { IF_DNS_CACHE(default_core_cfg.dns_cache_rec_pref=(yyvsp[(3) - (3)].intval)); }
    break;

  case 147:
#line 841 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 148:
#line 842 "core/cfg.y"
    {IF_AUTO_BIND_IPV6(auto_bind_ipv6 = (yyvsp[(3) - (3)].intval));}
    break;

  case 149:
#line 843 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 150:
#line 844 "core/cfg.y"
    { IF_DST_BLACKLIST(dst_blacklist_init=(yyvsp[(3) - (3)].intval)); }
    break;

  case 151:
#line 845 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 152:
#line 846 "core/cfg.y"
    {
		IF_DST_BLACKLIST(default_core_cfg.use_dst_blacklist=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 153:
#line 849 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 154:
#line 850 "core/cfg.y"
    {
		IF_DST_BLACKLIST(default_core_cfg.blst_max_mem=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 155:
#line 853 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 156:
#line 854 "core/cfg.y"
    {
		IF_DST_BLACKLIST(default_core_cfg.blst_timeout=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 157:
#line 857 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 158:
#line 858 "core/cfg.y"
    { IF_DST_BLACKLIST(blst_timer_interval=(yyvsp[(3) - (3)].intval));}
    break;

  case 159:
#line 859 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 160:
#line 860 "core/cfg.y"
    {
		IF_DST_BLACKLIST(default_core_cfg.blst_udp_imask=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 161:
#line 863 "core/cfg.y"
    { yyerror("number(flags) expected"); }
    break;

  case 162:
#line 864 "core/cfg.y"
    {
		IF_DST_BLACKLIST(default_core_cfg.blst_tcp_imask=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 163:
#line 867 "core/cfg.y"
    { yyerror("number(flags) expected"); }
    break;

  case 164:
#line 868 "core/cfg.y"
    {
		IF_DST_BLACKLIST(default_core_cfg.blst_tls_imask=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 165:
#line 871 "core/cfg.y"
    { yyerror("number(flags) expected"); }
    break;

  case 166:
#line 872 "core/cfg.y"
    {
		IF_DST_BLACKLIST(default_core_cfg.blst_sctp_imask=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 167:
#line 875 "core/cfg.y"
    { yyerror("number(flags) expected"); }
    break;

  case 168:
#line 876 "core/cfg.y"
    { port_no=(yyvsp[(3) - (3)].intval); }
    break;

  case 169:
#line 877 "core/cfg.y"
    {
		#ifdef STATS
				stat_file=(yyvsp[(3) - (3)].strval);
		#endif
	}
    break;

  case 170:
#line 882 "core/cfg.y"
    { maxbuffer=(yyvsp[(3) - (3)].intval); }
    break;

  case 171:
#line 883 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 172:
#line 884 "core/cfg.y"
    { sql_buffer_size=(yyvsp[(3) - (3)].intval); }
    break;

  case 173:
#line 885 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 174:
#line 886 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 175:
#line 887 "core/cfg.y"
    { children_no=(yyvsp[(3) - (3)].intval); }
    break;

  case 176:
#line 888 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 177:
#line 889 "core/cfg.y"
    { socket_workers=(yyvsp[(3) - (3)].intval); }
    break;

  case 178:
#line 890 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 179:
#line 891 "core/cfg.y"
    { async_task_set_workers((yyvsp[(3) - (3)].intval)); }
    break;

  case 180:
#line 892 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 181:
#line 893 "core/cfg.y"
    { async_task_set_usleep((yyvsp[(3) - (3)].intval)); }
    break;

  case 182:
#line 894 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 183:
#line 895 "core/cfg.y"
    { check_via=(yyvsp[(3) - (3)].intval); }
    break;

  case 184:
#line 896 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 185:
#line 897 "core/cfg.y"
    { phone2tel=(yyvsp[(3) - (3)].intval); }
    break;

  case 186:
#line 898 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 187:
#line 899 "core/cfg.y"
    { default_core_cfg.memlog=(yyvsp[(3) - (3)].intval); }
    break;

  case 188:
#line 900 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 189:
#line 901 "core/cfg.y"
    { default_core_cfg.memdbg=(yyvsp[(3) - (3)].intval); }
    break;

  case 190:
#line 902 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 191:
#line 903 "core/cfg.y"
    { default_core_cfg.mem_summary=(yyvsp[(3) - (3)].intval); }
    break;

  case 192:
#line 904 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 193:
#line 905 "core/cfg.y"
    { default_core_cfg.mem_safety=(yyvsp[(3) - (3)].intval); }
    break;

  case 194:
#line 906 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 195:
#line 907 "core/cfg.y"
    { default_core_cfg.mem_join=(yyvsp[(3) - (3)].intval); }
    break;

  case 196:
#line 908 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 197:
#line 909 "core/cfg.y"
    { default_core_cfg.mem_status_mode=(yyvsp[(3) - (3)].intval); }
    break;

  case 198:
#line 910 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 199:
#line 911 "core/cfg.y"
    { default_core_cfg.corelog=(yyvsp[(3) - (3)].intval); }
    break;

  case 200:
#line 912 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 201:
#line 913 "core/cfg.y"
    { sip_warning=(yyvsp[(3) - (3)].intval); }
    break;

  case 202:
#line 914 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 203:
#line 915 "core/cfg.y"
    { version_table.s=(yyvsp[(3) - (3)].strval);
			version_table.len=strlen(version_table.s);
	}
    break;

  case 204:
#line 918 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 205:
#line 919 "core/cfg.y"
    {
		if (shm_initialized())
			yyerror("user must be before any modparam or the"
					" route blocks");
		else if (user==0)
			user=(yyvsp[(3) - (3)].strval);
	}
    break;

  case 206:
#line 926 "core/cfg.y"
    {
		if (shm_initialized())
			yyerror("user must be before any modparam or the"
					" route blocks");
		else if (user==0)
			user=(yyvsp[(3) - (3)].strval);
	}
    break;

  case 207:
#line 933 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 208:
#line 934 "core/cfg.y"
    { group=(yyvsp[(3) - (3)].strval); }
    break;

  case 209:
#line 935 "core/cfg.y"
    { group=(yyvsp[(3) - (3)].strval); }
    break;

  case 210:
#line 936 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 211:
#line 937 "core/cfg.y"
    { chroot_dir=(yyvsp[(3) - (3)].strval); }
    break;

  case 212:
#line 938 "core/cfg.y"
    { chroot_dir=(yyvsp[(3) - (3)].strval); }
    break;

  case 213:
#line 939 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 214:
#line 940 "core/cfg.y"
    { working_dir=(yyvsp[(3) - (3)].strval); }
    break;

  case 215:
#line 941 "core/cfg.y"
    { working_dir=(yyvsp[(3) - (3)].strval); }
    break;

  case 216:
#line 942 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 217:
#line 943 "core/cfg.y"
    { runtime_dir=(yyvsp[(3) - (3)].strval); }
    break;

  case 218:
#line 944 "core/cfg.y"
    { runtime_dir=(yyvsp[(3) - (3)].strval); }
    break;

  case 219:
#line 945 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 220:
#line 946 "core/cfg.y"
    { mhomed=(yyvsp[(3) - (3)].intval); }
    break;

  case 221:
#line 947 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 222:
#line 948 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_disable=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 223:
#line 955 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 224:
#line 956 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.accept_aliases=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 225:
#line 963 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 226:
#line 964 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_cfg_children_no=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 227:
#line 971 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 228:
#line 972 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.connect_timeout_s=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 229:
#line 979 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 230:
#line 980 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.send_timeout=S_TO_TICKS((yyvsp[(3) - (3)].intval));
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 231:
#line 987 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 232:
#line 988 "core/cfg.y"
    {
		#ifdef USE_TCP
			if ((yyvsp[(3) - (3)].intval)<0)
				tcp_default_cfg.con_lifetime=-1;
			else
				tcp_default_cfg.con_lifetime=S_TO_TICKS((yyvsp[(3) - (3)].intval));
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 233:
#line 998 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 234:
#line 999 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_poll_method=get_poll_type((yyvsp[(3) - (3)].strval));
			if (tcp_poll_method==POLL_NONE) {
				LOG(L_CRIT, "bad poll method name:"
						" %s\n, try one of %s.\n",
						(yyvsp[(3) - (3)].strval), poll_support);
				yyerror("bad tcp_poll_method "
						"value");
			}
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 235:
#line 1013 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_poll_method=get_poll_type((yyvsp[(3) - (3)].strval));
			if (tcp_poll_method==POLL_NONE) {
				LOG(L_CRIT, "bad poll method name:"
						" %s\n, try one of %s.\n",
						(yyvsp[(3) - (3)].strval), poll_support);
				yyerror("bad tcp_poll_method "
						"value");
			}
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 236:
#line 1027 "core/cfg.y"
    { yyerror("poll method name expected"); }
    break;

  case 237:
#line 1028 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_max_connections=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 238:
#line 1035 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 239:
#line 1036 "core/cfg.y"
    {
		#ifdef USE_TLS
			tls_max_connections=(yyvsp[(3) - (3)].intval);
		#else
			warn("tls support not compiled in");
		#endif
	}
    break;

  case 240:
#line 1043 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 241:
#line 1044 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.no_connect=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 242:
#line 1051 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 243:
#line 1052 "core/cfg.y"
    {
		#ifdef USE_TCP
			if (tcp_set_src_addr((yyvsp[(3) - (3)].ipaddr))<0)
				warn("tcp_source_ipv4 failed");
		#else
			warn("tcp support not compiled in");
		#endif
		pkg_free((yyvsp[(3) - (3)].ipaddr));
	}
    break;

  case 244:
#line 1061 "core/cfg.y"
    { yyerror("IPv4 address expected"); }
    break;

  case 245:
#line 1062 "core/cfg.y"
    {
		#ifdef USE_TCP
				if (tcp_set_src_addr((yyvsp[(3) - (3)].ipaddr))<0)
					warn("tcp_source_ipv6 failed");
		#else
			warn("tcp support not compiled in");
		#endif
		pkg_free((yyvsp[(3) - (3)].ipaddr));
	}
    break;

  case 246:
#line 1071 "core/cfg.y"
    { yyerror("IPv6 address expected"); }
    break;

  case 247:
#line 1072 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.fd_cache=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 248:
#line 1079 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 249:
#line 1080 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.async=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 250:
#line 1087 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 251:
#line 1088 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.tcpconn_wq_max=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 252:
#line 1095 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 253:
#line 1096 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.tcp_wq_max=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 254:
#line 1103 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 255:
#line 1104 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.rd_buf_size=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 256:
#line 1111 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 257:
#line 1112 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.wq_blk_size=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 258:
#line 1119 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 259:
#line 1120 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.defer_accept=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 260:
#line 1127 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 261:
#line 1128 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.delayed_ack=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 262:
#line 1135 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 263:
#line 1136 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.syncnt=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 264:
#line 1143 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 265:
#line 1144 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.linger2=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 266:
#line 1151 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 267:
#line 1152 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.keepalive=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 268:
#line 1159 "core/cfg.y"
    { yyerror("boolean value expected");}
    break;

  case 269:
#line 1160 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.keepidle=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 270:
#line 1167 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 271:
#line 1168 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.keepintvl=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 272:
#line 1175 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 273:
#line 1176 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.keepcnt=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 274:
#line 1183 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 275:
#line 1184 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.crlf_ping=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 276:
#line 1191 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 277:
#line 1192 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_default_cfg.accept_no_cl=(yyvsp[(3) - (3)].intval);
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 278:
#line 1199 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 279:
#line 1200 "core/cfg.y"
    {
		#ifdef USE_TCP
			tcp_set_clone_rcvbuf((yyvsp[(3) - (3)].intval));
		#else
			warn("tcp support not compiled in");
		#endif
	}
    break;

  case 280:
#line 1207 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 281:
#line 1208 "core/cfg.y"
    {
		#ifdef USE_TLS
			tls_disable=(yyvsp[(3) - (3)].intval);
		#else
			warn("tls support not compiled in");
		#endif
	}
    break;

  case 282:
#line 1215 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 283:
#line 1216 "core/cfg.y"
    {
		#ifdef USE_TLS
			tls_disable=!((yyvsp[(3) - (3)].intval));
		#else
			warn("tls support not compiled in");
		#endif
	}
    break;

  case 284:
#line 1223 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 285:
#line 1224 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_log=(yyvsp[(3) - (3)].intval);
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 286:
#line 1231 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 287:
#line 1232 "core/cfg.y"
    {
		#ifdef USE_TLS
			tls_port_no=(yyvsp[(3) - (3)].intval);
		#else
			warn("tls support not compiled in");
		#endif
	}
    break;

  case 288:
#line 1239 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 289:
#line 1240 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_method=TLS_USE_SSLv23;
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 290:
#line 1247 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_method=TLS_USE_SSLv2;
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 291:
#line 1254 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_method=TLS_USE_SSLv3;
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 292:
#line 1261 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_method=TLS_USE_TLSv1;
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 293:
#line 1268 "core/cfg.y"
    {
		#ifdef CORE_TLS
			yyerror("SSLv23, SSLv2, SSLv3 or TLSv1 expected");
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 294:
#line 1275 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_verify_cert=(yyvsp[(3) - (3)].intval);
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 295:
#line 1282 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 296:
#line 1283 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_require_cert=(yyvsp[(3) - (3)].intval);
		#else
			warn( "tls-in-core support not compiled in");
		#endif
	}
    break;

  case 297:
#line 1290 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 298:
#line 1291 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_cert_file=(yyvsp[(3) - (3)].strval);
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 299:
#line 1298 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 300:
#line 1299 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_pkey_file=(yyvsp[(3) - (3)].strval);
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 301:
#line 1306 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 302:
#line 1307 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_ca_file=(yyvsp[(3) - (3)].strval);
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 303:
#line 1314 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 304:
#line 1315 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_handshake_timeout=(yyvsp[(3) - (3)].intval);
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 305:
#line 1322 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 306:
#line 1323 "core/cfg.y"
    {
		#ifdef CORE_TLS
			tls_send_timeout=(yyvsp[(3) - (3)].intval);
		#else
			warn("tls-in-core support not compiled in");
		#endif
	}
    break;

  case 307:
#line 1330 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 308:
#line 1331 "core/cfg.y"
    {
		#ifdef USE_SCTP
			sctp_disable=(yyvsp[(3) - (3)].intval);
		#else
			warn("sctp support not compiled in");
		#endif
	}
    break;

  case 309:
#line 1338 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 310:
#line 1339 "core/cfg.y"
    {
		#ifdef USE_SCTP
			sctp_disable=((yyvsp[(3) - (3)].intval)<=1)?!(yyvsp[(3) - (3)].intval):(yyvsp[(3) - (3)].intval);
		#else
			warn("sctp support not compiled in");
		#endif
	}
    break;

  case 311:
#line 1346 "core/cfg.y"
    { yyerror("boolean or number expected"); }
    break;

  case 312:
#line 1347 "core/cfg.y"
    {
		#ifdef USE_SCTP
			sctp_children_no=(yyvsp[(3) - (3)].intval);
		#else
			warn("sctp support not compiled in");
		#endif
	}
    break;

  case 313:
#line 1354 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 314:
#line 1355 "core/cfg.y"
    { server_signature=(yyvsp[(3) - (3)].intval); }
    break;

  case 315:
#line 1356 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 316:
#line 1357 "core/cfg.y"
    { server_hdr.s=(yyvsp[(3) - (3)].strval);
			server_hdr.len=strlen(server_hdr.s);
	}
    break;

  case 317:
#line 1360 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 318:
#line 1361 "core/cfg.y"
    { user_agent_hdr.s=(yyvsp[(3) - (3)].strval);
			user_agent_hdr.len=strlen(user_agent_hdr.s);
	}
    break;

  case 319:
#line 1364 "core/cfg.y"
    { yyerror("string value expected"); }
    break;

  case 320:
#line 1365 "core/cfg.y"
    { reply_to_via=(yyvsp[(3) - (3)].intval); }
    break;

  case 321:
#line 1366 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 322:
#line 1367 "core/cfg.y"
    {
		for(lst_tmp=(yyvsp[(3) - (3)].sockid); lst_tmp; lst_tmp=lst_tmp->next) {
			if (add_listen_iface(	lst_tmp->addr_lst->name,
									lst_tmp->addr_lst->next,
									lst_tmp->port, lst_tmp->proto,
									lst_tmp->flags)!=0) {
				LM_CRIT("cfg. parser: failed to add listen address\n");
				break;
			}
		}
		free_socket_id_lst((yyvsp[(3) - (3)].sockid));
	}
    break;

  case 323:
#line 1379 "core/cfg.y"
    {
		for(lst_tmp=(yyvsp[(3) - (7)].sockid); lst_tmp; lst_tmp=lst_tmp->next) {
			if (add_listen_advertise_iface(	lst_tmp->addr_lst->name,
									lst_tmp->addr_lst->next,
									lst_tmp->port, lst_tmp->proto,
									(yyvsp[(5) - (7)].strval), (yyvsp[(7) - (7)].intval),
									lst_tmp->flags)!=0) {
				LM_CRIT("cfg. parser: failed to add listen address\n");
				break;
			}
		}
		free_socket_id_lst((yyvsp[(3) - (7)].sockid));
	}
    break;

  case 324:
#line 1392 "core/cfg.y"
    { yyerror("ip address, interface name or"
									" hostname expected"); }
    break;

  case 325:
#line 1394 "core/cfg.y"
    {
		for(lst_tmp=(yyvsp[(3) - (3)].sockid); lst_tmp; lst_tmp=lst_tmp->next){
			add_alias(	lst_tmp->addr_lst->name,
						strlen(lst_tmp->addr_lst->name),
						lst_tmp->port, lst_tmp->proto);
			for (nl_tmp=lst_tmp->addr_lst->next; nl_tmp; nl_tmp=nl_tmp->next)
				add_alias(nl_tmp->name, strlen(nl_tmp->name),
							lst_tmp->port, lst_tmp->proto);
		}
		free_socket_id_lst((yyvsp[(3) - (3)].sockid));
	}
    break;

  case 326:
#line 1405 "core/cfg.y"
    { yyerror("hostname expected"); }
    break;

  case 327:
#line 1406 "core/cfg.y"
    { sr_auto_aliases=(yyvsp[(3) - (3)].intval); }
    break;

  case 328:
#line 1407 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 329:
#line 1408 "core/cfg.y"
    {
		if ((yyvsp[(3) - (3)].strval)){
			default_global_address.s=(yyvsp[(3) - (3)].strval);
			default_global_address.len=strlen((yyvsp[(3) - (3)].strval));
		}
	}
    break;

  case 330:
#line 1414 "core/cfg.y"
    {yyerror("ip address or hostname expected"); }
    break;

  case 331:
#line 1415 "core/cfg.y"
    {
		tmp=int2str((yyvsp[(3) - (3)].intval), &i_tmp);
		if ((default_global_port.s=pkg_malloc(i_tmp))==0) {
			LM_CRIT("cfg. parser: out of memory.\n");
			default_global_port.len=0;
		} else {
			default_global_port.len=i_tmp;
			memcpy(default_global_port.s, tmp, default_global_port.len);
		};
	}
    break;

  case 332:
#line 1425 "core/cfg.y"
    {yyerror("ip address or hostname expected"); }
    break;

  case 333:
#line 1426 "core/cfg.y"
    { disable_core_dump=(yyvsp[(3) - (3)].intval); }
    break;

  case 334:
#line 1427 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 335:
#line 1428 "core/cfg.y"
    { open_files_limit=(yyvsp[(3) - (3)].intval); }
    break;

  case 336:
#line 1429 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 337:
#line 1430 "core/cfg.y"
    {
		if (shm_initialized())
			yyerror("shm/shm_mem_size must be before any modparam or the"
					" route blocks");
		else if (shm_mem_size == 0 || shm_mem_size == SHM_MEM_POOL_SIZE)
			shm_mem_size=(yyvsp[(3) - (3)].intval) * 1024 * 1024;
	}
    break;

  case 338:
#line 1437 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 339:
#line 1438 "core/cfg.y"
    {
		if (shm_initialized())
			yyerror("shm_force_alloc must be before any modparam or the"
					" route blocks");
		else
			shm_force_alloc=(yyvsp[(3) - (3)].intval);
	}
    break;

  case 340:
#line 1445 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 341:
#line 1446 "core/cfg.y"
    { mlock_pages=(yyvsp[(3) - (3)].intval); }
    break;

  case 342:
#line 1447 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 343:
#line 1448 "core/cfg.y"
    { real_time=(yyvsp[(3) - (3)].intval); }
    break;

  case 344:
#line 1449 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 345:
#line 1450 "core/cfg.y"
    { rt_prio=(yyvsp[(3) - (3)].intval); }
    break;

  case 346:
#line 1451 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 347:
#line 1452 "core/cfg.y"
    { rt_policy=(yyvsp[(3) - (3)].intval); }
    break;

  case 348:
#line 1453 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 349:
#line 1454 "core/cfg.y"
    { rt_timer1_prio=(yyvsp[(3) - (3)].intval); }
    break;

  case 350:
#line 1455 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 351:
#line 1456 "core/cfg.y"
    { rt_timer1_policy=(yyvsp[(3) - (3)].intval); }
    break;

  case 352:
#line 1457 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 353:
#line 1458 "core/cfg.y"
    { rt_timer2_prio=(yyvsp[(3) - (3)].intval); }
    break;

  case 354:
#line 1459 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 355:
#line 1460 "core/cfg.y"
    { rt_timer2_policy=(yyvsp[(3) - (3)].intval); }
    break;

  case 356:
#line 1461 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 357:
#line 1462 "core/cfg.y"
    {
		#ifdef USE_MCAST
			mcast_loopback=(yyvsp[(3) - (3)].intval);
		#else
			warn("no multicast support compiled in");
		#endif
	}
    break;

  case 358:
#line 1469 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 359:
#line 1470 "core/cfg.y"
    {
		#ifdef USE_MCAST
			mcast_ttl=(yyvsp[(3) - (3)].intval);
		#else
			warn("no multicast support compiled in");
		#endif
	}
    break;

  case 360:
#line 1477 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 361:
#line 1478 "core/cfg.y"
    {
		#ifdef USE_MCAST
			mcast=(yyvsp[(3) - (3)].strval);
		#else
			warn("no multicast support compiled in");
		#endif
	}
    break;

  case 362:
#line 1485 "core/cfg.y"
    {
		#ifdef USE_MCAST
			mcast=(yyvsp[(3) - (3)].strval);
		#else
			warn("no multicast support compiled in");
		#endif
	}
    break;

  case 363:
#line 1492 "core/cfg.y"
    { yyerror("string expected"); }
    break;

  case 364:
#line 1493 "core/cfg.y"
    { tos=(yyvsp[(3) - (3)].intval); }
    break;

  case 365:
#line 1494 "core/cfg.y"
    { if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_LOWDELAY")) {
			tos=IPTOS_LOWDELAY;
		} else if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_THROUGHPUT")) {
			tos=IPTOS_THROUGHPUT;
		} else if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_RELIABILITY")) {
			tos=IPTOS_RELIABILITY;
#if defined(IPTOS_MINCOST)
		} else if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_MINCOST")) {
			tos=IPTOS_MINCOST;
#endif
#if defined(IPTOS_LOWCOST)
		} else if (strcasecmp((yyvsp[(3) - (3)].strval),"IPTOS_LOWCOST")) {
			tos=IPTOS_LOWCOST;
#endif
		} else {
			yyerror("invalid tos value - allowed: "
				"IPTOS_LOWDELAY,IPTOS_THROUGHPUT,"
				"IPTOS_RELIABILITY"
#if defined(IPTOS_LOWCOST)
				",IPTOS_LOWCOST"
#endif
#if !defined(IPTOS_MINCOST)
				",IPTOS_MINCOST"
#endif
				"\n");
		}
	}
    break;

  case 366:
#line 1521 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 367:
#line 1522 "core/cfg.y"
    { pmtu_discovery=(yyvsp[(3) - (3)].intval); }
    break;

  case 368:
#line 1523 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 369:
#line 1524 "core/cfg.y"
    { ser_kill_timeout=(yyvsp[(3) - (3)].intval); }
    break;

  case 370:
#line 1525 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 371:
#line 1526 "core/cfg.y"
    { default_core_cfg.max_while_loops=(yyvsp[(3) - (3)].intval); }
    break;

  case 372:
#line 1527 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 373:
#line 1528 "core/cfg.y"
    { pv_set_buffer_size((yyvsp[(3) - (3)].intval)); }
    break;

  case 374:
#line 1529 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 375:
#line 1530 "core/cfg.y"
    { pv_set_buffer_slots((yyvsp[(3) - (3)].intval)); }
    break;

  case 376:
#line 1531 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 377:
#line 1532 "core/cfg.y"
    { http_reply_parse=(yyvsp[(3) - (3)].intval); }
    break;

  case 378:
#line 1533 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 379:
#line 1534 "core/cfg.y"
    { server_id=(yyvsp[(3) - (3)].intval); }
    break;

  case 380:
#line 1535 "core/cfg.y"
    { set_max_recursive_level((yyvsp[(3) - (3)].intval)); }
    break;

  case 381:
#line 1536 "core/cfg.y"
    { sr_dst_max_branches = (yyvsp[(3) - (3)].intval); }
    break;

  case 382:
#line 1537 "core/cfg.y"
    { default_core_cfg.latency_log=(yyvsp[(3) - (3)].intval); }
    break;

  case 383:
#line 1538 "core/cfg.y"
    { yyerror("number  expected"); }
    break;

  case 384:
#line 1539 "core/cfg.y"
    { default_core_cfg.latency_cfg_log=(yyvsp[(3) - (3)].intval); }
    break;

  case 385:
#line 1540 "core/cfg.y"
    { yyerror("number  expected"); }
    break;

  case 386:
#line 1541 "core/cfg.y"
    { default_core_cfg.latency_limit_db=(yyvsp[(3) - (3)].intval); }
    break;

  case 387:
#line 1542 "core/cfg.y"
    { yyerror("number  expected"); }
    break;

  case 388:
#line 1543 "core/cfg.y"
    { default_core_cfg.latency_limit_action=(yyvsp[(3) - (3)].intval); }
    break;

  case 389:
#line 1544 "core/cfg.y"
    { yyerror("number  expected"); }
    break;

  case 390:
#line 1545 "core/cfg.y"
    { sr_msg_time=(yyvsp[(3) - (3)].intval); }
    break;

  case 391:
#line 1546 "core/cfg.y"
    { yyerror("number  expected"); }
    break;

  case 392:
#line 1547 "core/cfg.y"
    { onsend_route_reply=(yyvsp[(3) - (3)].intval); }
    break;

  case 393:
#line 1548 "core/cfg.y"
    { yyerror("int value expected"); }
    break;

  case 394:
#line 1549 "core/cfg.y"
    { default_core_cfg.udp_mtu=(yyvsp[(3) - (3)].intval); }
    break;

  case 395:
#line 1550 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 396:
#line 1552 "core/cfg.y"
    { default_core_cfg.force_rport=(yyvsp[(3) - (3)].intval); fix_global_req_flags(0, 0); }
    break;

  case 397:
#line 1553 "core/cfg.y"
    { yyerror("boolean value expected"); }
    break;

  case 398:
#line 1555 "core/cfg.y"
    { default_core_cfg.udp_mtu_try_proto=(yyvsp[(3) - (3)].intval); fix_global_req_flags(0, 0); }
    break;

  case 399:
#line 1557 "core/cfg.y"
    { yyerror("TCP, TLS, SCTP or UDP expected"); }
    break;

  case 400:
#line 1558 "core/cfg.y"
    { IF_RAW_SOCKS(default_core_cfg.udp4_raw=(yyvsp[(3) - (3)].intval)); }
    break;

  case 401:
#line 1559 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 402:
#line 1560 "core/cfg.y"
    {
		IF_RAW_SOCKS(default_core_cfg.udp4_raw_mtu=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 403:
#line 1563 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 404:
#line 1564 "core/cfg.y"
    {
		IF_RAW_SOCKS(default_core_cfg.udp4_raw_ttl=(yyvsp[(3) - (3)].intval));
	}
    break;

  case 405:
#line 1567 "core/cfg.y"
    { yyerror("number expected"); }
    break;

  case 407:
#line 1569 "core/cfg.y"
    { yyerror("unknown config variable"); }
    break;

  case 409:
#line 1573 "core/cfg.y"
    { (yyval.strval)="default" ; }
    break;

  case 411:
#line 1577 "core/cfg.y"
    { (yyval.strval)="default" ; }
    break;

  case 412:
#line 1578 "core/cfg.y"
    {
		yyerror("cfg var field name - use of number or reserved token not allowed: %s",
				yy_number_str);
		YYERROR;
	}
    break;

  case 413:
#line 1586 "core/cfg.y"
    {
		if (cfg_declare_int((yyvsp[(1) - (5)].strval), (yyvsp[(3) - (5)].strval), (yyvsp[(5) - (5)].intval), 0, 0, NULL)) {
			yyerror("variable cannot be declared");
		}
	}
    break;

  case 414:
#line 1591 "core/cfg.y"
    {
		if (cfg_declare_str((yyvsp[(1) - (5)].strval), (yyvsp[(3) - (5)].strval), (yyvsp[(5) - (5)].strval), NULL)) {
			yyerror("variable cannot be declared");
		}
	}
    break;

  case 415:
#line 1596 "core/cfg.y"
    {
		if (cfg_declare_int((yyvsp[(1) - (7)].strval), (yyvsp[(3) - (7)].strval), (yyvsp[(5) - (7)].intval), 0, 0, (yyvsp[(7) - (7)].strval))) {
			yyerror("variable cannot be declared");
		}
	}
    break;

  case 416:
#line 1601 "core/cfg.y"
    {
		if (cfg_declare_str((yyvsp[(1) - (7)].strval), (yyvsp[(3) - (7)].strval), (yyvsp[(5) - (7)].strval), (yyvsp[(7) - (7)].strval))) {
			yyerror("variable cannot be declared");
		}
	}
    break;

  case 417:
#line 1606 "core/cfg.y"
    {
		yyerror("number or string expected");
	}
    break;

  case 418:
#line 1609 "core/cfg.y"
    {
		if (cfg_ginst_var_int((yyvsp[(1) - (8)].strval), (yyvsp[(3) - (8)].intval), (yyvsp[(6) - (8)].strval), (yyvsp[(8) - (8)].intval))) {
			yyerror("variable cannot be added to the group instance");
		}
	}
    break;

  case 419:
#line 1614 "core/cfg.y"
    {
		if (cfg_ginst_var_string((yyvsp[(1) - (8)].strval), (yyvsp[(3) - (8)].intval), (yyvsp[(6) - (8)].strval), (yyvsp[(8) - (8)].strval))) {
			yyerror("variable cannot be added to the group instance");
		}
	}
    break;

  case 420:
#line 1622 "core/cfg.y"
    {
		LM_DBG("loading module %s\n", (yyvsp[(2) - (2)].strval));
			if (load_module((yyvsp[(2) - (2)].strval))!=0) {
				yyerror("failed to load module");
			}
	}
    break;

  case 421:
#line 1628 "core/cfg.y"
    { yyerror("string expected"); }
    break;

  case 422:
#line 1629 "core/cfg.y"
    {
		if(mods_dir_cmd==0) {
			LM_DBG("loading modules under %s\n", (yyvsp[(2) - (2)].strval));
			printf("loading modules under config path: %s\n", (yyvsp[(2) - (2)].strval));
			mods_dir = (yyvsp[(2) - (2)].strval);
		} else {
			LM_DBG("ignoring mod path given in config: %s\n", (yyvsp[(2) - (2)].strval));
			printf("loading modules under command line path: %s\n", mods_dir);
		}
	}
    break;

  case 423:
#line 1639 "core/cfg.y"
    { yyerror("string expected"); }
    break;

  case 424:
#line 1640 "core/cfg.y"
    {
		if(mods_dir_cmd==0) {
			LM_DBG("loading modules under %s\n", (yyvsp[(3) - (3)].strval));
			printf("loading modules under config path: %s\n", (yyvsp[(3) - (3)].strval));
			mods_dir = (yyvsp[(3) - (3)].strval);
		} else {
			LM_DBG("ignoring mod path given in config: %s\n", (yyvsp[(3) - (3)].strval));
			printf("loading modules under command line path: %s\n", mods_dir);
		}
	}
    break;

  case 425:
#line 1650 "core/cfg.y"
    { yyerror("string expected"); }
    break;

  case 426:
#line 1651 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		if (set_mod_param_regex((yyvsp[(3) - (8)].strval), (yyvsp[(5) - (8)].strval), PARAM_STRING, (yyvsp[(7) - (8)].strval)) != 0) {
			 yyerror("Can't set module parameter");
		}
	}
    break;

  case 427:
#line 1662 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		if (set_mod_param_regex((yyvsp[(3) - (8)].strval), (yyvsp[(5) - (8)].strval), PARAM_INT, (void*)(yyvsp[(7) - (8)].intval)) != 0) {
			 yyerror("Can't set module parameter");
		}
	}
    break;

  case 428:
#line 1673 "core/cfg.y"
    { yyerror("Invalid arguments"); }
    break;

  case 429:
#line 1674 "core/cfg.y"
    {
		if(sr_kemi_eng_setz((yyvsp[(2) - (2)].strval), NULL)) {
			yyerror("Can't set config routing engine");
			YYABORT;
		}
	}
    break;

  case 430:
#line 1680 "core/cfg.y"
    { yyerror("string expected"); }
    break;

  case 431:
#line 1681 "core/cfg.y"
    {
		if(sr_kemi_eng_setz((yyvsp[(3) - (3)].strval), NULL)) {
			yyerror("Can't set config routing engine");
			YYABORT;
		}
	}
    break;

  case 432:
#line 1687 "core/cfg.y"
    { yyerror("string expected"); }
    break;

  case 433:
#line 1691 "core/cfg.y"
    { (yyval.ipaddr)=(yyvsp[(1) - (1)].ipaddr); }
    break;

  case 434:
#line 1692 "core/cfg.y"
    { (yyval.ipaddr)=(yyvsp[(1) - (1)].ipaddr); }
    break;

  case 435:
#line 1695 "core/cfg.y"
    {
		(yyval.ipaddr)=pkg_malloc(sizeof(struct ip_addr));
		if ((yyval.ipaddr)==0) {
			LM_CRIT("cfg. parser: out of memory.\n");
		} else {
			memset((yyval.ipaddr), 0, sizeof(struct ip_addr));
			(yyval.ipaddr)->af=AF_INET;
			(yyval.ipaddr)->len=4;
			if (((yyvsp[(1) - (7)].intval)>255) || ((yyvsp[(1) - (7)].intval)<0) ||
				((yyvsp[(3) - (7)].intval)>255) || ((yyvsp[(3) - (7)].intval)<0) ||
				((yyvsp[(5) - (7)].intval)>255) || ((yyvsp[(5) - (7)].intval)<0) ||
				((yyvsp[(7) - (7)].intval)>255) || ((yyvsp[(7) - (7)].intval)<0)) {
				yyerror("invalid ipv4 address");
				(yyval.ipaddr)->u.addr32[0]=0;
				/* $$=0; */
			} else {
				(yyval.ipaddr)->u.addr[0]=(yyvsp[(1) - (7)].intval);
				(yyval.ipaddr)->u.addr[1]=(yyvsp[(3) - (7)].intval);
				(yyval.ipaddr)->u.addr[2]=(yyvsp[(5) - (7)].intval);
				(yyval.ipaddr)->u.addr[3]=(yyvsp[(7) - (7)].intval);
				/*
				$$=htonl( ($1<<24)|
				($3<<16)| ($5<<8)|$7 );
				*/
			}
		}
	}
    break;

  case 436:
#line 1724 "core/cfg.y"
    {
		(yyval.ipaddr)=pkg_malloc(sizeof(struct ip_addr));
		if ((yyval.ipaddr)==0) {
			LM_CRIT("cfg. parser: out of memory.\n");
		} else {
			memset((yyval.ipaddr), 0, sizeof(struct ip_addr));
			(yyval.ipaddr)->af=AF_INET6;
			(yyval.ipaddr)->len=16;
			if (inet_pton(AF_INET6, (yyvsp[(1) - (1)].strval), (yyval.ipaddr)->u.addr)<=0) {
				yyerror("bad ipv6 address");
			}
		}
	}
    break;

  case 437:
#line 1739 "core/cfg.y"
    { (yyval.ipaddr)=(yyvsp[(1) - (1)].ipaddr); }
    break;

  case 438:
#line 1740 "core/cfg.y"
    {(yyval.ipaddr)=(yyvsp[(2) - (3)].ipaddr); }
    break;

  case 439:
#line 1744 "core/cfg.y"
    {
					tmp=int2str((yyvsp[(1) - (1)].intval), &i_tmp);
					if (((yyval.strval)=pkg_malloc(i_tmp+1))==0) {
						yyerror("out of  memory");
						YYABORT;
					} else {
						memcpy((yyval.strval), tmp, i_tmp);
						(yyval.strval)[i_tmp]=0;
					}
					routename = tmp;
						}
    break;

  case 440:
#line 1755 "core/cfg.y"
    { routename = (yyvsp[(1) - (1)].strval); (yyval.strval)=(yyvsp[(1) - (1)].strval); }
    break;

  case 441:
#line 1756 "core/cfg.y"
    { routename = (yyvsp[(1) - (1)].strval); (yyval.strval)=(yyvsp[(1) - (1)].strval); }
    break;

  case 442:
#line 1760 "core/cfg.y"
    { routename=NULL; }
    break;

  case 443:
#line 1761 "core/cfg.y"
    { routename=NULL; }
    break;

  case 444:
#line 1765 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		push((yyvsp[(3) - (4)].action), &main_rt.rlist[DEFAULT_RT]);
	}
    break;

  case 445:
#line 1774 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		i_tmp=route_get(&main_rt, (yyvsp[(3) - (7)].strval));
		if (i_tmp==-1){
			yyerror("internal error");
			YYABORT;
		}
		if (main_rt.rlist[i_tmp]){
			yyerror("duplicate route");
			YYABORT;
		}
		push((yyvsp[(6) - (7)].action), &main_rt.rlist[i_tmp]);
	}
    break;

  case 446:
#line 1792 "core/cfg.y"
    { yyerror("invalid  route  statement"); }
    break;

  case 447:
#line 1793 "core/cfg.y"
    { yyerror("invalid  request_route  statement"); }
    break;

  case 448:
#line 1796 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		push((yyvsp[(3) - (4)].action), &failure_rt.rlist[DEFAULT_RT]);
	}
    break;

  case 449:
#line 1805 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		i_tmp=route_get(&failure_rt, (yyvsp[(3) - (7)].strval));
		if (i_tmp==-1){
			yyerror("internal error");
			YYABORT;
		}
		if (failure_rt.rlist[i_tmp]){
			yyerror("duplicate route");
			YYABORT;
		}
		push((yyvsp[(6) - (7)].action), &failure_rt.rlist[i_tmp]);
	}
    break;

  case 450:
#line 1823 "core/cfg.y"
    { yyerror("invalid failure_route statement"); }
    break;

  case 451:
#line 1827 "core/cfg.y"
    { routename=NULL; }
    break;

  case 452:
#line 1828 "core/cfg.y"
    { routename=NULL; }
    break;

  case 453:
#line 1833 "core/cfg.y"
    {rt=CORE_ONREPLY_ROUTE;}
    break;

  case 454:
#line 1833 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		push((yyvsp[(4) - (5)].action), &onreply_rt.rlist[DEFAULT_RT]);
	}
    break;

  case 455:
#line 1842 "core/cfg.y"
    { yyerror("invalid onreply_route statement"); }
    break;

  case 456:
#line 1843 "core/cfg.y"
    { yyerror("invalid onreply_route statement"); }
    break;

  case 457:
#line 1845 "core/cfg.y"
    {rt=(*(yyvsp[(3) - (4)].strval)=='0' && (yyvsp[(3) - (4)].strval)[1]==0)?CORE_ONREPLY_ROUTE:TM_ONREPLY_ROUTE;}
    break;

  case 458:
#line 1846 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		if (*(yyvsp[(3) - (8)].strval)=='0' && (yyvsp[(3) - (8)].strval)[1]==0){
			/* onreply_route[0] {} is equivalent with onreply_route {}*/
			push((yyvsp[(7) - (8)].action), &onreply_rt.rlist[DEFAULT_RT]);
		}else{
			i_tmp=route_get(&onreply_rt, (yyvsp[(3) - (8)].strval));
			if (i_tmp==-1){
				yyerror("internal error");
				YYABORT;
			}
			if (onreply_rt.rlist[i_tmp]){
				yyerror("duplicate route");
				YYABORT;
			}
			push((yyvsp[(7) - (8)].action), &onreply_rt.rlist[i_tmp]);
		}
	}
    break;

  case 459:
#line 1869 "core/cfg.y"
    {
		yyerror("invalid onreply_route statement");
	}
    break;

  case 460:
#line 1874 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		push((yyvsp[(3) - (4)].action), &branch_rt.rlist[DEFAULT_RT]);
	}
    break;

  case 461:
#line 1883 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		i_tmp=route_get(&branch_rt, (yyvsp[(3) - (7)].strval));
		if (i_tmp==-1){
			yyerror("internal error");
			YYABORT;
		}
		if (branch_rt.rlist[i_tmp]){
			yyerror("duplicate route");
			YYABORT;
		}
		push((yyvsp[(6) - (7)].action), &branch_rt.rlist[i_tmp]);
	}
    break;

  case 462:
#line 1901 "core/cfg.y"
    { yyerror("invalid branch_route statement"); }
    break;

  case 463:
#line 1903 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		push((yyvsp[(3) - (4)].action), &onsend_rt.rlist[DEFAULT_RT]);
	}
    break;

  case 464:
#line 1912 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		i_tmp=route_get(&onsend_rt, (yyvsp[(3) - (7)].strval));
		if (i_tmp==-1){
			yyerror("internal error");
			YYABORT;
		}
		if (onsend_rt.rlist[i_tmp]){
			yyerror("duplicate route");
			YYABORT;
		}
		push((yyvsp[(6) - (7)].action), &onsend_rt.rlist[i_tmp]);
	}
    break;

  case 465:
#line 1930 "core/cfg.y"
    { yyerror("invalid onsend_route statement"); }
    break;

  case 466:
#line 1932 "core/cfg.y"
    {
	#ifdef SHM_MEM
		if (!shm_initialized() && init_shm()<0) {
			yyerror("Can't initialize shared memory");
			YYABORT;
		}
	#endif /* SHM_MEM */
		i_tmp=route_get(&event_rt, (yyvsp[(3) - (7)].strval));
		if (i_tmp==-1){
			yyerror("internal error");
			YYABORT;
		}
		if (event_rt.rlist[i_tmp]){
			yyerror("duplicate route");
			YYABORT;
		}
		push((yyvsp[(6) - (7)].action), &event_rt.rlist[i_tmp]);
	}
    break;

  case 467:
#line 1951 "core/cfg.y"
    { yyerror("invalid event_route statement"); }
    break;

  case 468:
#line 1954 "core/cfg.y"
    { if(pp_subst_add((yyvsp[(2) - (2)].strval))<0) YYERROR; }
    break;

  case 469:
#line 1955 "core/cfg.y"
    { yyerror("invalid subst preprocess statement"); }
    break;

  case 470:
#line 1956 "core/cfg.y"
    { if(pp_substdef_add((yyvsp[(2) - (2)].strval), 0)<0) YYERROR; }
    break;

  case 471:
#line 1957 "core/cfg.y"
    { yyerror("invalid substdef preprocess statement"); }
    break;

  case 472:
#line 1958 "core/cfg.y"
    { if(pp_substdef_add((yyvsp[(2) - (2)].strval), 1)<0) YYERROR; }
    break;

  case 473:
#line 1959 "core/cfg.y"
    { yyerror("invalid substdefs preprocess statement"); }
    break;

  case 474:
#line 1981 "core/cfg.y"
    {(yyval.intval)=EQUAL_OP; }
    break;

  case 475:
#line 1982 "core/cfg.y"
    {(yyval.intval)=DIFF_OP; }
    break;

  case 476:
#line 1983 "core/cfg.y"
    {(yyval.intval)=EQUAL_OP; }
    break;

  case 477:
#line 1984 "core/cfg.y"
    {(yyval.intval)=DIFF_OP; }
    break;

  case 478:
#line 1987 "core/cfg.y"
    {(yyval.intval)=GT_OP; }
    break;

  case 479:
#line 1988 "core/cfg.y"
    {(yyval.intval)=LT_OP; }
    break;

  case 480:
#line 1989 "core/cfg.y"
    {(yyval.intval)=GTE_OP; }
    break;

  case 481:
#line 1990 "core/cfg.y"
    {(yyval.intval)=LTE_OP; }
    break;

  case 482:
#line 1993 "core/cfg.y"
    {(yyval.intval)=(yyvsp[(1) - (1)].intval); }
    break;

  case 483:
#line 1994 "core/cfg.y"
    {(yyval.intval)=MATCH_OP; }
    break;

  case 484:
#line 2000 "core/cfg.y"
    {(yyval.intval)=RVE_EQ_OP; }
    break;

  case 485:
#line 2001 "core/cfg.y"
    {(yyval.intval)=RVE_DIFF_OP; }
    break;

  case 486:
#line 2002 "core/cfg.y"
    {(yyval.intval)=RVE_IEQ_OP; }
    break;

  case 487:
#line 2003 "core/cfg.y"
    {(yyval.intval)=RVE_IDIFF_OP; }
    break;

  case 488:
#line 2004 "core/cfg.y"
    {(yyval.intval)=RVE_STREQ_OP; }
    break;

  case 489:
#line 2005 "core/cfg.y"
    {(yyval.intval)=RVE_STRDIFF_OP; }
    break;

  case 490:
#line 2006 "core/cfg.y"
    {(yyval.intval)=RVE_MATCH_OP; }
    break;

  case 491:
#line 2009 "core/cfg.y"
    {(yyval.intval)=RVE_GT_OP; }
    break;

  case 492:
#line 2010 "core/cfg.y"
    {(yyval.intval)=RVE_LT_OP; }
    break;

  case 493:
#line 2011 "core/cfg.y"
    {(yyval.intval)=RVE_GTE_OP; }
    break;

  case 494:
#line 2012 "core/cfg.y"
    {(yyval.intval)=RVE_LTE_OP; }
    break;

  case 495:
#line 2019 "core/cfg.y"
    {(yyval.intval)=URI_O;}
    break;

  case 496:
#line 2020 "core/cfg.y"
    {(yyval.intval)=FROM_URI_O;}
    break;

  case 497:
#line 2021 "core/cfg.y"
    {(yyval.intval)=TO_URI_O;}
    break;

  case 498:
#line 2028 "core/cfg.y"
    { (yyval.intval)=SNDPORT_O; }
    break;

  case 499:
#line 2029 "core/cfg.y"
    { (yyval.intval)=TOPORT_O; }
    break;

  case 500:
#line 2030 "core/cfg.y"
    { (yyval.intval)=SNDAF_O; }
    break;

  case 501:
#line 2034 "core/cfg.y"
    { (yyval.intval)=SRCPORT_O; }
    break;

  case 502:
#line 2035 "core/cfg.y"
    { (yyval.intval)=DSTPORT_O; }
    break;

  case 503:
#line 2036 "core/cfg.y"
    { (yyval.intval)=AF_O; }
    break;

  case 504:
#line 2037 "core/cfg.y"
    { (yyval.intval)=MSGLEN_O; }
    break;

  case 506:
#line 2043 "core/cfg.y"
    { onsend_check("snd_ip"); (yyval.intval)=SNDIP_O; }
    break;

  case 507:
#line 2044 "core/cfg.y"
    { onsend_check("to_ip");  (yyval.intval)=TOIP_O; }
    break;

  case 508:
#line 2047 "core/cfg.y"
    { (yyval.intval)=SRCIP_O; }
    break;

  case 509:
#line 2048 "core/cfg.y"
    { (yyval.intval)=DSTIP_O; }
    break;

  case 511:
#line 2056 "core/cfg.y"
    {(yyval.expr)= mk_elem((yyvsp[(2) - (3)].intval), METHOD_O, 0, RVE_ST, (yyvsp[(3) - (3)].rv_expr));}
    break;

  case 512:
#line 2058 "core/cfg.y"
    {(yyval.expr) = mk_elem((yyvsp[(2) - (3)].intval), METHOD_O, 0, STRING_ST,(yyvsp[(3) - (3)].strval)); }
    break;

  case 513:
#line 2059 "core/cfg.y"
    { (yyval.expr)=0; yyerror("string expected"); }
    break;

  case 514:
#line 2061 "core/cfg.y"
    { (yyval.expr)=0; yyerror("invalid operator,== , !=, or =~ expected"); }
    break;

  case 515:
#line 2063 "core/cfg.y"
    {(yyval.expr) = mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, RVE_ST, (yyvsp[(3) - (3)].rv_expr)); }
    break;

  case 516:
#line 2065 "core/cfg.y"
    {(yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, MYSELF_ST, 0); }
    break;

  case 517:
#line 2067 "core/cfg.y"
    { (yyval.expr)=0; yyerror("string or MYSELF expected"); }
    break;

  case 518:
#line 2069 "core/cfg.y"
    { (yyval.expr)=0; yyerror("invalid operator, == , != or =~ expected"); }
    break;

  case 519:
#line 2070 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, RVE_ST, (yyvsp[(3) - (3)].rv_expr) ); }
    break;

  case 520:
#line 2072 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, RVE_ST, (yyvsp[(3) - (3)].rv_expr) ); }
    break;

  case 521:
#line 2073 "core/cfg.y"
    { (yyval.expr)=0; yyerror("number expected"); }
    break;

  case 522:
#line 2074 "core/cfg.y"
    { (yyval.expr)=0; yyerror("number expected"); }
    break;

  case 523:
#line 2075 "core/cfg.y"
    { (yyval.expr)=0; yyerror("==, !=, <,>, >= or <=  expected"); }
    break;

  case 524:
#line 2077 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), PROTO_O, 0, NUMBER_ST, (void*)(yyvsp[(3) - (3)].intval) ); }
    break;

  case 525:
#line 2079 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), PROTO_O, 0, RVE_ST, (yyvsp[(3) - (3)].rv_expr) ); }
    break;

  case 526:
#line 2081 "core/cfg.y"
    { (yyval.expr)=0; yyerror("protocol expected (udp, tcp, tls, sctp, ws, or wss)"); }
    break;

  case 527:
#line 2083 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SNDPROTO_O, 0, NUMBER_ST, (void*)(yyvsp[(3) - (3)].intval) ); }
    break;

  case 528:
#line 2085 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), SNDPROTO_O, 0, RVE_ST, (yyvsp[(3) - (3)].rv_expr) ); }
    break;

  case 529:
#line 2087 "core/cfg.y"
    { (yyval.expr)=0; yyerror("protocol expected (udp, tcp, tls, sctp, ws, or wss)"); }
    break;

  case 530:
#line 2088 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, NET_ST, (yyvsp[(3) - (3)].ipnet)); }
    break;

  case 531:
#line 2089 "core/cfg.y"
    {
			s_tmp.s=0;
			(yyval.expr)=0;
			if (rve_is_constant((yyvsp[(3) - (3)].rv_expr))){
				i_tmp=rve_guess_type((yyvsp[(3) - (3)].rv_expr));
				if (i_tmp==RV_INT)
					yyerror("string expected");
				else if (i_tmp==RV_STR){
					if (((rval_tmp=rval_expr_eval(0, 0, (yyvsp[(3) - (3)].rv_expr)))==0) ||
								(rval_get_str(0, 0, &s_tmp, rval_tmp, 0)<0)){
						rval_destroy(rval_tmp);
						yyerror("bad rvalue expression");
					}else{
						rval_destroy(rval_tmp);
					}
				}else{
					yyerror("BUG: unexpected dynamic type");
				}
			}else{
					/* warn("non constant rvalue in ip comparison") */;
			}
			if (s_tmp.s){
				ip_tmp=str2ip(&s_tmp);
				if (ip_tmp==0)
					ip_tmp=str2ip6(&s_tmp);
				pkg_free(s_tmp.s);
				if (ip_tmp) {
					(yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, NET_ST,
								mk_new_net_bitlen(ip_tmp, ip_tmp->len*8) );
				} else {
					(yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, RVE_ST, (yyvsp[(3) - (3)].rv_expr));
				}
			}else{
				(yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, RVE_ST, (yyvsp[(3) - (3)].rv_expr));
			}
		}
    break;

  case 532:
#line 2126 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, STRING_ST, (yyvsp[(3) - (3)].strval)); }
    break;

  case 533:
#line 2128 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].intval), 0, MYSELF_ST, 0); }
    break;

  case 534:
#line 2130 "core/cfg.y"
    { (yyval.expr)=0; yyerror( "ip address or hostname expected" ); }
    break;

  case 535:
#line 2132 "core/cfg.y"
    { (yyval.expr)=0; yyerror("invalid operator, ==, != or =~ expected");}
    break;

  case 536:
#line 2135 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(3) - (3)].intval), 0, MYSELF_ST, 0); }
    break;

  case 537:
#line 2137 "core/cfg.y"
    { (yyval.expr)=mk_elem((yyvsp[(2) - (3)].intval), (yyvsp[(3) - (3)].intval), 0, MYSELF_ST, 0); }
    break;

  case 538:
#line 2139 "core/cfg.y"
    { (yyval.expr)=0; yyerror("URI, SRCIP or DSTIP expected"); }
    break;

  case 539:
#line 2140 "core/cfg.y"
    { (yyval.expr)=0; yyerror ("invalid operator, == or != expected"); }
    break;

  case 540:
#line 2144 "core/cfg.y"
    { (yyval.ipnet)=mk_new_net((yyvsp[(1) - (3)].ipaddr), (yyvsp[(3) - (3)].ipaddr)); }
    break;

  case 541:
#line 2145 "core/cfg.y"
    {
		if (((yyvsp[(3) - (3)].intval)<0) || ((yyvsp[(3) - (3)].intval)>(yyvsp[(1) - (3)].ipaddr)->len*8)) {
			yyerror("invalid bit number in netmask");
			(yyval.ipnet)=0;
		} else {
			(yyval.ipnet)=mk_new_net_bitlen((yyvsp[(1) - (3)].ipaddr), (yyvsp[(3) - (3)].intval));
		/*
			$$=mk_new_net($1, htonl( ($3)?~( (1<<(32-$3))-1 ):0 ) );
		*/
		}
	}
    break;

  case 542:
#line 2156 "core/cfg.y"
    { (yyval.ipnet)=mk_new_net_bitlen((yyvsp[(1) - (1)].ipaddr), (yyvsp[(1) - (1)].ipaddr)->len*8); }
    break;

  case 543:
#line 2157 "core/cfg.y"
    { (yyval.ipnet)=0; yyerror("netmask (eg:255.0.0.0 or 8) expected"); }
    break;

  case 544:
#line 2161 "core/cfg.y"
    { (yyval.strval)=(yyvsp[(1) - (1)].strval); }
    break;

  case 545:
#line 2162 "core/cfg.y"
    {
		if ((yyvsp[(1) - (3)].strval)){
			(yyval.strval)=(char*)pkg_malloc(strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))+1);
			if ((yyval.strval)==0) {
				LM_CRIT("cfg. parser: memory allocation"
							" failure while parsing host\n");
			} else {
				memcpy((yyval.strval), (yyvsp[(1) - (3)].strval), strlen((yyvsp[(1) - (3)].strval)));
				(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))]='.';
				memcpy((yyval.strval)+strlen((yyvsp[(1) - (3)].strval))+1, (yyvsp[(3) - (3)].strval), strlen((yyvsp[(3) - (3)].strval)));
				(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))]=0;
			}
			pkg_free((yyvsp[(1) - (3)].strval));
		}
		if ((yyvsp[(3) - (3)].strval)) pkg_free((yyvsp[(3) - (3)].strval));
	}
    break;

  case 546:
#line 2178 "core/cfg.y"
    {
		if ((yyvsp[(1) - (3)].strval)){
			(yyval.strval)=(char*)pkg_malloc(strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))+1);
			if ((yyval.strval)==0) {
				LM_CRIT("cfg. parser: memory allocation"
							" failure while parsing host\n");
			} else {
				memcpy((yyval.strval), (yyvsp[(1) - (3)].strval), strlen((yyvsp[(1) - (3)].strval)));
				(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))]='-';
				memcpy((yyval.strval)+strlen((yyvsp[(1) - (3)].strval))+1, (yyvsp[(3) - (3)].strval), strlen((yyvsp[(3) - (3)].strval)));
				(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))]=0;
			}
			pkg_free((yyvsp[(1) - (3)].strval));
		}
		if ((yyvsp[(3) - (3)].strval)) pkg_free((yyvsp[(3) - (3)].strval));
	}
    break;

  case 547:
#line 2194 "core/cfg.y"
    { (yyval.strval)=0; pkg_free((yyvsp[(1) - (3)].strval)); yyerror("invalid hostname"); }
    break;

  case 548:
#line 2195 "core/cfg.y"
    { (yyval.strval)=0; pkg_free((yyvsp[(1) - (3)].strval)); yyerror("invalid hostname"); }
    break;

  case 551:
#line 2200 "core/cfg.y"
    {
			/* get string version */
			(yyval.strval)=pkg_malloc(strlen(yy_number_str)+1);
			if ((yyval.strval))
				strcpy((yyval.strval), yy_number_str);
		}
    break;

  case 552:
#line 2209 "core/cfg.y"
    { (yyval.strval)=(yyvsp[(1) - (1)].strval); }
    break;

  case 553:
#line 2210 "core/cfg.y"
    {
		if ((yyvsp[(1) - (3)].strval)){
			(yyval.strval)=(char*)pkg_malloc(strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))+1);
			if ((yyval.strval)==0) {
				LM_CRIT("cfg. parser: memory allocation"
							" failure while parsing host/interface name\n");
			} else {
				memcpy((yyval.strval), (yyvsp[(1) - (3)].strval), strlen((yyvsp[(1) - (3)].strval)));
				(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))]='.';
				memcpy((yyval.strval)+strlen((yyvsp[(1) - (3)].strval))+1, (yyvsp[(3) - (3)].strval), strlen((yyvsp[(3) - (3)].strval)));
				(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))]=0;
			}
			pkg_free((yyvsp[(1) - (3)].strval));
		}
		if ((yyvsp[(3) - (3)].strval)) pkg_free((yyvsp[(3) - (3)].strval));
	}
    break;

  case 554:
#line 2226 "core/cfg.y"
    {
		if ((yyvsp[(1) - (3)].strval)){
			(yyval.strval)=(char*)pkg_malloc(strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))+1);
			if ((yyval.strval)==0) {
				LM_CRIT("cfg. parser: memory allocation"
							" failure while parsing host/interface name\n");
			} else {
				memcpy((yyval.strval), (yyvsp[(1) - (3)].strval), strlen((yyvsp[(1) - (3)].strval)));
				(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))]='-';
				memcpy((yyval.strval)+strlen((yyvsp[(1) - (3)].strval))+1, (yyvsp[(3) - (3)].strval), strlen((yyvsp[(3) - (3)].strval)));
				(yyval.strval)[strlen((yyvsp[(1) - (3)].strval))+1+strlen((yyvsp[(3) - (3)].strval))]=0;
			}
			pkg_free((yyvsp[(1) - (3)].strval));
		}
		if ((yyvsp[(3) - (3)].strval)) pkg_free((yyvsp[(3) - (3)].strval));
	}
    break;

  case 555:
#line 2242 "core/cfg.y"
    { (yyval.strval)=0; pkg_free((yyvsp[(1) - (3)].strval));
								yyerror("invalid host or interface name"); }
    break;

  case 556:
#line 2244 "core/cfg.y"
    { (yyval.strval)=0; pkg_free((yyvsp[(1) - (3)].strval));
								yyerror("invalid host or interface name"); }
    break;

  case 557:
#line 2251 "core/cfg.y"
    {
		/* check if allowed */
		if ((yyvsp[(1) - (1)].action) && rt==ONSEND_ROUTE) {
			switch((yyvsp[(1) - (1)].action)->type) {
				case DROP_T:
				case LOG_T:
				case SETFLAG_T:
				case RESETFLAG_T:
				case ISFLAGSET_T:
				case IF_T:
				case MODULE0_T:
				case MODULE1_T:
				case MODULE2_T:
				case MODULE3_T:
				case MODULE4_T:
				case MODULE5_T:
				case MODULE6_T:
				case MODULEX_T:
				case SET_FWD_NO_CONNECT_T:
				case SET_RPL_NO_CONNECT_T:
				case SET_FWD_CLOSE_T:
				case SET_RPL_CLOSE_T:
					(yyval.action)=(yyvsp[(1) - (1)].action);
					break;
				default:
					(yyval.action)=0;
					yyerror("command not allowed in onsend_route\n");
			}
		} else {
			(yyval.action)=(yyvsp[(1) - (1)].action);
		}
	}
    break;

  case 558:
#line 2293 "core/cfg.y"
    { (yyval.action)=(yyvsp[(1) - (1)].action); }
    break;

  case 559:
#line 2294 "core/cfg.y"
    { (yyval.action)=(yyvsp[(2) - (3)].action); }
    break;

  case 560:
#line 2297 "core/cfg.y"
    {(yyval.action)=append_action((yyvsp[(1) - (2)].action), (yyvsp[(2) - (2)].action)); }
    break;

  case 561:
#line 2298 "core/cfg.y"
    {(yyval.action)=(yyvsp[(1) - (1)].action);}
    break;

  case 562:
#line 2299 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad command"); }
    break;

  case 563:
#line 2302 "core/cfg.y"
    {(yyval.action)=(yyvsp[(1) - (2)].action);}
    break;

  case 564:
#line 2303 "core/cfg.y"
    {(yyval.action)=(yyvsp[(1) - (1)].action);}
    break;

  case 565:
#line 2304 "core/cfg.y"
    {(yyval.action)=(yyvsp[(1) - (1)].action);}
    break;

  case 566:
#line 2305 "core/cfg.y"
    { (yyval.action)=(yyvsp[(1) - (1)].action); }
    break;

  case 567:
#line 2306 "core/cfg.y"
    { (yyval.action)=(yyvsp[(1) - (2)].action); }
    break;

  case 568:
#line 2307 "core/cfg.y"
    {(yyval.action)=(yyvsp[(1) - (2)].action);}
    break;

  case 569:
#line 2308 "core/cfg.y"
    {(yyval.action)=0;}
    break;

  case 570:
#line 2309 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad command: missing ';'?"); }
    break;

  case 571:
#line 2312 "core/cfg.y"
    {
		if ((yyvsp[(2) - (3)].rv_expr) && rval_expr_int_check((yyvsp[(2) - (3)].rv_expr))>=0){
			warn_ct_rve((yyvsp[(2) - (3)].rv_expr), "if");
			(yyval.action)=mk_action( IF_T, 3, RVE_ST, (yyvsp[(2) - (3)].rv_expr), ACTIONS_ST, (yyvsp[(3) - (3)].action), NOSUBTYPE, 0);
			set_cfg_pos((yyval.action));
		}else
			YYERROR;
	}
    break;

  case 572:
#line 2320 "core/cfg.y"
    {
		if ((yyvsp[(2) - (5)].rv_expr) && rval_expr_int_check((yyvsp[(2) - (5)].rv_expr))>=0){
			warn_ct_rve((yyvsp[(2) - (5)].rv_expr), "if");
			(yyval.action)=mk_action( IF_T, 3, RVE_ST, (yyvsp[(2) - (5)].rv_expr), ACTIONS_ST, (yyvsp[(3) - (5)].action), ACTIONS_ST, (yyvsp[(5) - (5)].action));
			set_cfg_pos((yyval.action));
		}else
			YYERROR;
	}
    break;

  case 573:
#line 2330 "core/cfg.y"
    {
			(yyval.rv_expr)=0;
			if ((yyvsp[(1) - (1)].rv_expr) && !rve_is_constant((yyvsp[(1) - (1)].rv_expr))){
				yyerror("constant expected");
				YYERROR;
			/*
			} else if ($1 &&
						!rve_check_type((enum rval_type*)&i_tmp, $1, 0, 0 ,0)){
				yyerror("invalid expression (bad type)");
			}else if ($1 && i_tmp!=RV_INT){
				yyerror("invalid expression type, int expected\n");
			*/
			}else
				(yyval.rv_expr)=(yyvsp[(1) - (1)].rv_expr);
		}
    break;

  case 574:
#line 2347 "core/cfg.y"
    {
		(yyval.case_stms)=0;
		if ((yyvsp[(2) - (4)].rv_expr)==0) { yyerror ("bad case label"); YYERROR; }
		else if ((((yyval.case_stms)=mk_case_stm((yyvsp[(2) - (4)].rv_expr), 0, (yyvsp[(4) - (4)].action), &i_tmp))==0) && (i_tmp==-10)){
				YYABORT;
		}
	}
    break;

  case 575:
#line 2354 "core/cfg.y"
    {
		(yyval.case_stms)=0;
		if ((yyvsp[(3) - (5)].rv_expr)==0) { yyerror ("bad case label"); YYERROR; }
		else if ((((yyval.case_stms)=mk_case_stm((yyvsp[(3) - (5)].rv_expr), 1, (yyvsp[(5) - (5)].action), &i_tmp))==0) && (i_tmp==-10)){
				YYABORT;
		}
	}
    break;

  case 576:
#line 2361 "core/cfg.y"
    {
		(yyval.case_stms)=0;
		if ((yyvsp[(2) - (3)].rv_expr)==0) { yyerror ("bad case label"); YYERROR; }
		else if ((((yyval.case_stms)=mk_case_stm((yyvsp[(2) - (3)].rv_expr), 0, 0, &i_tmp))==0) && (i_tmp==-10)){
				YYABORT;
		}
	}
    break;

  case 577:
#line 2368 "core/cfg.y"
    {
		(yyval.case_stms)=0;
		if ((yyvsp[(3) - (4)].rv_expr)==0) { yyerror ("bad regex case label"); YYERROR; }
		else if ((((yyval.case_stms)=mk_case_stm((yyvsp[(3) - (4)].rv_expr), 1, 0, &i_tmp))==0) && (i_tmp==-10)){
				YYABORT;
		}
	}
    break;

  case 578:
#line 2375 "core/cfg.y"
    {
		if ((((yyval.case_stms)=mk_case_stm(0, 0, (yyvsp[(3) - (3)].action), &i_tmp))==0) && (i_tmp=-10)){
				YYABORT;
		}
	}
    break;

  case 579:
#line 2380 "core/cfg.y"
    {
		if ((((yyval.case_stms)=mk_case_stm(0, 0, 0, &i_tmp))==0) && (i_tmp==-10)){
				YYABORT;
		}
	}
    break;

  case 580:
#line 2385 "core/cfg.y"
    { (yyval.case_stms)=0; yyerror("bad case label"); }
    break;

  case 581:
#line 2386 "core/cfg.y"
    { (yyval.case_stms)=0; yyerror("bad case regex label"); }
    break;

  case 582:
#line 2387 "core/cfg.y"
    { (yyval.case_stms)=0; yyerror("bad case label"); }
    break;

  case 583:
#line 2388 "core/cfg.y"
    { (yyval.case_stms)=0; yyerror("bad case regex label"); }
    break;

  case 584:
#line 2389 "core/cfg.y"
    { (yyval.case_stms)=0; yyerror ("bad case body"); }
    break;

  case 585:
#line 2392 "core/cfg.y"
    {
		(yyval.case_stms)=(yyvsp[(1) - (2)].case_stms);
		if ((yyvsp[(2) - (2)].case_stms)==0) yyerror ("bad case");
		if ((yyval.case_stms)){
			*((yyval.case_stms)->append)=(yyvsp[(2) - (2)].case_stms);
			if (*((yyval.case_stms)->append)!=0)
				(yyval.case_stms)->append=&((*((yyval.case_stms)->append))->next);
		}
	}
    break;

  case 586:
#line 2401 "core/cfg.y"
    {
		(yyval.case_stms)=(yyvsp[(1) - (1)].case_stms);
		if ((yyvsp[(1) - (1)].case_stms)==0) yyerror ("bad case");
		else (yyval.case_stms)->append=&((yyval.case_stms)->next);
	}
    break;

  case 587:
#line 2408 "core/cfg.y"
    {
		(yyval.action)=0;
		if ((yyvsp[(2) - (5)].rv_expr)==0){
			yyerror("bad expression in switch(...)");
			YYERROR;
		}else if ((yyvsp[(4) - (5)].case_stms)==0){
			yyerror ("bad switch body");
			YYERROR;
		}else if (case_check_default((yyvsp[(4) - (5)].case_stms))!=0){
			yyerror_at(&(yyvsp[(2) - (5)].rv_expr)->fpos, "bad switch(): too many "
							"\"default:\" labels\n");
			YYERROR;
		}else if (case_check_type((yyvsp[(4) - (5)].case_stms))!=0){
			yyerror_at(&(yyvsp[(2) - (5)].rv_expr)->fpos, "bad switch(): mixed integer and"
							" string/RE cases not allowed\n");
			YYERROR;
		}else{
			(yyval.action)=mk_action(SWITCH_T, 2, RVE_ST, (yyvsp[(2) - (5)].rv_expr), CASE_ST, (yyvsp[(4) - (5)].case_stms));
			if ((yyval.action)==0) {
				yyerror("internal error");
				YYABORT;
			}
			set_cfg_pos((yyval.action));
		}
	}
    break;

  case 588:
#line 2433 "core/cfg.y"
    {
		(yyval.action)=0;
		warn("empty switch()");
		if ((yyvsp[(2) - (4)].rv_expr)==0){
			yyerror("bad expression in switch(...)");
			YYERROR;
		}else{
			/* it might have sideffects, so leave it for the optimizer */
			(yyval.action)=mk_action(SWITCH_T, 2, RVE_ST, (yyvsp[(2) - (4)].rv_expr), CASE_ST, 0);
			if ((yyval.action)==0) {
				yyerror("internal error");
				YYABORT;
			}
			set_cfg_pos((yyval.action));
		}
	}
    break;

  case 589:
#line 2449 "core/cfg.y"
    { (yyval.action)=0; yyerror ("bad expression in switch(...)"); }
    break;

  case 590:
#line 2451 "core/cfg.y"
    {(yyval.action)=0; yyerror ("bad switch body"); }
    break;

  case 591:
#line 2455 "core/cfg.y"
    {
		if ((yyvsp[(2) - (3)].rv_expr) && rval_expr_int_check((yyvsp[(2) - (3)].rv_expr))>=0){
			warn_ct_rve((yyvsp[(2) - (3)].rv_expr), "while");
			(yyval.action)=mk_action( WHILE_T, 2, RVE_ST, (yyvsp[(2) - (3)].rv_expr), ACTIONS_ST, (yyvsp[(3) - (3)].action));
			set_cfg_pos((yyval.action));
		}else{
			yyerror_at(&(yyvsp[(2) - (3)].rv_expr)->fpos, "bad while(...) expression");
			YYERROR;
		}
	}
    break;

  case 592:
#line 2474 "core/cfg.y"
    {
		if (sel.n >= MAX_SELECT_PARAMS-1) {
			yyerror("Select identifier too long\n");
		}
		sel.params[sel.n].type = SEL_PARAM_STR;
		sel.params[sel.n].v.s.s = (yyvsp[(1) - (1)].strval);
		sel.params[sel.n].v.s.len = strlen((yyvsp[(1) - (1)].strval));
		sel.n++;
	}
    break;

  case 593:
#line 2483 "core/cfg.y"
    {
		if (sel.n >= MAX_SELECT_PARAMS-2) {
			yyerror("Select identifier too long\n");
		}
		sel.params[sel.n].type = SEL_PARAM_STR;
		sel.params[sel.n].v.s.s = (yyvsp[(1) - (4)].strval);
		sel.params[sel.n].v.s.len = strlen((yyvsp[(1) - (4)].strval));
		sel.n++;
		sel.params[sel.n].type = SEL_PARAM_INT;
		sel.params[sel.n].v.i = (yyvsp[(3) - (4)].intval);
		sel.n++;
	}
    break;

  case 594:
#line 2495 "core/cfg.y"
    {
		if (sel.n >= MAX_SELECT_PARAMS-2) {
			yyerror("Select identifier too long\n");
		}
		sel.params[sel.n].type = SEL_PARAM_STR;
		sel.params[sel.n].v.s.s = (yyvsp[(1) - (4)].strval);
		sel.params[sel.n].v.s.len = strlen((yyvsp[(1) - (4)].strval));
		sel.n++;
		sel.params[sel.n].type = SEL_PARAM_STR;
		sel.params[sel.n].v.s.s = (yyvsp[(3) - (4)].strval);
		sel.params[sel.n].v.s.len = strlen((yyvsp[(3) - (4)].strval));
		sel.n++;
	}
    break;

  case 597:
#line 2514 "core/cfg.y"
    { sel.n = 0; sel.f[0] = 0; }
    break;

  case 598:
#line 2514 "core/cfg.y"
    {
		sel_ptr = (select_t*)pkg_malloc(sizeof(select_t));
		if (!sel_ptr) {
			yyerror("No memory left to allocate select structure\n");
		}
		memcpy(sel_ptr, &sel, sizeof(select_t));
		(yyval.select) = sel_ptr;
	}
    break;

  case 599:
#line 2524 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_FROM; }
    break;

  case 600:
#line 2525 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_TO; }
    break;

  case 601:
#line 2526 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_FROM | AVP_CLASS_URI; }
    break;

  case 602:
#line 2527 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_TO | AVP_CLASS_URI; }
    break;

  case 603:
#line 2528 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_FROM | AVP_CLASS_USER; }
    break;

  case 604:
#line 2529 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_TO | AVP_CLASS_USER; }
    break;

  case 605:
#line 2530 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_FROM | AVP_CLASS_DOMAIN; }
    break;

  case 606:
#line 2531 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_TO | AVP_CLASS_DOMAIN; }
    break;

  case 607:
#line 2532 "core/cfg.y"
    { s_attr->type |= AVP_TRACK_ALL | AVP_CLASS_GLOBAL; }
    break;

  case 608:
#line 2535 "core/cfg.y"
    { s_attr->type |= AVP_NAME_STR; s_attr->name.s.s = (yyvsp[(1) - (1)].strval); s_attr->name.s.len = strlen ((yyvsp[(1) - (1)].strval)); }
    break;

  case 611:
#line 2542 "core/cfg.y"
    {
		s_attr = (struct avp_spec*)pkg_malloc(sizeof(struct avp_spec));
		if (!s_attr) { yyerror("No memory left"); YYABORT; }
		else s_attr->type = 0;
	}
    break;

  case 612:
#line 2549 "core/cfg.y"
    { (yyval.attr) = s_attr; }
    break;

  case 613:
#line 2552 "core/cfg.y"
    {
		s_attr->type|= (AVP_NAME_STR | ((yyvsp[(4) - (5)].intval)<0?AVP_INDEX_BACKWARD:AVP_INDEX_FORWARD));
		s_attr->index = ((yyvsp[(4) - (5)].intval)<0?-(yyvsp[(4) - (5)].intval):(yyvsp[(4) - (5)].intval));
		(yyval.attr) = s_attr;
	}
    break;

  case 614:
#line 2559 "core/cfg.y"
    {
		s_attr->type|= AVP_INDEX_ALL;
		(yyval.attr) = s_attr;
	}
    break;

  case 621:
#line 2581 "core/cfg.y"
    {
		if ((yyvsp[(1) - (1)].lval)->type==LV_AVP){
			s_attr = pkg_malloc(sizeof(struct avp_spec));
			if (!s_attr) { yyerror("No memory left"); YYABORT; }
			else{
				*s_attr=(yyvsp[(1) - (1)].lval)->lv.avps;
			}
			(yyval.attr)=s_attr;
		}else
			(yyval.attr)=0; /* not an avp, a pvar */
		pkg_free((yyvsp[(1) - (1)].lval));
	}
    break;

  case 622:
#line 2593 "core/cfg.y"
    {
		avp_spec_t *avp_spec;
		str s;
		int type, idx;
		avp_spec = pkg_malloc(sizeof(*avp_spec));
		if (!avp_spec) {
			yyerror("Not enough memory");
			YYABORT;
		}
		s.s = (yyvsp[(1) - (1)].strval);
		if (s.s[0] == '$')
			s.s++;
		s.len = strlen(s.s);
		if (parse_avp_name(&s, &type, &avp_spec->name, &idx)) {
			yyerror("error when parsing AVP");
			pkg_free(avp_spec);
			YYABORT;
		}
		avp_spec->type = type;
		avp_spec->index = idx;
		(yyval.attr) = avp_spec;
	}
    break;

  case 623:
#line 2617 "core/cfg.y"
    {
			s_tmp.s=(yyvsp[(1) - (1)].strval); s_tmp.len=strlen((yyvsp[(1) - (1)].strval));
			pv_spec=pv_cache_get(&s_tmp);
			if (!pv_spec) {
				yyerror("Can't get from cache: %s", (yyvsp[(1) - (1)].strval));
				YYABORT;
			}
			(yyval.pvar)=pv_spec;
		}
    break;

  case 624:
#line 2628 "core/cfg.y"
    {
				lval_tmp=pkg_malloc(sizeof(*lval_tmp));
				if (!lval_tmp) {
					yyerror("Not enough memory");
					YYABORT;
				}
				memset(lval_tmp, 0, sizeof(*lval_tmp));
				s_tmp.s=(yyvsp[(1) - (1)].strval); s_tmp.len=strlen(s_tmp.s);
				lval_tmp->lv.pvs = pv_cache_get(&s_tmp);
				if (lval_tmp->lv.pvs==NULL){
					lval_tmp->lv.avps.type|= AVP_NAME_STR;
					lval_tmp->lv.avps.name.s.s = s_tmp.s+1;
					lval_tmp->lv.avps.name.s.len = s_tmp.len-1;
					lval_tmp->type=LV_AVP;
				}else{
					lval_tmp->type=LV_PVAR;
				}
				(yyval.lval) = lval_tmp;
				DBG("parsed ambiguous avp/pvar \"%.*s\" to %d\n",
							s_tmp.len, s_tmp.s, lval_tmp->type);
			}
    break;

  case 625:
#line 2659 "core/cfg.y"
    { (yyval.intval) = ASSIGN_T; }
    break;

  case 626:
#line 2663 "core/cfg.y"
    {
					lval_tmp=pkg_malloc(sizeof(*lval_tmp));
					if (!lval_tmp) {
						yyerror("Not enough memory");
						YYABORT;
					}
					lval_tmp->type=LV_AVP; lval_tmp->lv.avps=*(yyvsp[(1) - (1)].attr);
					pkg_free((yyvsp[(1) - (1)].attr)); /* free the avp spec we just copied */
					(yyval.lval)=lval_tmp;
				}
    break;

  case 627:
#line 2673 "core/cfg.y"
    {
					if (!pv_is_w((yyvsp[(1) - (1)].pvar)))
						yyerror("read only pvar in assignment left side");
					if ((yyvsp[(1) - (1)].pvar)->trans!=0)
						yyerror("pvar with transformations in assignment"
								" left side");
					lval_tmp=pkg_malloc(sizeof(*lval_tmp));
					if (!lval_tmp) {
						yyerror("Not enough memory");
						YYABORT;
					}
					lval_tmp->type=LV_PVAR; lval_tmp->lv.pvs=(yyvsp[(1) - (1)].pvar);
					(yyval.lval)=lval_tmp;
				}
    break;

  case 628:
#line 2687 "core/cfg.y"
    {
					if (((yyvsp[(1) - (1)].lval))->type==LV_PVAR){
						if (!pv_is_w((yyvsp[(1) - (1)].lval)->lv.pvs))
							yyerror("read only pvar in assignment left side");
						if ((yyvsp[(1) - (1)].lval)->lv.pvs->trans!=0)
							yyerror("pvar with transformations in assignment"
									" left side");
					}
					(yyval.lval)=(yyvsp[(1) - (1)].lval);
				}
    break;

  case 629:
#line 2699 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve_rval(RV_INT, (void*)(yyvsp[(1) - (1)].intval)); }
    break;

  case 630:
#line 2700 "core/cfg.y"
    {	s_tmp.s=(yyvsp[(1) - (1)].strval); s_tmp.len=strlen((yyvsp[(1) - (1)].strval));
							(yyval.rv_expr)=mk_rve_rval(RV_STR, &s_tmp); }
    break;

  case 631:
#line 2702 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve_rval(RV_AVP, (yyvsp[(1) - (1)].attr)); pkg_free((yyvsp[(1) - (1)].attr)); }
    break;

  case 632:
#line 2703 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve_rval(RV_PVAR, (yyvsp[(1) - (1)].pvar)); }
    break;

  case 633:
#line 2704 "core/cfg.y"
    {
							switch((yyvsp[(1) - (1)].lval)->type){
								case LV_AVP:
									(yyval.rv_expr)=mk_rve_rval(RV_AVP, &(yyvsp[(1) - (1)].lval)->lv.avps);
									break;
								case LV_PVAR:
									(yyval.rv_expr)=mk_rve_rval(RV_PVAR, (yyvsp[(1) - (1)].lval)->lv.pvs);
									break;
								default:
									yyerror("BUG: invalid lvalue type ");
									YYABORT;
							}
							pkg_free((yyvsp[(1) - (1)].lval)); /* not needed anymore */
						}
    break;

  case 634:
#line 2718 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve_rval(RV_SEL, (yyvsp[(1) - (1)].select)); pkg_free((yyvsp[(1) - (1)].select)); }
    break;

  case 635:
#line 2719 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve_rval(RV_ACTION_ST, (yyvsp[(1) - (1)].action)); }
    break;

  case 636:
#line 2720 "core/cfg.y"
    { (yyval.rv_expr)=mk_rve_rval(RV_BEXPR, (yyvsp[(1) - (1)].expr)); }
    break;

  case 637:
#line 2721 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve_rval(RV_ACTION_ST, (yyvsp[(2) - (3)].action)); }
    break;

  case 638:
#line 2722 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad command block"); }
    break;

  case 639:
#line 2723 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve_rval(RV_ACTION_ST, (yyvsp[(2) - (3)].action)); }
    break;

  case 640:
#line 2724 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 641:
#line 2728 "core/cfg.y"
    { (yyval.intval)=RVE_LNOT_OP; }
    break;

  case 642:
#line 2729 "core/cfg.y"
    { (yyval.intval)=RVE_BNOT_OP; }
    break;

  case 643:
#line 2730 "core/cfg.y"
    { (yyval.intval)=RVE_UMINUS_OP; }
    break;

  case 644:
#line 2743 "core/cfg.y"
    { (yyval.rv_expr)=(yyvsp[(1) - (1)].rv_expr);
										if ((yyval.rv_expr)==0){
											/*yyerror("out of memory\n");*/
											YYERROR;
										}
									}
    break;

  case 645:
#line 2749 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve1((yyvsp[(1) - (2)].intval), (yyvsp[(2) - (2)].rv_expr)); }
    break;

  case 646:
#line 2750 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve1(RVE_INT_OP, (yyvsp[(2) - (2)].rv_expr)); }
    break;

  case 647:
#line 2751 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve1(RVE_STR_OP, (yyvsp[(2) - (2)].rv_expr)); }
    break;

  case 648:
#line 2752 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_PLUS_OP, (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr)); }
    break;

  case 649:
#line 2753 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_MINUS_OP, (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr)); }
    break;

  case 650:
#line 2754 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_MUL_OP, (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr)); }
    break;

  case 651:
#line 2755 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_DIV_OP, (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr)); }
    break;

  case 652:
#line 2756 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_MOD_OP, (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr)); }
    break;

  case 653:
#line 2757 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_BOR_OP, (yyvsp[(1) - (3)].rv_expr),  (yyvsp[(3) - (3)].rv_expr)); }
    break;

  case 654:
#line 2758 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_BAND_OP, (yyvsp[(1) - (3)].rv_expr),  (yyvsp[(3) - (3)].rv_expr));}
    break;

  case 655:
#line 2759 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_BXOR_OP, (yyvsp[(1) - (3)].rv_expr),  (yyvsp[(3) - (3)].rv_expr));}
    break;

  case 656:
#line 2760 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_BLSHIFT_OP, (yyvsp[(1) - (3)].rv_expr),  (yyvsp[(3) - (3)].rv_expr));}
    break;

  case 657:
#line 2761 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve2(RVE_BRSHIFT_OP, (yyvsp[(1) - (3)].rv_expr),  (yyvsp[(3) - (3)].rv_expr));}
    break;

  case 658:
#line 2762 "core/cfg.y"
    { (yyval.rv_expr)=mk_rve2( (yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr));}
    break;

  case 659:
#line 2763 "core/cfg.y"
    {
			/* comparing with $null => treat as defined or !defined */
			if((yyvsp[(3) - (3)].rv_expr)->op==RVE_RVAL_OP && (yyvsp[(3) - (3)].rv_expr)->left.rval.type==RV_PVAR
					&& (yyvsp[(3) - (3)].rv_expr)->left.rval.v.pvs.type==PVT_NULL) {
				if((yyvsp[(2) - (3)].intval)==RVE_DIFF_OP || (yyvsp[(2) - (3)].intval)==RVE_IDIFF_OP
						|| (yyvsp[(2) - (3)].intval)==RVE_STRDIFF_OP) {
					DBG("comparison with $null switched to notdefined operator\n");
					(yyval.rv_expr)=mk_rve1(RVE_DEFINED_OP, (yyvsp[(1) - (3)].rv_expr));
				} else {
					DBG("comparison with $null switched to defined operator\n");
					(yyval.rv_expr)=mk_rve1(RVE_NOTDEFINED_OP, (yyvsp[(1) - (3)].rv_expr));
				}
				/* free rve struct for $null */
				rve_destroy((yyvsp[(3) - (3)].rv_expr));
			} else {
				(yyval.rv_expr)=mk_rve2((yyvsp[(2) - (3)].intval), (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr));
			}
		}
    break;

  case 660:
#line 2781 "core/cfg.y"
    { (yyval.rv_expr)=mk_rve2(RVE_LAND_OP, (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr));}
    break;

  case 661:
#line 2782 "core/cfg.y"
    { (yyval.rv_expr)=mk_rve2(RVE_LOR_OP, (yyvsp[(1) - (3)].rv_expr), (yyvsp[(3) - (3)].rv_expr));}
    break;

  case 662:
#line 2783 "core/cfg.y"
    { (yyval.rv_expr)=(yyvsp[(2) - (3)].rv_expr);}
    break;

  case 663:
#line 2784 "core/cfg.y"
    { (yyval.rv_expr)=mk_rve1(RVE_STRLEN_OP, (yyvsp[(3) - (4)].rv_expr));}
    break;

  case 664:
#line 2785 "core/cfg.y"
    {(yyval.rv_expr)=mk_rve1(RVE_STREMPTY_OP, (yyvsp[(3) - (4)].rv_expr));}
    break;

  case 665:
#line 2786 "core/cfg.y"
    { (yyval.rv_expr)=mk_rve1(RVE_DEFINED_OP, (yyvsp[(2) - (2)].rv_expr));}
    break;

  case 666:
#line 2787 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 667:
#line 2788 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 668:
#line 2789 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 669:
#line 2790 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 670:
#line 2791 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 671:
#line 2792 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 672:
#line 2793 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 673:
#line 2794 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 674:
#line 2795 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 675:
#line 2796 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 676:
#line 2798 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 677:
#line 2800 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 678:
#line 2801 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 679:
#line 2802 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 680:
#line 2803 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 681:
#line 2804 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 682:
#line 2805 "core/cfg.y"
    { (yyval.rv_expr)=0; yyerror("bad expression"); }
    break;

  case 683:
#line 2808 "core/cfg.y"
    { (yyval.action)=mk_action((yyvsp[(2) - (3)].intval), 2, LVAL_ST, (yyvsp[(1) - (3)].lval),
														 	  RVE_ST, (yyvsp[(3) - (3)].rv_expr));
											set_cfg_pos((yyval.action));
										}
    break;

  case 684:
#line 2826 "core/cfg.y"
    { (yyval.intval) = 1; }
    break;

  case 685:
#line 2827 "core/cfg.y"
    { (yyval.intval) = 0; }
    break;

  case 686:
#line 2828 "core/cfg.y"
    { (yyval.intval) = -1; }
    break;

  case 687:
#line 2831 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_T, 2, URIHOST_ST, 0, URIPORT_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 688:
#line 2832 "core/cfg.y"
    { (yyval.action)=mk_action(	FORWARD_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 689:
#line 2833 "core/cfg.y"
    { (yyval.action)=mk_action(	FORWARD_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 690:
#line 2834 "core/cfg.y"
    { (yyval.action)=mk_action(	FORWARD_T, 2, IP_ST, (void*)(yyvsp[(3) - (4)].ipaddr), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 691:
#line 2835 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 692:
#line 2836 "core/cfg.y"
    {(yyval.action)=mk_action(FORWARD_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 693:
#line 2837 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_T, 2, IP_ST, (void*)(yyvsp[(3) - (6)].ipaddr), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 694:
#line 2838 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_T, 2, URIHOST_ST, 0, URIPORT_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 695:
#line 2839 "core/cfg.y"
    {(yyval.action)=mk_action(FORWARD_T, 2, URIHOST_ST, 0, NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 696:
#line 2840 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_T, 2, URIHOST_ST, 0, NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 697:
#line 2841 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 698:
#line 2842 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad forward argument"); }
    break;

  case 699:
#line 2843 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_UDP_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 700:
#line 2844 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_UDP_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 701:
#line 2845 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_UDP_T, 2, IP_ST, (void*)(yyvsp[(3) - (4)].ipaddr), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 702:
#line 2846 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_UDP_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 703:
#line 2847 "core/cfg.y"
    {(yyval.action)=mk_action(FORWARD_UDP_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 704:
#line 2848 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_UDP_T, 2, IP_ST, (void*)(yyvsp[(3) - (6)].ipaddr), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 705:
#line 2849 "core/cfg.y"
    {(yyval.action)=mk_action(FORWARD_UDP_T, 2, URIHOST_ST, 0, URIPORT_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 706:
#line 2850 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_UDP_T, 2, URIHOST_ST, 0, NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 707:
#line 2851 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_UDP_T, 2, URIHOST_ST, 0, NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 708:
#line 2852 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 709:
#line 2853 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad forward_udp argument"); }
    break;

  case 710:
#line 2854 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_TCP_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 711:
#line 2855 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_TCP_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 712:
#line 2856 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_TCP_T, 2, IP_ST, (void*)(yyvsp[(3) - (4)].ipaddr), NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 713:
#line 2857 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_TCP_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 714:
#line 2858 "core/cfg.y"
    {(yyval.action)=mk_action(FORWARD_TCP_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 715:
#line 2859 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_TCP_T, 2, IP_ST, (void*)(yyvsp[(3) - (6)].ipaddr), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 716:
#line 2860 "core/cfg.y"
    {(yyval.action)=mk_action(FORWARD_TCP_T, 2, URIHOST_ST, 0, URIPORT_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 717:
#line 2861 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_TCP_T, 2, URIHOST_ST, 0, NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 718:
#line 2862 "core/cfg.y"
    { (yyval.action)=mk_action(FORWARD_TCP_T, 2, URIHOST_ST, 0, NUMBER_ST, 0); set_cfg_pos((yyval.action)); }
    break;

  case 719:
#line 2863 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 720:
#line 2864 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad forward_tcp argument"); }
    break;

  case 721:
#line 2865 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 722:
#line 2873 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 723:
#line 2881 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, IP_ST, (void*)(yyvsp[(3) - (4)].ipaddr), NUMBER_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 724:
#line 2889 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 725:
#line 2897 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 726:
#line 2905 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, IP_ST, (void*)(yyvsp[(3) - (6)].ipaddr), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
					}
    break;

  case 727:
#line 2913 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, URIHOST_ST, 0, URIPORT_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 728:
#line 2921 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, URIHOST_ST, 0, NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 729:
#line 2929 "core/cfg.y"
    {
		#ifdef USE_TLS
			(yyval.action)=mk_action(FORWARD_TLS_T, 2, URIHOST_ST, 0, NUMBER_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 730:
#line 2937 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 731:
#line 2938 "core/cfg.y"
    { (yyval.action)=0;
									yyerror("bad forward_tls argument"); }
    break;

  case 732:
#line 2940 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("sctp support not compiled in");
		#endif
	}
    break;

  case 733:
#line 2948 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, STRING_ST, (yyvsp[(3) - (4)].strval), NUMBER_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("sctp support not compiled in");
		#endif
	}
    break;

  case 734:
#line 2956 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, IP_ST, (void*)(yyvsp[(3) - (4)].ipaddr), NUMBER_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("sctp support not compiled in");
		#endif
	}
    break;

  case 735:
#line 2964 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST,
							(void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("sctp support not compiled in");
		#endif
	}
    break;

  case 736:
#line 2973 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST,
							(void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("sctp support not compiled in");
		#endif
	}
    break;

  case 737:
#line 2982 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, IP_ST, (void*)(yyvsp[(3) - (6)].ipaddr), NUMBER_ST,
							(void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("sctp support not compiled in");
		#endif
					}
    break;

  case 738:
#line 2991 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, URIHOST_ST, 0, URIPORT_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("sctp support not compiled in");
		#endif
	}
    break;

  case 739:
#line 2999 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, URIHOST_ST, 0, NUMBER_ST,
							(void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("sctp support not compiled in");
		#endif
	}
    break;

  case 740:
#line 3008 "core/cfg.y"
    {
		#ifdef USE_SCTP
			(yyval.action)=mk_action(FORWARD_SCTP_T, 2, URIHOST_ST, 0, NUMBER_ST, 0); set_cfg_pos((yyval.action));
		#else
			(yyval.action)=0;
			yyerror("tls support not compiled in");
		#endif
	}
    break;

  case 741:
#line 3016 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 742:
#line 3017 "core/cfg.y"
    { (yyval.action)=0;
									yyerror("bad forward_sctp argument"); }
    break;

  case 743:
#line 3019 "core/cfg.y"
    {(yyval.action)=mk_action(LOG_T, 2, NUMBER_ST,
										(void*)(L_DBG+1), STRING_ST, (yyvsp[(3) - (4)].strval));
									set_cfg_pos((yyval.action)); }
    break;

  case 744:
#line 3022 "core/cfg.y"
    {(yyval.action)=mk_action(LOG_T, 2, NUMBER_ST, (void*)(yyvsp[(3) - (6)].intval), STRING_ST, (yyvsp[(5) - (6)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 745:
#line 3023 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 746:
#line 3024 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad log argument"); }
    break;

  case 747:
#line 3025 "core/cfg.y"
    {
							if (check_flag((yyvsp[(3) - (4)].intval))==-1)
								yyerror("bad flag value");
							(yyval.action)=mk_action(SETFLAG_T, 1, NUMBER_ST,
													(void*)(yyvsp[(3) - (4)].intval));
							set_cfg_pos((yyval.action));
									}
    break;

  case 748:
#line 3032 "core/cfg.y"
    {
							i_tmp=get_flag_no((yyvsp[(3) - (4)].strval), strlen((yyvsp[(3) - (4)].strval)));
							if (i_tmp<0) yyerror("flag not declared");
							(yyval.action)=mk_action(SETFLAG_T, 1, NUMBER_ST,
										(void*)(long)i_tmp);
							set_cfg_pos((yyval.action));
									}
    break;

  case 749:
#line 3039 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); }
    break;

  case 750:
#line 3040 "core/cfg.y"
    {
							if (check_flag((yyvsp[(3) - (4)].intval))==-1)
								yyerror("bad flag value");
							(yyval.action)=mk_action(RESETFLAG_T, 1, NUMBER_ST, (void*)(yyvsp[(3) - (4)].intval));
							set_cfg_pos((yyval.action));
									}
    break;

  case 751:
#line 3046 "core/cfg.y"
    {
							i_tmp=get_flag_no((yyvsp[(3) - (4)].strval), strlen((yyvsp[(3) - (4)].strval)));
							if (i_tmp<0) yyerror("flag not declared");
							(yyval.action)=mk_action(RESETFLAG_T, 1, NUMBER_ST,
										(void*)(long)i_tmp);
							set_cfg_pos((yyval.action));
									}
    break;

  case 752:
#line 3053 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); }
    break;

  case 753:
#line 3054 "core/cfg.y"
    {
							if (check_flag((yyvsp[(3) - (4)].intval))==-1)
								yyerror("bad flag value");
							(yyval.action)=mk_action(ISFLAGSET_T, 1, NUMBER_ST, (void*)(yyvsp[(3) - (4)].intval));
							set_cfg_pos((yyval.action));
									}
    break;

  case 754:
#line 3060 "core/cfg.y"
    {
							i_tmp=get_flag_no((yyvsp[(3) - (4)].strval), strlen((yyvsp[(3) - (4)].strval)));
							if (i_tmp<0) yyerror("flag not declared");
							(yyval.action)=mk_action(ISFLAGSET_T, 1, NUMBER_ST,
										(void*)(long)i_tmp);
							set_cfg_pos((yyval.action));
									}
    break;

  case 755:
#line 3067 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); }
    break;

  case 756:
#line 3068 "core/cfg.y"
    {
		i_tmp=get_avpflag_no((yyvsp[(5) - (6)].strval));
		if (i_tmp==0) yyerror("avpflag not declared");
		(yyval.action)=mk_action(AVPFLAG_OPER_T, 3, AVP_ST, (yyvsp[(3) - (6)].attr), NUMBER_ST, (void*)(long)i_tmp, NUMBER_ST, (void*)(yyvsp[(1) - (6)].intval));
		set_cfg_pos((yyval.action));
	}
    break;

  case 757:
#line 3074 "core/cfg.y"
    {
		(yyval.action)=0; yyerror("error parsing flag name");
	}
    break;

  case 758:
#line 3077 "core/cfg.y"
    {
		(yyval.action)=0; yyerror("error parsing first parameter (avp or string)");
	}
    break;

  case 759:
#line 3080 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad parameters"); }
    break;

  case 760:
#line 3081 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')'?"); }
    break;

  case 761:
#line 3082 "core/cfg.y"
    {(yyval.action)=mk_action(ERROR_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), STRING_ST, (yyvsp[(5) - (6)].strval));
			set_cfg_pos((yyval.action));
	}
    break;

  case 762:
#line 3085 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 763:
#line 3086 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad error argument"); }
    break;

  case 764:
#line 3087 "core/cfg.y"
    {
		if ((yyvsp[(3) - (4)].rv_expr)) {
			(yyval.action) = mk_action(ROUTE_T, 1, RVE_ST, (void*)(yyvsp[(3) - (4)].rv_expr));
			set_cfg_pos((yyval.action));
		} else {
			(yyval.action) = 0;
			YYERROR;
		}
	}
    break;

  case 765:
#line 3096 "core/cfg.y"
    {
		if ((yyvsp[(3) - (4)].strval)) {
			(yyval.action) = mk_action(ROUTE_T, 1, STRING_ST, (void*)(yyvsp[(3) - (4)].strval));
			set_cfg_pos((yyval.action));
		} else {
			(yyval.action) = 0;
			YYERROR;
		}
	}
    break;

  case 766:
#line 3105 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 767:
#line 3106 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad route argument"); }
    break;

  case 768:
#line 3107 "core/cfg.y"
    { (yyval.action)=mk_action(EXEC_T, 1, STRING_ST, (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 769:
#line 3108 "core/cfg.y"
    { (yyval.action)=mk_action(SET_HOST_T, 1, STRING_ST, (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 770:
#line 3109 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 771:
#line 3110 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 772:
#line 3111 "core/cfg.y"
    { (yyval.action)=mk_action(PREFIX_T, 1, STRING_ST,  (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 773:
#line 3112 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 774:
#line 3113 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 775:
#line 3114 "core/cfg.y"
    { (yyval.action)=mk_action(STRIP_TAIL_T, 1, NUMBER_ST, (void*)(yyvsp[(3) - (4)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 776:
#line 3115 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 777:
#line 3116 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, number expected"); }
    break;

  case 778:
#line 3117 "core/cfg.y"
    { (yyval.action)=mk_action(STRIP_T, 1, NUMBER_ST, (void*) (yyvsp[(3) - (4)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 779:
#line 3118 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 780:
#line 3119 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, number expected"); }
    break;

  case 781:
#line 3120 "core/cfg.y"
    { (yyval.action)=mk_action(SET_USERPHONE_T, 0); set_cfg_pos((yyval.action)); }
    break;

  case 782:
#line 3121 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 783:
#line 3122 "core/cfg.y"
    {
			(yyval.action)=mk_action(REMOVE_BRANCH_T, 1, NUMBER_ST, (void*)(yyvsp[(3) - (4)].intval));
			set_cfg_pos((yyval.action));
	}
    break;

  case 784:
#line 3126 "core/cfg.y"
    {
			(yyval.action)=mk_action(REMOVE_BRANCH_T, 0);
			set_cfg_pos((yyval.action));
	}
    break;

  case 785:
#line 3130 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 786:
#line 3131 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, number expected"); }
    break;

  case 787:
#line 3132 "core/cfg.y"
    { (yyval.action)=mk_action(CLEAR_BRANCHES_T, 0); set_cfg_pos((yyval.action)); }
    break;

  case 788:
#line 3133 "core/cfg.y"
    { (yyval.action)=mk_action(SET_HOSTPORT_T, 1, STRING_ST, (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 789:
#line 3134 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 790:
#line 3135 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 791:
#line 3136 "core/cfg.y"
    { (yyval.action)=mk_action(SET_HOSTPORTTRANS_T, 1, STRING_ST, (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 792:
#line 3137 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 793:
#line 3138 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 794:
#line 3139 "core/cfg.y"
    { (yyval.action)=mk_action(SET_PORT_T, 1, STRING_ST, (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 795:
#line 3140 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 796:
#line 3141 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 797:
#line 3142 "core/cfg.y"
    { (yyval.action)=mk_action(SET_USER_T, 1, STRING_ST, (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 798:
#line 3143 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 799:
#line 3144 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 800:
#line 3145 "core/cfg.y"
    { (yyval.action)=mk_action(SET_USERPASS_T, 1, STRING_ST, (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 801:
#line 3146 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 802:
#line 3147 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 803:
#line 3148 "core/cfg.y"
    { (yyval.action)=mk_action(SET_URI_T, 1, STRING_ST,(yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action)); }
    break;

  case 804:
#line 3149 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 805:
#line 3150 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 806:
#line 3151 "core/cfg.y"
    { (yyval.action)=mk_action(REVERT_URI_T, 0); set_cfg_pos((yyval.action)); }
    break;

  case 807:
#line 3152 "core/cfg.y"
    { (yyval.action)=mk_action(REVERT_URI_T, 0); set_cfg_pos((yyval.action)); }
    break;

  case 808:
#line 3153 "core/cfg.y"
    { (yyval.action)=mk_action(FORCE_RPORT_T, 0); set_cfg_pos((yyval.action)); }
    break;

  case 809:
#line 3154 "core/cfg.y"
    {(yyval.action)=mk_action(FORCE_RPORT_T, 0); set_cfg_pos((yyval.action)); }
    break;

  case 810:
#line 3155 "core/cfg.y"
    { (yyval.action)=mk_action(ADD_LOCAL_RPORT_T, 0); set_cfg_pos((yyval.action)); }
    break;

  case 811:
#line 3156 "core/cfg.y"
    {(yyval.action)=mk_action(ADD_LOCAL_RPORT_T, 0); set_cfg_pos((yyval.action)); }
    break;

  case 812:
#line 3157 "core/cfg.y"
    {
		#ifdef USE_TCP
			(yyval.action)=mk_action(FORCE_TCP_ALIAS_T, 1, NUMBER_ST, (void*)(yyvsp[(3) - (4)].intval));
			set_cfg_pos((yyval.action));
		#else
			yyerror("tcp support not compiled in");
		#endif
	}
    break;

  case 813:
#line 3165 "core/cfg.y"
    {
		#ifdef USE_TCP
			(yyval.action)=mk_action(FORCE_TCP_ALIAS_T, 0);
			set_cfg_pos((yyval.action));
		#else
			yyerror("tcp support not compiled in");
		#endif
	}
    break;

  case 814:
#line 3173 "core/cfg.y"
    {
		#ifdef USE_TCP
			(yyval.action)=mk_action(FORCE_TCP_ALIAS_T, 0);
			set_cfg_pos((yyval.action));
		#else
			yyerror("tcp support not compiled in");
		#endif
	}
    break;

  case 815:
#line 3181 "core/cfg.y"
    {(yyval.action)=0; yyerror("bad argument, number expected"); }
    break;

  case 816:
#line 3183 "core/cfg.y"
    { (yyval.action)=mk_action(UDP_MTU_TRY_PROTO_T, 1, NUMBER_ST, (yyvsp[(3) - (4)].intval)); set_cfg_pos((yyval.action)); }
    break;

  case 817:
#line 3185 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, UDP, TCP, TLS or SCTP expected"); }
    break;

  case 818:
#line 3186 "core/cfg.y"
    {
		(yyval.action)=0;
		if ((str_tmp=pkg_malloc(sizeof(str)))==0) {
			LM_CRIT("cfg. parser: out of memory.\n");
		} else {
			str_tmp->s=(yyvsp[(3) - (4)].strval);
			str_tmp->len=(yyvsp[(3) - (4)].strval)?strlen((yyvsp[(3) - (4)].strval)):0;
			(yyval.action)=mk_action(SET_ADV_ADDR_T, 1, STR_ST, str_tmp);
			set_cfg_pos((yyval.action));
		}
	}
    break;

  case 819:
#line 3197 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 820:
#line 3198 "core/cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 821:
#line 3199 "core/cfg.y"
    {
		(yyval.action)=0;
		tmp=int2str((yyvsp[(3) - (4)].intval), &i_tmp);
		if ((str_tmp=pkg_malloc(sizeof(str)))==0) {
			LM_CRIT("cfg. parser: out of memory.\n");
		} else {
			if ((str_tmp->s=pkg_malloc(i_tmp))==0) {
				LM_CRIT("cfg. parser: out of memory.\n");
			} else {
				memcpy(str_tmp->s, tmp, i_tmp);
				str_tmp->len=i_tmp;
				(yyval.action)=mk_action(SET_ADV_PORT_T, 1, STR_ST, str_tmp);
				set_cfg_pos((yyval.action));
			}
		}
	}
    break;

  case 822:
#line 3215 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad argument, string expected"); }
    break;

  case 823:
#line 3216 "core/cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 824:
#line 3217 "core/cfg.y"
    {
		(yyval.action)=mk_action(FORCE_SEND_SOCKET_T, 1, SOCKID_ST, (yyvsp[(3) - (4)].sockid));
		set_cfg_pos((yyval.action));
	}
    break;

  case 825:
#line 3221 "core/cfg.y"
    {
		(yyval.action)=0; yyerror("bad argument, [proto:]host[:port] expected");
	}
    break;

  case 826:
#line 3224 "core/cfg.y"
    {(yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 827:
#line 3225 "core/cfg.y"
    {
		(yyval.action)=mk_action(SET_FWD_NO_CONNECT_T, 0); set_cfg_pos((yyval.action));
	}
    break;

  case 828:
#line 3228 "core/cfg.y"
    {
		(yyval.action)=mk_action(SET_FWD_NO_CONNECT_T, 0); set_cfg_pos((yyval.action));
	}
    break;

  case 829:
#line 3231 "core/cfg.y"
    {
		(yyval.action)=mk_action(SET_RPL_NO_CONNECT_T, 0); set_cfg_pos((yyval.action));
	}
    break;

  case 830:
#line 3234 "core/cfg.y"
    {
		(yyval.action)=mk_action(SET_RPL_NO_CONNECT_T, 0); set_cfg_pos((yyval.action));
	}
    break;

  case 831:
#line 3237 "core/cfg.y"
    {
		(yyval.action)=mk_action(SET_FWD_CLOSE_T, 0); set_cfg_pos((yyval.action));
	}
    break;

  case 832:
#line 3240 "core/cfg.y"
    {
		(yyval.action)=mk_action(SET_FWD_CLOSE_T, 0); set_cfg_pos((yyval.action));
	}
    break;

  case 833:
#line 3243 "core/cfg.y"
    {
		(yyval.action)=mk_action(SET_RPL_CLOSE_T, 0); set_cfg_pos((yyval.action));
	}
    break;

  case 834:
#line 3246 "core/cfg.y"
    {
		(yyval.action)=mk_action(SET_RPL_CLOSE_T, 0); set_cfg_pos((yyval.action));
	}
    break;

  case 835:
#line 3249 "core/cfg.y"
    {
		(yyval.action)=mk_action(CFG_SELECT_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), NUMBER_ST, (void*)(yyvsp[(5) - (6)].intval)); set_cfg_pos((yyval.action));
	}
    break;

  case 836:
#line 3252 "core/cfg.y"
    {
		(yyval.action)=mk_action(CFG_SELECT_T, 2, STRING_ST, (yyvsp[(3) - (6)].strval), RVE_ST, (yyvsp[(5) - (6)].rv_expr)); set_cfg_pos((yyval.action));
	}
    break;

  case 837:
#line 3255 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 838:
#line 3256 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad arguments, string and number expected"); }
    break;

  case 839:
#line 3257 "core/cfg.y"
    {
		(yyval.action)=mk_action(CFG_RESET_T, 1, STRING_ST, (yyvsp[(3) - (4)].strval)); set_cfg_pos((yyval.action));
	}
    break;

  case 840:
#line 3260 "core/cfg.y"
    { (yyval.action)=0; yyerror("missing '(' or ')' ?"); }
    break;

  case 841:
#line 3261 "core/cfg.y"
    { (yyval.action)=0; yyerror("bad arguments, string expected"); }
    break;

  case 842:
#line 3262 "core/cfg.y"
    {mod_func_action = mk_action(MODULE0_T, 2, MODEXP_ST, NULL, NUMBER_ST,
			0); }
    break;

  case 843:
#line 3263 "core/cfg.y"
    {
		mod_func_action->val[0].u.data =
			find_export_record((yyvsp[(1) - (5)].strval), mod_func_action->val[1].u.number, rt,
								&u_tmp);
		if (mod_func_action->val[0].u.data == 0) {
			if (find_export_record((yyvsp[(1) - (5)].strval), mod_func_action->val[1].u.number, 0,
									&u_tmp) ) {
					LM_ERR("misused command %s\n", (yyvsp[(1) - (5)].strval));
					yyerror("Command cannot be used in the block\n");
			} else {
				LM_ERR("cfg. parser: failed to find command %s (params %ld)\n",
						(yyvsp[(1) - (5)].strval), mod_func_action->val[1].u.number);
				yyerror("unknown command, missing loadmodule?\n");
			}
			free_mod_func_action(mod_func_action);
			mod_func_action=0;
		}else{
			if (mod_func_action && mod_f_params_pre_fixup(mod_func_action)<0) {
				/* error messages are printed inside the function */
				free_mod_func_action(mod_func_action);
				mod_func_action = 0;
				YYERROR;
			}
		}
		(yyval.action) = mod_func_action;
		set_cfg_pos((yyval.action));
	}
    break;

  case 844:
#line 3290 "core/cfg.y"
    { yyerror("'('')' expected (function call)");}
    break;

  case 846:
#line 3294 "core/cfg.y"
    { }
    break;

  case 847:
#line 3295 "core/cfg.y"
    {}
    break;

  case 848:
#line 3298 "core/cfg.y"
    {
		if ((yyvsp[(1) - (1)].rv_expr) && mod_func_action->val[1].u.number < MAX_ACTIONS-2) {
			mod_func_action->val[mod_func_action->val[1].u.number+2].type =
				RVE_ST;
			mod_func_action->val[mod_func_action->val[1].u.number+2].u.data =
				(yyvsp[(1) - (1)].rv_expr);
			mod_func_action->val[1].u.number++;
		} else if ((yyvsp[(1) - (1)].rv_expr)) {
			yyerror("Too many arguments\n");
			YYERROR;
		} else {
			YYERROR;
		}
	}
    break;

  case 849:
#line 3315 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, NUMBER_ST, 0, NUMBER_ST,
						(void*)(DROP_R_F|EXIT_R_F)); set_cfg_pos((yyval.action));
	}
    break;

  case 850:
#line 3319 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, RVE_ST, (yyvsp[(2) - (2)].rv_expr), NUMBER_ST,
						(void*)(DROP_R_F|EXIT_R_F)); set_cfg_pos((yyval.action));
	}
    break;

  case 851:
#line 3323 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, NUMBER_ST, 0, NUMBER_ST,
						(void*)(DROP_R_F|EXIT_R_F)); set_cfg_pos((yyval.action));
	}
    break;

  case 852:
#line 3327 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, NUMBER_ST, (void*)1, NUMBER_ST,
						(void*)EXIT_R_F);
		set_cfg_pos((yyval.action));
	}
    break;

  case 853:
#line 3332 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, RVE_ST, (yyvsp[(2) - (2)].rv_expr), NUMBER_ST, (void*)EXIT_R_F);
		set_cfg_pos((yyval.action));
	}
    break;

  case 854:
#line 3336 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, NUMBER_ST, (void*)1, NUMBER_ST,
						(void*)EXIT_R_F);
		set_cfg_pos((yyval.action));
	}
    break;

  case 855:
#line 3341 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, NUMBER_ST, (void*)1, NUMBER_ST,
						(void*)RETURN_R_F); set_cfg_pos((yyval.action));
	}
    break;

  case 856:
#line 3345 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, NUMBER_ST, (void*)1, NUMBER_ST,
						(void*)RETURN_R_F); set_cfg_pos((yyval.action));
	}
    break;

  case 857:
#line 3349 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, RVE_ST, (yyvsp[(2) - (2)].rv_expr), NUMBER_ST, (void*)RETURN_R_F);
		set_cfg_pos((yyval.action));
	}
    break;

  case 858:
#line 3353 "core/cfg.y"
    {
		(yyval.action)=mk_action(DROP_T, 2, NUMBER_ST, 0, NUMBER_ST, (void*)BREAK_R_F);
		set_cfg_pos((yyval.action));
	}
    break;


/* Line 1267 of yacc.c.  */
#line 11381 "core/cfg.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 3359 "core/cfg.y"


static void get_cpos(struct cfg_pos* pos)
{
	pos->s_line=startline;
	pos->e_line=line;
	pos->s_col=startcolumn;
	pos->e_col=column-1;
	if(finame==0)
		finame = (cfg_file!=0)?cfg_file:"default";
	pos->fname=finame;
	pos->rname=(routename!=0)?routename:default_routename;
}


static void warn_at(struct cfg_pos* p, char* format, ...)
{
	va_list ap;
	char s[256];

	va_start(ap, format);
	vsnprintf(s, sizeof(s), format, ap);
	va_end(ap);
	if (p->e_line!=p->s_line)
		LM_WARN("warning in config file %s, from line %d, column %d to"
					" line %d, column %d: %s\n",
					p->fname, p->s_line, p->s_col, p->e_line, p->e_col, s);
	else if (p->s_col!=p->e_col)
		LM_WARN("warning in config file %s, line %d, column %d-%d: %s\n",
					p->fname, p->s_line, p->s_col, p->e_col, s);
	else
		LM_WARN("warning in config file %s, line %d, column %d: %s\n",
				p->fname, p->s_line, p->s_col, s);
	cfg_warnings++;
}



static void yyerror_at(struct cfg_pos* p, char* format, ...)
{
	va_list ap;
	char s[256];

	va_start(ap, format);
	vsnprintf(s, sizeof(s), format, ap);
	va_end(ap);
	if (p->e_line!=p->s_line)
		LM_CRIT("parse error in config file %s, from line %d, column %d"
					" to line %d, column %d: %s\n",
					p->fname, p->s_line, p->s_col, p->e_line, p->e_col, s);
	else if (p->s_col!=p->e_col)
		LM_CRIT("parse error in config file %s, line %d, column %d-%d: %s\n",
					p->fname, p->s_line, p->s_col, p->e_col, s);
	else
		LM_CRIT("parse error in config file %s, line %d, column %d: %s\n",
					p->fname, p->s_line, p->s_col, s);
	cfg_errors++;
}



static void warn(char* format, ...)
{
	va_list ap;
	char s[256];
	struct cfg_pos pos;

	get_cpos(&pos);
	va_start(ap, format);
	vsnprintf(s, sizeof(s), format, ap);
	va_end(ap);
	warn_at(&pos, s);
}



static void yyerror(char* format, ...)
{
	va_list ap;
	char s[256];
	struct cfg_pos pos;

	get_cpos(&pos);
	va_start(ap, format);
	vsnprintf(s, sizeof(s), format, ap);
	va_end(ap);
	yyerror_at(&pos, s);
}



/** mk_rval_expr_v wrapper.
 *  checks mk_rval_expr_v return value and sets the cfg. pos
 *  (line and column numbers)
 *  @return rval_expr* on success, 0 on error (@see mk_rval_expr_v)
 */
static struct rval_expr* mk_rve_rval(enum rval_type type, void* v)
{
	struct rval_expr* ret;
	struct cfg_pos pos;

	get_cpos(&pos);
	ret=mk_rval_expr_v(type, v, &pos);
	if (ret==0){
		yyerror("internal error: failed to create rval expr");
		/* YYABORT; */
	}
	return ret;
}


/** mk_rval_expr1 wrapper.
 *  checks mk_rval_expr1 return value (!=0 and type checking)
 *  @return rval_expr* on success, 0 on error (@see mk_rval_expr1)
 */
static struct rval_expr* mk_rve1(enum rval_expr_op op, struct rval_expr* rve1)
{
	struct rval_expr* ret;
	struct rval_expr* bad_rve;
	enum rval_type type, bad_t, exp_t;

	if (rve1==0)
		return 0;
	ret=mk_rval_expr1(op, rve1, &rve1->fpos);
	if (ret && (rve_check_type(&type, ret, &bad_rve, &bad_t, &exp_t)!=1)){
		yyerror_at(&rve1->fpos, "bad expression: type mismatch"
					" (%s instead of %s)", rval_type_name(bad_t),
					rval_type_name(exp_t));
		rve_destroy(ret);
		ret=0;
	}
	return ret;
}


/** mk_rval_expr2 wrapper.
 *  checks mk_rval_expr2 return value (!=0 and type checking)
 *  @return rval_expr* on success, 0 on error (@see mk_rval_expr2)
 */
static struct rval_expr* mk_rve2(enum rval_expr_op op, struct rval_expr* rve1,
									struct rval_expr* rve2)
{
	struct rval_expr* ret;
	struct rval_expr* bad_rve;
	enum rval_type type, bad_t, exp_t;
	struct cfg_pos pos;

	if ((rve1==0) || (rve2==0))
		return 0;
	bad_rve=0;
	bad_t=0;
	exp_t=0;
	cfg_pos_join(&pos, &rve1->fpos, &rve2->fpos);
	ret=mk_rval_expr2(op, rve1, rve2, &pos);
	if (ret && (rve_check_type(&type, ret, &bad_rve, &bad_t, &exp_t)!=1)){
		if (bad_rve)
			yyerror_at(&pos, "bad expression: type mismatch:"
						" %s instead of %s at (%d,%d)",
						rval_type_name(bad_t), rval_type_name(exp_t),
						bad_rve->fpos.s_line, bad_rve->fpos.s_col);
		else
			yyerror("BUG: unexpected null \"bad\" expression\n");
		rve_destroy(ret);
		ret=0;
	}
	return ret;
}


/** check if the expression is an int.
 * if the expression does not evaluate to an int return -1 and
 * log an error.
 * @return 0 success, no warnings; 1 success but warnings; -1 on error */
static int rval_expr_int_check(struct rval_expr *rve)
{
	struct rval_expr* bad_rve;
	enum rval_type type, bad_t, exp_t;

	if (rve==0){
		yyerror("invalid expression");
		return -1;
	}else if (!rve_check_type(&type, rve, &bad_rve, &bad_t ,&exp_t)){
		if (bad_rve)
			yyerror_at(&rve->fpos, "bad expression: type mismatch:"
						" %s instead of %s at (%d,%d)",
						rval_type_name(bad_t), rval_type_name(exp_t),
						bad_rve->fpos.s_line, bad_rve->fpos.s_col);
		else
			yyerror("BUG: unexpected null \"bad\" expression\n");
		return -1;
	}else if (type!=RV_INT && type!=RV_NONE){
		warn_at(&rve->fpos, "non-int expression (you might want to use"
				" casts)\n");
		return 1;
	}
	return 0;
}


/** warn if the expression is constant.
 * @return 0 on success (no warning), 1 when warning */
static int warn_ct_rve(struct rval_expr *rve, char* name)
{
	if (rve && rve_is_constant(rve)){
		warn_at(&rve->fpos, "constant value in %s%s",
				name?name:"expression", name?"(...)":"");
		return 1;
	}
	return 0;
}


static struct name_lst* mk_name_lst(char* host, int flags)
{
	struct name_lst* l;
	if (host==0) return 0;
	l=pkg_malloc(sizeof(struct name_lst));
	if (l==0) {
		LM_CRIT("cfg. parser: out of memory.\n");
	} else {
		l->name=host;
		l->flags=flags;
		l->next=0;
	}
	return l;
}


static struct socket_id* mk_listen_id(char* host, int proto, int port)
{
	struct socket_id* l;
	if (host==0) return 0;
	l=pkg_malloc(sizeof(struct socket_id));
	if (l==0) {
		LM_CRIT("cfg. parser: out of memory.\n");
	} else {
		l->addr_lst=mk_name_lst(host, 0);
		if (l->addr_lst==0){
			pkg_free(l);
			return 0;
		}
		l->flags=0;
		l->port=port;
		l->proto=proto;
		l->next=0;
	}
	return l;
}


static void free_name_lst(struct name_lst* lst)
{
	struct name_lst* tmp;

	while(lst){
		tmp=lst;
		lst=lst->next;
		pkg_free(tmp);
	}
}


static struct socket_id* mk_listen_id2(struct name_lst* addr_l, int proto,
										int port)
{
	struct socket_id* l;
	if (addr_l==0) return 0;
	l=pkg_malloc(sizeof(struct socket_id));
	if (l==0) {
		LM_CRIT("cfg. parser: out of memory.\n");
	} else {
		l->flags=addr_l->flags;
		l->port=port;
		l->proto=proto;
		l->addr_lst=addr_l;
		l->next=0;
	}
	return l;
}


static void free_socket_id(struct socket_id* i)
{
	free_name_lst(i->addr_lst);
	pkg_free(i);
}


static void free_socket_id_lst(struct socket_id* lst)
{
	struct socket_id* tmp;

	while(lst){
		tmp=lst;
		lst=lst->next;
		free_socket_id(tmp);
	}
}


/** create a temporary case statmenet structure.
 *  *err will be filled in case of error (return == 0):
 *   -1 - non constant expression
 *   -2 - expression error (bad type)
 *   -10 - memory allocation error
 */
static struct case_stms* mk_case_stm(struct rval_expr* ct, int is_re,
											struct action* a, int* err)
{
	struct case_stms* s;
	struct rval_expr* bad_rve;
	enum rval_type type, bad_t, exp_t;
	enum match_str_type t;

	t=MATCH_UNKNOWN;
	if (ct){
		/* if ct!=0 => case, else if ct==0 is a default */
		if (!rve_is_constant(ct)){
			yyerror_at(&ct->fpos, "non constant expression in case");
			*err=-1;
			return 0;
		}
		if (rve_check_type(&type, ct, &bad_rve, &bad_t, &exp_t)!=1){
			yyerror_at(&ct->fpos, "bad expression: type mismatch:"
							" %s instead of %s at (%d,%d)",
							rval_type_name(bad_t), rval_type_name(exp_t),
							bad_rve->fpos.s_line, bad_rve->fpos.s_col);
			*err=-2;
			return 0;
		}
		if (is_re)
			t=MATCH_RE;
		else if (type==RV_STR)
			t=MATCH_STR;
		else
			t=MATCH_INT;
	}

	s=pkg_malloc(sizeof(*s));
	if (s==0) {
		yyerror("internal error: memory allocation failure");
		*err=-10;
	} else {
		memset(s, 0, sizeof(*s));
		s->ct_rve=ct;
		s->type=t;
		s->actions=a;
		s->next=0;
		s->append=0;
	}
	return s;
}


/*
 * @return 0 on success, -1 on error.
 */
static int case_check_type(struct case_stms* stms)
{
	struct case_stms* c;
	struct case_stms* s;

	for(c=stms; c ; c=c->next){
		if (!c->ct_rve) continue;
		for (s=c->next; s; s=s->next){
			if (!s->ct_rve) continue;
			if ((s->type!=c->type) &&
				!(	(c->type==MATCH_STR || c->type==MATCH_RE) &&
					(s->type==MATCH_STR || s->type==MATCH_RE) ) ){
					yyerror_at(&s->ct_rve->fpos, "type mismatch in case");
					return -1;
			}
		}
	}
	return 0;
}


/*
 * @return 0 on success, -1 on error.
 */
static int case_check_default(struct case_stms* stms)
{
	struct case_stms* c;
	int default_no;

	default_no=0;
	for(c=stms; c ; c=c->next)
		if (c->ct_rve==0) default_no++;
	return (default_no<=1)?0:-1;
}



/** fixes the parameters and the type of a module function call.
 * It is done here instead of fix action, to have quicker feedback
 * on error cases (e.g. passing a non constant to a function with a
 * declared fixup)
 * The rest of the fixup is done inside do_action().
 * @param a - filled module function call (MODULE*_T) action structure
 *            complete with parameters, starting at val[2] and parameter
 *            number at val[1].
 * @return 0 on success, -1 on error (it will also print the error msg.).
 *
 */
static int mod_f_params_pre_fixup(struct action* a)
{
	sr31_cmd_export_t* cmd_exp;
	action_u_t* params;
	int param_no;
	struct rval_expr* rve;
	struct rvalue* rv;
	int r;
	str s;

	cmd_exp = a->val[0].u.data;
	param_no = a->val[1].u.number;
	params = &a->val[2];

	switch(cmd_exp->param_no) {
		case 0:
			a->type = MODULE0_T;
			break;
		case 1:
			a->type = MODULE1_T;
			break;
		case 2:
			a->type = MODULE2_T;
			break;
		case 3:
			a->type = MODULE3_T;
			break;
		case 4:
			a->type = MODULE4_T;
			break;
		case 5:
			a->type = MODULE5_T;
			break;
		case 6:
			a->type = MODULE6_T;
			break;
		case VAR_PARAM_NO:
			a->type = MODULEX_T;
			break;
		default:
			yyerror("function %s: bad definition"
					" (invalid number of parameters)", cmd_exp->name);
			return -1;
	}

	if ( cmd_exp->fixup) {
		if (is_fparam_rve_fixup(cmd_exp->fixup))
			/* mark known fparam rve safe fixups */
			cmd_exp->fixup_flags  |= FIXUP_F_FPARAM_RVE;
		else if (!(cmd_exp->fixup_flags & FIXUP_F_FPARAM_RVE) &&
				 cmd_exp->free_fixup == 0) {
			/* v0 or v1 functions that have fixups and no coresp. fixup_free
			   functions, need constant, string params.*/
			for (r=0; r < param_no; r++) {
				rve=params[r].u.data;
				if (!rve_is_constant(rve)) {
					yyerror_at(&rve->fpos, "function %s: parameter %d is not"
								" constant\n", cmd_exp->name, r+1);
					return -1;
				}
				if ((rv = rval_expr_eval(0, 0, rve)) == 0 ||
						rval_get_str(0, 0, &s, rv, 0) < 0 ) {
					/* out of mem or bug ? */
					rval_destroy(rv);
					yyerror_at(&rve->fpos, "function %s: bad parameter %d"
									" expression\n", cmd_exp->name, r+1);
					return -1;
				}
				rval_destroy(rv);
				rve_destroy(rve);
				params[r].type = STRING_ST; /* asciiz */
				params[r].u.string = s.s;
				params[r].u.str.len = s.len; /* not used right now */
			}
		}
	}/* else
		if no fixups are present, the RVEs can be transformed
		into strings at runtime, allowing seamless var. use
		even with old functions.
		Further optimizations -> in fix_actions()
		*/
	return 0;
}



/** frees a filled module function call action structure.
 * @param a - filled module function call action structure
 *            complete with parameters, starting at val[2] and parameter
 *            number at val[1].
 */
static void free_mod_func_action(struct action* a)
{
	action_u_t* params;
	int param_no;
	int r;

	param_no = a->val[1].u.number;
	params = &a->val[2];

	for (r=0; r < param_no; r++)
		if (params[r].u.data)
			rve_destroy(params[r].u.data);
	pkg_free(a);
}



/*
int main(int argc, char ** argv)
{
	if (yyparse()!=0)
		fprintf(stderr, "parsing error\n");
}
*/

